@echo off
chcp 65001 >nul
title 短剧音频库 v4.9.13 自动更新优化版
cd /d "%~dp0"
if not exist "%~dp0Install-v4913.ps1" (
  echo [错误] 找不到 Install-v4913.ps1
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-v4913.ps1"
pause
