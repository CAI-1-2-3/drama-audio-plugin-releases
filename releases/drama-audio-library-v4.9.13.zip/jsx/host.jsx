/*
  Host-side ExtendScript for Adobe Premiere Pro.
*/

function SFX_escapeJSON(s) {
  s = String(s === undefined || s === null ? "" : s);
  return s.replace(/\\/g, "\\\\")
          .replace(/"/g, "\\\"")
          .replace(/\r/g, "\\r")
          .replace(/\n/g, "\\n")
          .replace(/\t/g, "\\t");
}

function SFX_result(ok, error, extra) {
  var out = '{"ok":' + (ok ? 'true' : 'false') + ',"error":"' + SFX_escapeJSON(error || '') + '"';
  if (extra) {
    for (var k in extra) {
      if (extra.hasOwnProperty(k)) {
        out += ',"' + SFX_escapeJSON(k) + '":' + extra[k];
      }
    }
  }
  out += '}';
  return out;
}

function SFX_basename(p) {
  p = String(p || "");
  p = p.replace(/\\/g, "/");
  return p.substring(p.lastIndexOf("/") + 1);
}

function SFX_findBinByName(parent, name) {
  if (!parent || !parent.children) return 0;

  for (var i = 0; i < parent.children.numItems; i++) {
    var child = parent.children[i];
    if (child && child.name === name && child.type === ProjectItemType.BIN) {
      return child;
    }
  }
  return 0;
}

function SFX_ensureBin(name) {
  var root = app.project.rootItem;
  var bin = SFX_findBinByName(root, name);
  if (bin) return bin;

  try {
    return root.createBin(name);
  } catch (e) {
    return root;
  }
}

function SFX_findItemByMediaPath(mediaPath) {
  var root = app.project.rootItem;
  var found = 0;

  try {
    found = root.findItemsMatchingMediaPath(mediaPath, 1);
    if (found && found.length && found.length > 0) {
      return found[0];
    }
  } catch (e) {}

  return 0;
}

function SFX_findItemByNameRecursive(parent, name) {
  if (!parent || !parent.children) return 0;

  for (var i = 0; i < parent.children.numItems; i++) {
    var child = parent.children[i];
    if (!child) continue;

    if (child.name === name) return child;

    if (child.type === ProjectItemType.BIN) {
      var found = SFX_findItemByNameRecursive(child, name);
      if (found) return found;
    }
  }
  return 0;
}

function SFX_getAudioTracks() {
  var seq = app.project.activeSequence;
  if (!seq) return SFX_result(false, "没有打开的时间线序列。");

  var tracks = [];
  try {
    for (var i = 0; i < seq.audioTracks.numTracks; i++) {
      var tr = seq.audioTracks[i];
      var nm = "";
      try { nm = tr.name || ""; } catch (e1) {}
      tracks.push('{"index":' + i + ',"name":"' + SFX_escapeJSON(nm) + '"}');
    }
  } catch (e) {
    return SFX_result(false, "读取音频轨道失败：" + e);
  }

  return SFX_result(true, "", { tracks: "[" + tracks.join(",") + "]" });
}

function SFX_importAndInsertAtCTI(filePath, audioTrackIndex) {
  var seq = app.project.activeSequence;
  if (!seq) return SFX_result(false, "没有打开的时间线序列。");

  var aIndex = parseInt(audioTrackIndex, 10);
  if (isNaN(aIndex) || aIndex < 0) aIndex = 0;

  try {
    if (aIndex >= seq.audioTracks.numTracks) {
      return SFX_result(false, "目标音频轨道不存在：A" + (aIndex + 1));
    }

    try {
      if (seq.audioTracks[aIndex].isLocked && seq.audioTracks[aIndex].isLocked()) {
        return SFX_result(false, "目标轨道 A" + (aIndex + 1) + " 已锁定。");
      }
    } catch (lockErr) {}
  } catch (e0) {
    return SFX_result(false, "无法读取音频轨道。");
  }

  var item = SFX_findItemByMediaPath(filePath);

  if (!item) {
    var bin = SFX_ensureBin("Drama Audio Library");
    var okImport = app.project.importFiles([filePath], true, bin, false);
    if (!okImport) {
      return SFX_result(false, "导入素材失败：" + filePath);
    }

    item = SFX_findItemByMediaPath(filePath);
    if (!item) {
      item = SFX_findItemByNameRecursive(bin, SFX_basename(filePath));
    }
  }

  if (!item) return SFX_result(false, "导入后仍找不到素材：" + SFX_basename(filePath));

  var timeObj = seq.getPlayerPosition();
  if (!timeObj) return SFX_result(false, "无法读取播放头位置。");

  var ok = false;

  try {
    ok = seq.insertClip(item, timeObj, 0, aIndex);
  } catch (e1) {
    try {
      ok = seq.insertClip(item, timeObj.ticks, 0, aIndex);
    } catch (e2) {
      return SFX_result(false, "插入时间线失败：" + e2);
    }
  }

  if (!ok) return SFX_result(false, "Premiere 返回插入失败。请确认时间线已激活，目标轨道未锁定。");
  return SFX_result(true, "", { track: String(aIndex), name: '"' + SFX_escapeJSON(item.name) + '"' });
}

var SFX_TICKS_PER_SECOND = 254016000000;

function SFX_secondsToTicksString(sec) {
  sec = Math.max(0, Number(sec) || 0);
  return String(Math.round(sec * SFX_TICKS_PER_SECOND));
}

function SFX_setSourceRange(item, inSec, outSec) {
  var ok = false;

  // Premiere 的 ProjectItem.setInPoint / setOutPoint 需要的是 ticks 字符串，
  // 不是秒数。v4.7 传了 "1.23" 这种秒数字符串，会被 PR 当成极小 ticks，
  // 所以插入后变成很短且没有声音的片段。v4.7.1 改成 ticks。
  var inText = SFX_secondsToTicksString(inSec);
  var outText = SFX_secondsToTicksString(outSec);

  try {
    // 2 = audio
    item.setInPoint(inText, 2);
    item.setOutPoint(outText, 2);
    ok = true;
  } catch (e1) {
    try {
      // fallback: 4 = all media, for different PR versions
      item.setInPoint(inText, 4);
      item.setOutPoint(outText, 4);
      ok = true;
    } catch (e2) {
      try {
        // last fallback: older builds sometimes accept seconds
        item.setInPoint(String(Math.max(0, Number(inSec) || 0)), 2);
        item.setOutPoint(String(Math.max(0, Number(outSec) || 0)), 2);
        ok = true;
      } catch (e3) {
        ok = false;
      }
    }
  }

  return ok;
}

function SFX_clearSourceRange(item) {
  try { item.clearInPoint(2); } catch (e1) {}
  try { item.clearOutPoint(2); } catch (e2) {}
  try { item.clearInPoint(4); } catch (e3) {}
  try { item.clearOutPoint(4); } catch (e4) {}
}

function SFX_getOrImportProjectItem(filePath) {
  var item = SFX_findItemByMediaPath(filePath);

  if (!item) {
    var bin = SFX_ensureBin("Drama Audio Library");
    var okImport = app.project.importFiles([filePath], true, bin, false);
    if (!okImport) {
      return 0;
    }

    item = SFX_findItemByMediaPath(filePath);
    if (!item) {
      item = SFX_findItemByNameRecursive(bin, SFX_basename(filePath));
    }
  }

  return item;
}

function SFX_importAndInsertRangeAtCTI(filePath, audioTrackIndex, inSec, outSec) {
  var seq = app.project.activeSequence;
  if (!seq) return SFX_result(false, "没有打开的时间线序列。");

  var aIndex = parseInt(audioTrackIndex, 10);
  if (isNaN(aIndex) || aIndex < 0) aIndex = 0;

  var inPoint = Math.max(0, Number(inSec) || 0);
  var outPoint = Math.max(0, Number(outSec) || 0);

  if (outPoint <= inPoint + 0.02) {
    return SFX_result(false, "选区无效：出点必须大于入点。");
  }

  try {
    if (aIndex >= seq.audioTracks.numTracks) {
      return SFX_result(false, "目标音频轨道不存在：A" + (aIndex + 1));
    }

    try {
      if (seq.audioTracks[aIndex].isLocked && seq.audioTracks[aIndex].isLocked()) {
        return SFX_result(false, "目标轨道 A" + (aIndex + 1) + " 已锁定。");
      }
    } catch (lockErr) {}
  } catch (e0) {
    return SFX_result(false, "无法读取音频轨道。");
  }

  var item = SFX_getOrImportProjectItem(filePath);
  if (!item) return SFX_result(false, "导入后仍找不到素材：" + SFX_basename(filePath));

  var rangeOk = SFX_setSourceRange(item, inPoint, outPoint);
  if (!rangeOk) {
    return SFX_result(false, "Premiere 未能设置素材入出点，请尝试插入完整素材。");
  }

  var timeObj = seq.getPlayerPosition();
  if (!timeObj) {
    SFX_clearSourceRange(item);
    return SFX_result(false, "无法读取播放头位置。");
  }

  var ok = false;
  try {
    ok = seq.insertClip(item, timeObj, 0, aIndex);
  } catch (e1) {
    try {
      ok = seq.insertClip(item, timeObj.ticks, 0, aIndex);
    } catch (e2) {
      SFX_clearSourceRange(item);
      return SFX_result(false, "插入选区失败：" + e2);
    }
  }

  SFX_clearSourceRange(item);

  if (!ok) return SFX_result(false, "Premiere 返回插入选区失败。请确认时间线已激活，目标轨道未锁定。");
  return SFX_result(true, "", {
    track: String(aIndex),
    name: '"' + SFX_escapeJSON(item.name) + '"',
    inSec: String(inPoint),
    outSec: String(outPoint)
  });
}



function SFX_timeToSecondsSafe(t) {
  try {
    if (t && t.seconds !== undefined) return Number(t.seconds) || 0;
  } catch (e1) {}
  try {
    if (t && t.ticks !== undefined) return Number(t.ticks) / SFX_TICKS_PER_SECOND;
  } catch (e2) {}
  try { return Number(t) || 0; } catch (e3) {}
  return 0;
}

function SFX_scanTrackCollectionForOrganizer(trackCollection, kind) {
  var tracks = [];
  var prefix = kind === "video" ? "V" : "A";
  var total = 0;

  try {
    total = trackCollection.numTracks;
  } catch (e0) {
    total = 0;
  }

  for (var i = 0; i < total; i++) {
    var tr = trackCollection[i];
    var nm = "";
    try { nm = tr.name || ""; } catch (e1) {}

    var clipsJson = [];
    var clipCount = 0;

    try {
      clipCount = tr.clips ? tr.clips.numItems : 0;
    } catch (e2) {
      clipCount = 0;
    }

    for (var c = 0; c < clipCount; c++) {
      var item = tr.clips[c];
      if (!item) continue;

      var start = 0;
      var end = 0;
      var name = "";

      try { start = SFX_timeToSecondsSafe(item.start); } catch (e3) {}
      try { end = SFX_timeToSecondsSafe(item.end); } catch (e4) {}
      try { name = item.name || ""; } catch (e5) {}

      if (!name) {
        try {
          if (item.projectItem) name = item.projectItem.name || "";
        } catch (e6) {}
      }

      clipsJson.push(
        '{"name":"' + SFX_escapeJSON(name || (prefix + (i + 1) + " Clip")) + '"' +
        ',"start":' + start.toFixed(3) +
        ',"end":' + end.toFixed(3) +
        '}'
      );
    }

    tracks.push(
      '{"index":' + i +
      ',"name":"' + SFX_escapeJSON(nm) + '"' +
      ',"clipCount":' + clipCount +
      ',"clips":[' + clipsJson.join(",") + ']}'
    );
  }

  return "[" + tracks.join(",") + "]";
}

function SFX_scanTrackOrganizer() {
  var seq = app.project.activeSequence;
  if (!seq) return SFX_result(false, "没有打开的时间线序列。");

  try {
    var video = SFX_scanTrackCollectionForOrganizer(seq.videoTracks, "video");
    var audio = SFX_scanTrackCollectionForOrganizer(seq.audioTracks, "audio");
    return SFX_result(true, "", {
      videoTracks: video,
      audioTracks: audio
    });
  } catch (e) {
    return SFX_result(false, "扫描轨道失败：" + e);
  }
}


function SFX_makeTrackSummaryJSON(trackCollection) {
  var tracks = [];
  var total = 0;

  try { total = trackCollection.numTracks; } catch (e0) { total = 0; }

  for (var i = 0; i < total; i++) {
    var tr = trackCollection[i];
    var nm = "";
    var clipCount = 0;

    try { nm = tr.name || ""; } catch (e1) {}
    try { clipCount = tr.clips ? tr.clips.numItems : 0; } catch (e2) { clipCount = 0; }

    tracks.push(
      '{"index":' + i +
      ',"name":"' + SFX_escapeJSON(nm) + '"' +
      ',"clipCount":' + clipCount +
      ',"clips":[]}'
    );
  }

  return "[" + tracks.join(",") + "]";
}

function SFX_scanTrackOrganizerSummary() {
  var seq = app.project.activeSequence;
  if (!seq) return SFX_result(false, "没有打开的时间线序列。请先打开并激活一个序列。");

  try {
    return SFX_result(true, "", {
      videoTracks: SFX_makeTrackSummaryJSON(seq.videoTracks),
      audioTracks: SFX_makeTrackSummaryJSON(seq.audioTracks)
    });
  } catch (e) {
    return SFX_result(false, "扫描轨道数量失败：" + e);
  }
}

function SFX_csvToIndexMap(csv) {
  var map = {};
  csv = String(csv || "");
  if (!csv) return map;

  var parts = csv.split(",");
  for (var i = 0; i < parts.length; i++) {
    var n = parseInt(parts[i], 10);
    if (!isNaN(n) && n >= 0) map[n] = true;
  }
  return map;
}

function SFX_scanSelectedTrackCollection(trackCollection, indexMap, kind) {
  var tracks = [];
  var prefix = kind === "video" ? "V" : "A";
  var total = 0;

  try { total = trackCollection.numTracks; } catch (e0) { total = 0; }

  for (var i = 0; i < total; i++) {
    if (!indexMap[i]) continue;

    var tr = trackCollection[i];
    var nm = "";
    var clipsJson = [];
    var clipCount = 0;

    try { nm = tr.name || ""; } catch (e1) {}
    try { clipCount = tr.clips ? tr.clips.numItems : 0; } catch (e2) { clipCount = 0; }

    for (var c = 0; c < clipCount; c++) {
      var item = tr.clips[c];
      if (!item) continue;

      var start = 0;
      var end = 0;
      var name = "";

      try { start = SFX_timeToSecondsSafe(item.start); } catch (e3) {}
      try { end = SFX_timeToSecondsSafe(item.end); } catch (e4) {}
      try { name = item.name || ""; } catch (e5) {}

      if (!name) {
        try {
          if (item.projectItem) name = item.projectItem.name || "";
        } catch (e6) {}
      }

      clipsJson.push(
        '{"name":"' + SFX_escapeJSON(name || (prefix + (i + 1) + " Clip")) + '"' +
        ',"start":' + start.toFixed(3) +
        ',"end":' + end.toFixed(3) +
        '}'
      );
    }

    tracks.push(
      '{"index":' + i +
      ',"name":"' + SFX_escapeJSON(nm) + '"' +
      ',"clipCount":' + clipCount +
      ',"clips":[' + clipsJson.join(",") + ']}'
    );
  }

  return "[" + tracks.join(",") + "]";
}

function SFX_scanTrackOrganizerSelected(videoCsv, audioCsv) {
  var seq = app.project.activeSequence;
  if (!seq) return SFX_result(false, "没有打开的时间线序列。请先打开并激活一个序列。");

  try {
    var vMap = SFX_csvToIndexMap(videoCsv);
    var aMap = SFX_csvToIndexMap(audioCsv);

    return SFX_result(true, "", {
      videoTracks: SFX_scanSelectedTrackCollection(seq.videoTracks, vMap, "video"),
      audioTracks: SFX_scanSelectedTrackCollection(seq.audioTracks, aMap, "audio")
    });
  } catch (e) {
    return SFX_result(false, "读取选中轨道素材失败：" + e);
  }
}



function SFX_qeTimeToSecondsSafe(qeTime) {
  if (qeTime === undefined || qeTime === null) return 0;
  try {
    if (typeof qeTime === "number") return Number(qeTime) || 0;
    if (typeof qeTime === "string") {
      var n = Number(qeTime);
      if (!isNaN(n)) return n;
    }
    if (qeTime.seconds !== undefined) return Number(qeTime.seconds) || 0;
    if (qeTime.ticks !== undefined) {
      var ticks = Number(qeTime.ticks) || 0;
      return ticks / 254016000000.0;
    }
  } catch (e) {}
  return 0;
}

function SFX_qeGetSequence() {
  try { app.enableQE(); } catch (e0) {}
  try {
    if (qe && qe.project && qe.project.getActiveSequence) return qe.project.getActiveSequence();
  } catch (e1) {}
  return null;
}

function SFX_qeGetTrack(qeSeq, kind, index) {
  try {
    if (kind === "video") return qeSeq.getVideoTrackAt(index);
    return qeSeq.getAudioTrackAt(index);
  } catch (e) {}
  return null;
}

function SFX_qeTrackNumItems(qeTrack) {
  try {
    if (qeTrack && qeTrack.numItems !== undefined) return Number(qeTrack.numItems) || 0;
  } catch (e) {}
  return 0;
}

function SFX_qeGetItemName(qeItem) {
  var nm = "";
  try { nm = qeItem.name || ""; } catch (e1) {}
  if (!nm) {
    try { nm = qeItem.projectItem.name || ""; } catch (e2) {}
  }
  return String(nm || "");
}

function SFX_qeFindClip(qeSeq, kind, trackIndex, startSec, endSec, name) {
  var qeTrack = SFX_qeGetTrack(qeSeq, kind, Number(trackIndex));
  if (!qeTrack) return null;

  var total = SFX_qeTrackNumItems(qeTrack);
  var best = null;
  var bestScore = 999999;
  for (var i = 0; i < total; i++) {
    var item = null;
    try { item = qeTrack.getItemAt(i); } catch (e0) { item = null; }
    if (!item) continue;

    var st = 0;
    var en = 0;
    try { st = SFX_qeTimeToSecondsSafe(item.start); } catch (e1) { st = 0; }
    try { en = SFX_qeTimeToSecondsSafe(item.end); } catch (e2) { en = 0; }
    if (en <= st) continue;

    var score = Math.abs(st - Number(startSec)) + Math.abs(en - Number(endSec));
    if (score > 0.1) continue;

    var nm = SFX_qeGetItemName(item);
    if (name && nm && nm !== name) {
      if (score < 0.02) {
        // tolerate name mismatch only if timing matches exactly.
      } else {
        continue;
      }
    }

    if (score < bestScore) {
      best = item;
      bestScore = score;
      if (score < 0.001 && (!name || !nm || nm === name)) break;
    }
  }
  return best;
}

function SFX_trackIsLocked(seq, kind, index) {
  try {
    var tr = kind === "video" ? seq.videoTracks[index] : seq.audioTracks[index];
    if (tr && tr.isLocked && tr.isLocked()) return true;
  } catch (e) {}
  return false;
}

function SFX_executeSingleTrackMove(seq, qeSeq, cmd) {
  var kind = String(cmd.kind || "video");
  var sourceTrack = Number(cmd.sourceTrack);
  var targetTrack = Number(cmd.targetTrack);
  if (isNaN(sourceTrack) || isNaN(targetTrack)) {
    return { ok: false, reason: "轨道索引无效" };
  }
  if (sourceTrack === targetTrack) {
    return { ok: true, skipped: true, reason: "无需移动" };
  }

  if (SFX_trackIsLocked(seq, kind, sourceTrack) || SFX_trackIsLocked(seq, kind, targetTrack)) {
    return { ok: false, reason: "源轨道或目标轨道已锁定" };
  }

  var qeClip = SFX_qeFindClip(qeSeq, kind, sourceTrack, Number(cmd.start), Number(cmd.end), String(cmd.name || ""));
  if (!qeClip) {
    return { ok: false, reason: "未找到待移动素材" };
  }

  var shift = targetTrack - sourceTrack;
  var vShift = kind === "video" ? shift : 0;
  var aShift = kind === "audio" ? shift : 0;
  var movedOk = false;
  try {
    movedOk = qeClip.moveToTrack(vShift, aShift, "00:00:00:00", 0);
  } catch (eMove) {
    return { ok: false, reason: "moveToTrack 执行失败：" + eMove };
  }

  var verify = SFX_qeFindClip(qeSeq, kind, targetTrack, Number(cmd.start), Number(cmd.end), String(cmd.name || ""));
  if (verify || movedOk === true || movedOk === undefined || movedOk === null) {
    return { ok: true, skipped: false };
  }

  return { ok: false, reason: "移动后未能在目标轨道验证到素材" };
}


function SFX_trackOrgParseJSON(planJson) {
  var text = String(planJson || "{}");

  try {
    if (typeof JSON !== "undefined" && JSON.parse) {
      return JSON.parse(text);
    }
  } catch (e1) {}

  try {
    // ExtendScript fallback. Input is generated by this panel via JSON.stringify.
    return eval("(" + text + ")");
  } catch (e2) {
    return null;
  }
}

function SFX_executeTrackOrganizerPlanCore(planJson) {
  var seq = app.project.activeSequence;
  if (!seq) return SFX_result(false, "没有打开的时间线序列。请先打开并激活一个序列。");

  var qeSeq = SFX_qeGetSequence();
  if (!qeSeq) return SFX_result(false, "无法访问 QE 时间线接口，当前版本无法执行纯垂直整理。");

  var plan = SFX_trackOrgParseJSON(planJson);
  if (!plan) return SFX_result(false, "整理方案解析失败。");

  var commands = [];
  var v = plan.videoCommands || [];
  var a = plan.audioCommands || [];
  for (var i = 0; i < v.length; i++) { v[i].kind = "video"; commands.push(v[i]); }
  for (var j = 0; j < a.length; j++) { a[j].kind = "audio"; commands.push(a[j]); }

  commands.sort(function (x, y) {
    var ks = String(x.kind || "").localeCompare(String(y.kind || ""));
    if (ks !== 0) return ks;
    return Number(x.sourceTrack) - Number(y.sourceTrack) || Number(x.targetTrack) - Number(y.targetTrack) || Number(x.start) - Number(y.start);
  });

  var moved = 0;
  var skipped = 0;
  var failed = 0;
  var notes = [];

  for (var c = 0; c < commands.length; c++) {
    var cmd = commands[c];
    var res = SFX_executeSingleTrackMove(seq, qeSeq, cmd);
    if (res.ok) {
      if (res.skipped) skipped++;
      else moved++;
    } else {
      failed++;
      notes.push((cmd.kind === "video" ? "视频" : "音频") + " " + (cmd.name || "未命名素材") + "：" + res.reason);
    }
  }

  var detail = "";
  if (notes.length) {
    var max = Math.min(10, notes.length);
    detail = notes.slice(0, max).join("\n");
    if (notes.length > max) detail += "\n……还有 " + (notes.length - max) + " 条记录";
  }

  return SFX_result(true, "", {
    moved: String(moved),
    skipped: String(skipped),
    failed: String(failed),
    details: '"' + SFX_escapeJSON(detail) + '"'
  });
}


function SFX_executeTrackOrganizerPlan(planJson) {
  try {
    return SFX_executeTrackOrganizerPlanCore(planJson);
  } catch (e) {
    return SFX_result(false, "执行脚本异常：" + e);
  }
}

