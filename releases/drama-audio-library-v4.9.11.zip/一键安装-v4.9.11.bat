@echo off
chcp 65001 >nul
title 短剧音频库 v4.9.11 方向整理逻辑版
cd /d "%~dp0"
if not exist "%~dp0Install-v4911.ps1" (
  echo [错误] 找不到 Install-v4911.ps1
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-v4911.ps1"
pause
