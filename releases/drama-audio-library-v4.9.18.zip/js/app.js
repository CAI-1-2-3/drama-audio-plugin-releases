/* global CSInterface, SystemPath */
(function () {
  "use strict";

  var cs = new CSInterface();

  var fs, path, childProcess, crypto, os;
  try {
    fs = require("fs");
    path = require("path");
    childProcess = require("child_process");
    crypto = require("crypto");
    os = require("os");
  } catch (e) {
    alert("Node.js 没有启用。请确认 manifest.xml 内有 --enable-nodejs，然后重启 Premiere Pro。");
    return;
  }

  var AUDIO_EXTS = [".wav", ".mp3", ".aif", ".aiff", ".m4a", ".ogg", ".flac"];

  var LIB_TYPES = {
    sfx: {
      label: "音效",
      folder: "sfx",
      defaults: ["全部", "未分类", "悬疑", "重音", "上升", "结尾", "幽默", "转场", "惊吓", "环境", "情绪", "其他"],
      primaryDefaults: ["全部", "短剧", "宣传片", "广告片"]
    },
    music: {
      label: "音乐",
      folder: "music",
      defaults: ["全部", "未分类", "短剧BGM", "悬疑", "紧张", "情绪", "燃向", "舒缓", "卡点", "转场", "结尾", "环境", "其他"],
      primaryDefaults: ["全部", "短剧", "宣传片", "广告片"]
    }
  };

  var KEYWORDS = {
    sfx: {
      "悬疑": ["suspense", "tension", "mystery", "dark", "horror", "thriller", "悬疑", "紧张", "诡异", "惊悚", "恐怖", "阴森", "压迫", "疑惑"],
      "重音": ["hit", "impact", "boom", "slam", "thud", "bass", "drop", "punch", "爆", "撞", "重音", "冲击", "敲击", "震撼", "低音", "鼓点", "砸"],
      "上升": ["rise", "riser", "whoosh up", "up", "build", "swell", "uplift", "上升", "递进", "拉升", "升起", "渐强", "蓄力", "起势"],
      "结尾": ["end", "ending", "outro", "finish", "logo", "sting", "button", "结尾", "收尾", "尾声", "落版", "结束", "定版"],
      "幽默": ["funny", "comedy", "cartoon", "boing", "pop", "silly", "quirk", "搞笑", "幽默", "滑稽", "尴尬", "弹跳", "可爱", "逗"],
      "转场": ["whoosh", "swoosh", "transition", "swipe", "pass", "转场", "划过", "嗖", "呼啸", "甩动", "飞过"],
      "惊吓": ["shock", "scare", "jump", "stab", "stinger", "惊吓", "吓人", "突发", "惊悚点", "刺", "惊"],
      "环境": ["ambience", "ambient", "room", "street", "wind", "rain", "city", "环境", "氛围", "雨", "风", "街道", "房间", "人群"],
      "情绪": ["sad", "warm", "hope", "emotional", "soft", "piano", "情绪", "悲伤", "温暖", "感动", "柔和", "伤感"]
    },
    music: {
      "短剧BGM": ["bgm", "music", "ost", "score", "短剧", "配乐", "背景音乐", "BGM"],
      "悬疑": ["suspense", "mystery", "detective", "dark", "悬疑", "谜团", "诡异", "推理", "暗黑"],
      "紧张": ["tension", "urgent", "danger", "pressure", "紧张", "压迫", "危险", "追逐", "急促"],
      "情绪": ["emotional", "sad", "tear", "heart", "warm", "piano", "情绪", "悲伤", "感动", "温情", "虐心", "钢琴"],
      "燃向": ["epic", "hero", "battle", "trailer", "power", "燃", "史诗", "战斗", "热血", "高燃"],
      "舒缓": ["soft", "calm", "lofi", "chill", "ambient", "舒缓", "安静", "治愈", "温柔", "轻音乐"],
      "卡点": ["beat", "rhythm", "dance", "drum", "卡点", "节奏", "鼓点", "踩点"],
      "转场": ["transition", "whoosh", "swell", "转场", "过渡", "推进"],
      "结尾": ["ending", "outro", "end", "logo", "结尾", "收尾", "结束", "落版"],
      "环境": ["ambience", "ambient", "nature", "rain", "wind", "city", "环境", "氛围", "雨声", "自然"]
    }
  };

  // v4.8.2: 只用于「重新自动分类」的扩展标签词库。
  // 如果分类结果命中这里但当前二级分类不存在，会先弹窗询问是否创建。
  var RECLASSIFY_EXTRA_KEYWORDS = {
    sfx: {
      "反转": ["反转", "转折", "反差", "逆转", "揭晓", "真相", "reveal", "twist"],
      "打脸": ["打脸", "爽点", "反击", "回怼", "逆袭", "slap", "counter"],
      "煽情": ["煽情", "催泪", "泪点", "感人", "心酸", "哭", "tear"],
      "甜宠": ["甜宠", "恋爱", "心动", "暧昧", "甜", "撒糖", "love", "romance"],
      "压迫": ["压迫", "压迫感", "危机", "逼近", "沉重", "pressure", "doom"],
      "惊喜": ["惊喜", "惊讶", "意外", "发现", "surprise"],
      "提示": ["提示", "提醒", "叮", "成功", "失败", "notice", "alert", "提示音"],
      "倒计时": ["倒计时", "计时", "滴答", "tick", "clock", "countdown"],
      "科技": ["科技", "电子", "机械", "扫描", "系统", "sci", "tech", "digital"],
      "古风": ["古风", "国风", "武侠", "仙侠", "江湖", "笛", "琴", "鼓"],
      "战斗": ["战斗", "刀剑", "拳", "打斗", "格斗", "battle", "fight", "sword"],
      "生活": ["生活", "日常", "家里", "脚步", "开门", "关门", "电话", "手机"]
    },
    music: {
      "反转": ["反转", "转折", "反差", "逆转", "揭晓", "真相", "reveal", "twist"],
      "煽情": ["煽情", "催泪", "泪点", "感人", "心酸", "虐", "tear"],
      "甜宠": ["甜宠", "恋爱", "心动", "暧昧", "甜", "撒糖", "love", "romance"],
      "压迫": ["压迫", "压迫感", "危机", "黑暗", "沉重", "pressure"],
      "古风": ["古风", "国风", "武侠", "仙侠", "江湖", "中国风", "古装"],
      "战斗": ["战斗", "史诗", "战争", "热血", "battle", "fight", "epic"],
      "生活": ["生活", "日常", "轻松", "城市", "vlog", "daily"]
    }
  };

  function $(id) {
    return document.getElementById(id);
  }

  function cepPathToFsPath(p) {
    p = String(p || "");
    try { p = decodeURI(p); } catch (e) {}

    if (p.indexOf("file:///") === 0) {
      p = p.substring("file:///".length);
    } else if (p.indexOf("file://") === 0) {
      p = p.substring("file://".length);
    } else if (p.indexOf("file:/") === 0) {
      p = p.substring("file:/".length);
    }

    if (/^\/[a-zA-Z]:/.test(p)) {
      p = p.substring(1);
    }

    if (process.platform === "win32") {
      p = p.replace(/\//g, "\\");
    }

    return p;
  }

  var rawUserData = cs.getSystemPath(SystemPath.USER_DATA) || process.env.APPDATA || process.env.HOME || ".";
  var userData = cepPathToFsPath(rawUserData);
  if (!userData || userData.indexOf("file:") === 0) {
    userData = process.env.APPDATA || process.env.HOME || ".";
  }

  var DEFAULT_LIB_DIR = path.join(userData, "DramaAudioLibrary");
  var LOCATION_CONFIG_PATH = path.join(userData, "DramaAudioLibrary.location.json");

  function readLibraryLocationConfig() {
    try {
      if (!fs.existsSync(LOCATION_CONFIG_PATH)) return "";
      var cfg = JSON.parse(fs.readFileSync(LOCATION_CONFIG_PATH, "utf8"));
      var dir = cfg && cfg.libraryDir ? String(cfg.libraryDir) : "";
      if (!dir) return "";
      return path.resolve(dir);
    } catch (e) {
      return "";
    }
  }

  function writeLibraryLocationConfig(dir) {
    try {
      var parent = path.dirname(LOCATION_CONFIG_PATH);
      if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
      fs.writeFileSync(LOCATION_CONFIG_PATH, JSON.stringify({
        libraryDir: path.resolve(dir),
        updatedAt: new Date().toISOString()
      }, null, 2), "utf8");
      return true;
    } catch (e) {
      alert("保存路径配置失败：" + e.message);
      return false;
    }
  }

  var LIB_DIR = readLibraryLocationConfig() || DEFAULT_LIB_DIR;
  var MEDIA_DIR = "";
  var STATE_PATH = "";
  var LOG_PATH = "";
  var AUTH_PATH = "";
  var DEVICE_PATH = "";

  function setLibraryPaths(dir) {
    LIB_DIR = path.resolve(dir || DEFAULT_LIB_DIR);
    MEDIA_DIR = path.join(LIB_DIR, "media");
    STATE_PATH = path.join(LIB_DIR, "library.json");
    LOG_PATH = path.join(LIB_DIR, "debug.log");
    AUTH_PATH = path.join(LIB_DIR, "license.json");
    DEVICE_PATH = path.join(LIB_DIR, "device.json");
  }

  setLibraryPaths(LIB_DIR);

  var PLUGIN_VERSION = "4.9.18";
  var PRODUCT_ID = "drama-audio-library";
  var LICENSE_API_BASE = "https://drama-audio-license-api.cai1473785473.workers.dev";
  var EXTENSION_DIR = path.resolve(__dirname, "..");
  var OFFLINE_GRACE_MS = 72 * 60 * 60 * 1000;
  var EXPECTED_FILE_HASHES = {
  "index.html": "FE418BF923C615304C7F4C567C402C651E4A0A558F97389EF42BB650C4133799",
  "css/styles.css": "30E76DB0882CAC1F85A0254B43843A0B9744C68C52AC276F74227C27B7D2B53E",
  "CSXS/manifest.xml": "760740CF27C11BAFB0D1B532547DCA5823ED1DE04ED8B5991DB8FE68BAED6B08"
};

  var state = {
    version: 4,
    createdAt: new Date().toISOString(),
    currentType: "sfx",
    selectedPrimaryCategory: {
      sfx: "全部",
      music: "全部"
    },
    selectedCategory: {
      sfx: "全部",
      music: "全部"
    },
    customPrimaryCategories: [],
    deletedPrimaryCategories: {
      sfx: [],
      music: []
    },
    customCategories: [],
    deletedCategories: {
      sfx: [],
      music: []
    },
    items: []
  };

  var selectedId = null;
  var currentPreviewId = null;
  var selectedIds = {};

  var latestUpdateInfo = null;

  var waveState = {
    itemId: null,
    path: "",
    duration: 0,
    peaks: [],
    inSec: 0,
    outSec: 0,
    hasRange: false,
    dragging: false,
    dragStartSec: 0,
    playRangeMode: false,
    loading: false
  };
  var waveCache = {};
  var importing = false;

  function ensureDir(dir) {
    if (!dir) return;
    if (!fs.existsSync(dir)) {
      try {
        fs.mkdirSync(dir, { recursive: true });
      } catch (e) {
        var parts = String(dir).split(/[\\/]+/);
        var current = "";
        for (var i = 0; i < parts.length; i++) {
          if (!parts[i]) continue;
          if (i === 0 && /^[a-zA-Z]:$/.test(parts[i])) {
            current = parts[i] + "\\";
            continue;
          }
          current = current ? path.join(current, parts[i]) : parts[i];
          if (!fs.existsSync(current)) {
            try { fs.mkdirSync(current); } catch (_) {}
          }
        }
      }
    }
  }

  function normalizePathForCompare(p) {
    try { return path.resolve(String(p || "")).toLowerCase().replace(/[\\/]+$/, ""); }
    catch (e) { return String(p || "").toLowerCase().replace(/[\\/]+$/, ""); }
  }

  function isSamePath(a, b) {
    return normalizePathForCompare(a) === normalizePathForCompare(b);
  }

  function copyDirRecursive(src, dest) {
    if (!src || !fs.existsSync(src)) return;
    ensureDir(dest);

    var entries = fs.readdirSync(src);
    for (var i = 0; i < entries.length; i++) {
      var from = path.join(src, entries[i]);
      var to = path.join(dest, entries[i]);
      var st = fs.statSync(from);

      if (st.isDirectory()) {
        copyDirRecursive(from, to);
      } else {
        ensureDir(path.dirname(to));
        if (!fs.existsSync(to)) {
          fs.copyFileSync(from, to);
        } else {
          var ext = path.extname(to);
          var base = path.basename(to, ext);
          var dir = path.dirname(to);
          var candidate = to;
          var n = 2;
          while (fs.existsSync(candidate)) {
            candidate = path.join(dir, base + "_copy" + n + ext);
            n++;
          }
          fs.copyFileSync(from, candidate);
        }
      }
    }
  }

  function chooseFolderForLibraryPath(title) {
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialogEx) {
      toast("文件夹选择接口不可用。");
      return "";
    }

    var result = window.cep.fs.showOpenDialogEx(false, true, title || "选择保存位置", "", [], "Folder", "选择");
    if (result && result.err === 0 && result.data && result.data.length) return cepPathToFsPath(result.data[0]);
    return "";
  }

  function makeLibraryFolderFromSelected(selectedFolder) {
    selectedFolder = path.resolve(selectedFolder);
    if (path.basename(selectedFolder).toLowerCase() === "dramaaudiolibrary") {
      return selectedFolder;
    }
    return path.join(selectedFolder, "DramaAudioLibrary");
  }

  function switchLibraryDir(targetDir, shouldCopy) {
    var oldDir = LIB_DIR;
    targetDir = path.resolve(targetDir);

    if (isSamePath(oldDir, targetDir)) {
      toast("当前已经是这个保存路径。");
      return;
    }

    try {
      ensureDir(targetDir);
      if (shouldCopy && fs.existsSync(oldDir)) {
        showProgress(0, 1, "正在迁移音频库到新路径…");
        copyDirRecursive(oldDir, targetDir);
        hideProgress();
      }

      if (!writeLibraryLocationConfig(targetDir)) return;

      setLibraryPaths(targetDir);

      // 重新从新路径读取状态。授权、设备码、素材库文件都会从新路径读取。
      state = {
        version: 4,
        createdAt: new Date().toISOString(),
        currentType: "sfx",
        selectedPrimaryCategory: { sfx: "全部", music: "全部" },
        selectedCategory: { sfx: "全部", music: "全部" },
        customPrimaryCategories: [],
        deletedPrimaryCategories: { sfx: [], music: [] },
        customCategories: [],
        deletedCategories: { sfx: [], music: [] },
        items: []
      };

      loadState();
      selectedId = null;
      selectedIds = {};
      currentPreviewId = null;
      updateSaveStatus();
      render();

      openUiConfirm({
        title: "保存路径已切换",
        subtitle: "新的素材库目录",
        message: "当前保存路径已切换到：\\n" + targetDir + "\\n\\n以后导入的音效 / 音乐 / 分类数据都会保存到这里。\\n\\n旧目录不会自动删除，确认新路径正常后可以手动清理旧目录：\\n" + oldDir,
        confirmText: "打开新目录",
        cancelText: "知道了",
        onConfirm: function () { openLibraryDir(); }
      });
    } catch (e) {
      hideProgress();
      alert("切换保存路径失败：" + e.message);
    }
  }

  function changeLibraryDir() {
    if (!requireAuthorized()) return;

    var selected = chooseFolderForLibraryPath("选择音频库保存位置");
    if (!selected) return;

    var target = makeLibraryFolderFromSelected(selected);

    openUiConfirm({
      title: "修改保存路径",
      subtitle: "会在所选位置创建 DramaAudioLibrary 文件夹",
      message:
        "你选择的位置：\\n" + selected +
        "\\n\\n实际保存目录会是：\\n" + target +
        "\\n\\n是否把当前 C 盘/默认目录里的素材库一起复制过去？\\n\\n建议选择「迁移并切换」，这样不会丢失已导入的音效、音乐、分类、授权缓存和设备信息。",
      confirmText: "迁移并切换",
      cancelText: "只切换不迁移",
      onConfirm: function () { switchLibraryDir(target, true); },
      onCancel: function () { switchLibraryDir(target, false); }
    });
  }

  function log(msg) {
    try {
      ensureDir(LIB_DIR);
      fs.appendFileSync(LOG_PATH, "[" + new Date().toISOString() + "] " + msg + "\n", "utf8");
    } catch (e) {}
  }

  function toast(msg) {
    var el = $("toast");
    el.textContent = msg;
    el.classList.remove("hidden");
    setTimeout(function () {
      el.classList.add("hidden");
    }, 2400);
  }


  var authState = {
    checked: false,
    allowed: false,
    status: "checking",
    deviceId: "",
    reason: ""
  };

  function runCommandSafe(cmd, timeoutMs) {
    try {
      return childProcess.execSync(cmd, {
        encoding: "utf8",
        timeout: timeoutMs || 2500,
        windowsHide: true,
        stdio: ["ignore", "pipe", "ignore"]
      });
    } catch (e) {
      return "";
    }
  }

  function cleanHardwareValue(v) {
    v = String(v || "").replace(/\r/g, "\n").split("\n").map(function (x) {
      return String(x || "").trim();
    }).filter(Boolean);

    var bad = /^(serialnumber|processorid|uuid|to be filled|to be filled by o\.e\.m\.|none|unknown|default string|system serial number|0+)$/i;

    for (var i = 0; i < v.length; i++) {
      var line = v[i].replace(/\s+/g, " ").trim();
      if (line && !bad.test(line)) return line;
    }
    return "";
  }

  function powershellOne(command) {
    if (process.platform !== "win32") return "";
    var cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "' + command.replace(/"/g, '\\"') + '"';
    return cleanHardwareValue(runCommandSafe(cmd, 3000));
  }

  function wmicOne(command) {
    if (process.platform !== "win32") return "";
    return cleanHardwareValue(runCommandSafe(command, 2500));
  }

  function getMachineGuid() {
    try {
      if (process.platform === "win32") {
        var out = runCommandSafe('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', 2500);
        var m = /MachineGuid\s+REG_SZ\s+([^\r\n]+)/i.exec(out);
        if (m && m[1]) return String(m[1]).trim();
      }
    } catch (e) {
      log("MachineGuid read failed: " + e.message);
    }
    return "";
  }

  function getWindowsHardwareParts() {
    var parts = {
      baseboardSerial: "",
      biosSerial: "",
      cpuId: "",
      machineGuid: "",
      computerName: process.env.COMPUTERNAME || "",
      osArch: os.arch ? os.arch() : ""
    };

    if (process.platform === "win32") {
      parts.baseboardSerial = powershellOne("(Get-CimInstance Win32_BaseBoard).SerialNumber") || wmicOne("wmic baseboard get serialnumber");
      parts.biosSerial = powershellOne("(Get-CimInstance Win32_BIOS).SerialNumber") || wmicOne("wmic bios get serialnumber");
      parts.cpuId = powershellOne("(Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId") || wmicOne("wmic cpu get processorid");
      parts.machineGuid = getMachineGuid();
    } else {
      parts.machineGuid = os.hostname ? os.hostname() : "";
    }

    return parts;
  }

  function sha256(s) {
    return crypto.createHash("sha256").update(String(s || ""), "utf8").digest("hex").toUpperCase();
  }

  function formatDeviceId(hash) {
    hash = String(hash || "").replace(/[^A-F0-9]/g, "");
    return "DAG-HW-" + hash.slice(0, 4) + "-" + hash.slice(4, 8) + "-" + hash.slice(8, 12);
  }

  var deviceFingerprintCache = null;

  function getDeviceFingerprint() {
    if (deviceFingerprintCache) return deviceFingerprintCache;

    ensureDir(LIB_DIR);

    var parts = getWindowsHardwareParts();
    var raw = [
      "drama-audio-library-hardware-v2",
      parts.baseboardSerial || "",
      parts.biosSerial || "",
      parts.cpuId || "",
      parts.machineGuid || "",
      parts.computerName || "",
      parts.osArch || ""
    ].join("|");

    var available = [];
    if (parts.baseboardSerial) available.push("baseboard");
    if (parts.biosSerial) available.push("bios");
    if (parts.cpuId) available.push("cpu");
    if (parts.machineGuid) available.push("machineGuid");

    var hardwareHash = sha256(raw);
    var id = formatDeviceId(hardwareHash);

    deviceFingerprintCache = {
      deviceId: id,
      hardwareHash: hardwareHash,
      hardwareVersion: "hardware-v2",
      hardwareSources: available,
      createdAt: new Date().toISOString()
    };

    try {
      fs.writeFileSync(DEVICE_PATH, JSON.stringify({
        deviceId: id,
        hardwareHash: hardwareHash,
        hardwareVersion: "hardware-v2",
        hardwareSources: available,
        updatedAt: new Date().toISOString()
      }, null, 2), "utf8");
    } catch (e) {
      log("device file failed: " + e.message);
    }

    return deviceFingerprintCache;
  }

  function getDeviceId() {
    var fp = getDeviceFingerprint();
    authState.deviceId = fp.deviceId;
    return fp.deviceId;
  }

  function readFileHash(rel) {
    try {
      var full = path.join(EXTENSION_DIR, rel);
      if (!fs.existsSync(full)) return "";
      return sha256(fs.readFileSync(full));
    } catch (e) {
      log("hash failed " + rel + ": " + e.message);
      return "";
    }
  }

  function getIntegrityReport() {
    var report = [];
    var overall = "ok";
    var concat = [];

    Object.keys(EXPECTED_FILE_HASHES || {}).forEach(function (rel) {
      var expected = EXPECTED_FILE_HASHES[rel];
      var actual = readFileHash(rel);
      var ok = !!actual && String(actual).toUpperCase() === String(expected).toUpperCase();
      if (!ok) overall = "warning";
      report.push({
        file: rel,
        ok: ok,
        expected: String(expected || "").slice(0, 16),
        actual: String(actual || "").slice(0, 16)
      });
      concat.push(rel + ":" + actual);
    });

    // v4.6.1: report mismatch details to backend, but do not lock the client only because
    // local CEP file bytes may vary after install/copy. Backend can still record the report.
    return {
      integrityStatus: "ok",
      integrityCheckResult: overall,
      integrityHash: sha256(concat.join("|")).slice(0, 32),
      integrityReport: report
    };
  }

  function readAuthCache() {
    try {
      if (fs.existsSync(AUTH_PATH)) return JSON.parse(fs.readFileSync(AUTH_PATH, "utf8"));
    } catch (e) {
      log("read auth cache failed: " + e.message);
    }
    return {};
  }

  function writeAuthCache(data) {
    try {
      ensureDir(LIB_DIR);
      fs.writeFileSync(AUTH_PATH, JSON.stringify(data || {}, null, 2), "utf8");
    } catch (e) {
      log("write auth cache failed: " + e.message);
    }
  }

  function apiPost(apiPath, payload) {
    return new Promise(function (resolve, reject) {
      try {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", LICENSE_API_BASE + apiPath, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.timeout = 15000;
        xhr.onreadystatechange = function () {
          if (xhr.readyState !== 4) return;
          var txt = xhr.responseText || "";
          var json = null;
          try { json = JSON.parse(txt); } catch (e) {}
          if (xhr.status >= 200 && xhr.status < 300 && json) resolve(json);
          else reject(new Error((json && (json.reason || json.error)) || ("HTTP " + xhr.status + " " + txt.slice(0, 120))));
        };
        xhr.ontimeout = function () { reject(new Error("授权后台连接超时")); };
        xhr.onerror = function () { reject(new Error("无法连接授权后台")); };
        xhr.send(JSON.stringify(payload || {}));
      } catch (e) {
        reject(e);
      }
    });
  }

  function setAuthChip(text, cls) {
    var chip = $("authChip");
    if (!chip) return;
    chip.textContent = text || "授权未知";
    chip.className = "auth-chip " + (cls || "checking");
  }

  function updateDeveloperContact(dev) {
    dev = dev || {};
    var phone = dev.phone || dev.contact || "19910766507";
    var name = dev.name || "短剧音频库";
    var text = phone ? phone : name;

    if ($("devContactSide")) $("devContactSide").textContent = text;
    if ($("authDeveloperContact")) $("authDeveloperContact").textContent = text;

    try {
      var cache = readAuthCache();
      cache.developer = { name: name, phone: phone, updatedAt: new Date().toISOString() };
      writeAuthCache(cache);
    } catch (e) {}
  }


  function showAuthGate(message, cls) {
    var gate = $("authGate");
    if (gate) {
      gate.classList.remove("hidden");
      gate.setAttribute("aria-hidden", "false");
    }
    var status = $("authStatus");
    if (status) {
      status.textContent = message || "需要联网授权";
      status.className = "auth-status " + (cls || "bad");
    }
    var dev = $("authDeviceId");
    if (dev) dev.value = authState.deviceId || getDeviceId();

    var closeBtn = $("btnCloseAuthGate");
    if (closeBtn) closeBtn.style.display = authState.allowed ? "" : "none";

    var cache = readAuthCache();
    if (cache.developer) updateDeveloperContact(cache.developer);
  }

  function hideAuthGate() {
    var gate = $("authGate");
    if (gate) {
      gate.classList.add("hidden");
      gate.setAttribute("aria-hidden", "true");
    }
  }

  function openAuthPanelFromChip() {
    var fp = getDeviceFingerprint();
    authState.deviceId = fp.deviceId || authState.deviceId || getDeviceId();

    var text = "当前授权状态：" + (authState.status || "未知");
    var cls = "checking";

    if (authState.allowed) {
      if (authState.status === "trial") {
        text = "当前为试用状态，可在这里查看设备码或粘贴激活码。";
        cls = "trial";
      } else {
        text = "当前已授权，可在这里查看设备码。";
        cls = "ok";
      }
    } else {
      text = authState.reason || "需要联网授权或激活码。";
      cls = "bad";
    }

    showAuthGate(text, cls);
  }

  function allowPlugin(statusText, chipCls) {
    authState.checked = true;
    authState.allowed = true;
    authState.status = statusText || "ok";
    hideAuthGate();
    setAuthChip(statusText || "已授权", chipCls || "ok");
  }

  function lockPlugin(message) {
    authState.checked = true;
    authState.allowed = false;
    authState.status = "locked";
    setAuthChip("未激活", "bad");
    showAuthGate(message || "试用已结束，请输入激活码。", "bad");
  }

  function requireAuthorized() {
    if (authState.allowed) return true;
    showAuthGate(authState.reason || "请先完成联网授权或激活插件。", "bad");
    return false;
  }

  function remainingDaysFromIso(endIso) {
    if (!endIso) return 0;
    var ms = new Date(endIso).getTime() - Date.now();
    return Math.max(0, Math.ceil(ms / 86400000));
  }


  function compareVersionLocal(a, b) {
    function parts(v) {
      return String(v || "0").replace(/^v/i, "").split(".").map(function (x) {
        return parseInt(x, 10) || 0;
      });
    }

    var pa = parts(a);
    var pb = parts(b);
    var len = Math.max(pa.length, pb.length);

    for (var i = 0; i < len; i++) {
      var da = pa[i] || 0;
      var db = pb[i] || 0;
      if (da > db) return 1;
      if (da < db) return -1;
    }

    return 0;
  }

  function updateUpdateStatus(text, isNew) {
    var el = $("updateStatus");
    if (!el) return;
    el.innerHTML = escapeHtml(text || ("当前版本：v" + PLUGIN_VERSION));
    el.style.color = isNew ? "#ffd047" : "#8fa3d2";
  }

  function setUpdateButtonVisible(visible) {
    var btn = $("btnInstallUpdate");
    if (!btn) return;
    btn.classList.toggle("hidden", !visible);
  }

  function normalizeUpdateInfo(update) {
    update = update || {};
    var latest = update.latestVersion || update.latest_version || "";
    var current = update.currentVersion || PLUGIN_VERSION;
    var has = !!update.hasUpdate || (!!latest && compareVersionLocal(latest, PLUGIN_VERSION) > 0);

    return {
      hasUpdate: has,
      currentVersion: current,
      latestVersion: latest,
      minSupportedVersion: update.minSupportedVersion || update.min_supported_version || "",
      forceUpdate: !!update.forceUpdate || !!update.force_update,
      downloadUrl: update.downloadUrl || update.download_url || "",
      sha256: update.sha256 || "",
      releaseNotes: update.releaseNotes || update.release_notes || []
    };
  }

  function checkPluginUpdate(manual) {
    updateUpdateStatus("正在检查更新…", false);
    setUpdateButtonVisible(false);

    return apiPost("/api/update/check", {
      product: PRODUCT_ID,
      pluginVersion: PLUGIN_VERSION,
      version: PLUGIN_VERSION,
      deviceId: authState.deviceId || getDeviceId()
    }).then(function (res) {
      var info = normalizeUpdateInfo(res.update || {});
      latestUpdateInfo = info;

      if (res.developer) updateDeveloperContact(res.developer);

      if (!info.hasUpdate) {
        updateUpdateStatus("当前已是最新版本：v" + PLUGIN_VERSION, false);
        if (manual) toast("当前已是最新版本");
        return info;
      }

      var notes = "";
      if (Array.isArray(info.releaseNotes) && info.releaseNotes.length) {
        notes = "\n\n更新内容：\n" + info.releaseNotes.map(function (x) { return "• " + x; }).join("\n");
      }

      updateUpdateStatus("发现新版本：v" + info.latestVersion, true);
      setUpdateButtonVisible(true);

      openUiConfirm({
        title: "发现新版本 v" + info.latestVersion,
        subtitle: info.forceUpdate ? "后台要求强制更新" : "可以在插件内一键更新",
        message: "当前版本：v" + PLUGIN_VERSION + "\n最新版本：v" + info.latestVersion + notes + "\n\n点击「立即更新」会下载更新包。安装时需要关闭 Premiere Pro，用户数据会保留。",
        confirmText: "立即更新",
        cancelText: "稍后",
        onConfirm: function () { installPluginUpdate(info); }
      });

      return info;
    }).catch(function (err) {
      updateUpdateStatus("检查更新失败：" + err.message, false);
      if (manual) alert("检查更新失败：" + err.message);
      throw err;
    });
  }

  function psQuote(s) {
    return "'" + String(s || "").replace(/'/g, "''") + "'";
  }

  function sha256File(filePath) {
    var h = crypto.createHash("sha256");
    h.update(fs.readFileSync(filePath));
    return h.digest("hex").toUpperCase();
  }

  function writeUpdaterScript(info) {
    ensureDir(LIB_DIR);

    var updateRoot = path.join(LIB_DIR, "updates");
    var stageDir = path.join(updateRoot, "stage-" + Date.now());
    ensureDir(updateRoot);
    ensureDir(stageDir);

    var scriptPath = path.join(stageDir, "RunPluginUpdate.ps1");
    var logPath = path.join(stageDir, "plugin-update.log");
    var adminUrl = LICENSE_API_BASE + "/admin";

    var ps = [
      "$ErrorActionPreference = 'Stop'",
      "Add-Type -AssemblyName System.Windows.Forms",
      "$UpdateUrl = " + psQuote(info.downloadUrl),
      "$ExpectedSha256 = " + psQuote(info.sha256 || ""),
      "$PluginDir = " + psQuote(EXTENSION_DIR),
      "$StageDir = " + psQuote(stageDir),
      "$LogPath = " + psQuote(logPath),
      "$AdminUrl = " + psQuote(adminUrl),
      "function Log($m) { Add-Content -Path $LogPath -Value ('[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $m) -Encoding UTF8 }",
      "function Info($m) { [System.Windows.Forms.MessageBox]::Show($m, '短剧音频库更新', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null }",
      "function Fail($m) { Log ('FAILED: ' + $m); [System.Windows.Forms.MessageBox]::Show($m + \"`n`n日志：\" + $LogPath, '更新失败', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null; exit 1 }",
      "function GetPremiereProcesses { Get-Process | Where-Object { $_.ProcessName -like '*Premiere*' -or $_.ProcessName -like '*Adobe Premiere*' } }",
      "try {",
      "  New-Item -ItemType Directory -Force -Path $StageDir | Out-Null",
      "  Log 'Updater started.'",
      "  $PremierePath = ''",
      "  try {",
      "    $p = GetPremiereProcesses | Select-Object -First 1",
      "    if ($p) { try { $PremierePath = $p.Path } catch {} }",
      "    if ($PremierePath) { Log ('Premiere path: ' + $PremierePath) }",
      "  } catch {}",
      "  $ZipPath = Join-Path $StageDir 'plugin-update.zip'",
      "  $ExtractDir = Join-Path $StageDir 'extracted'",
      "  Log 'Downloading update package...'",
      "  Write-Progress -Activity '短剧音频库更新' -Status '正在下载更新包' -PercentComplete 15",
      "  Invoke-WebRequest -Uri $UpdateUrl -OutFile $ZipPath -UseBasicParsing",
      "  if (!(Test-Path $ZipPath)) { Fail '更新包下载失败。' }",
      "  Write-Progress -Activity '短剧音频库更新' -Status '正在校验更新包' -PercentComplete 30",
      "  if ($ExpectedSha256 -and $ExpectedSha256.Trim().Length -gt 0) {",
      "    $hash = (Get-FileHash -Algorithm SHA256 -Path $ZipPath).Hash.ToUpper()",
      "    Log ('SHA256: ' + $hash)",
      "    if ($hash -ne $ExpectedSha256.Trim().ToUpper()) { Fail '更新包校验失败，可能下载不完整或被替换。' }",
      "  }",
      "  Info \"独立更新窗口已经接管更新。`n`n请先保存并关闭 Premiere Pro。关闭后点击确定继续安装。`n`n更新完成后会询问是否重新启动 Premiere Pro。`n用户音效、音乐、分类、授权缓存都会保留。\"",
      "  Write-Progress -Activity '短剧音频库更新' -Status '等待关闭 Premiere Pro' -PercentComplete 45",
      "  while (GetPremiereProcesses) {",
      "    [System.Windows.Forms.MessageBox]::Show('检测到 Premiere Pro 仍在运行。`n`n请先关闭 Premiere Pro，再点击确定继续。', '等待关闭 Premiere Pro') | Out-Null",
      "    Start-Sleep -Seconds 1",
      "  }",
      "  Write-Progress -Activity '短剧音频库更新' -Status '正在解压更新包' -PercentComplete 60",
      "  if (Test-Path $ExtractDir) { Remove-Item $ExtractDir -Recurse -Force }",
      "  New-Item -ItemType Directory -Force -Path $ExtractDir | Out-Null",
      "  Expand-Archive -Path $ZipPath -DestinationPath $ExtractDir -Force",
      "  $SourceRoot = $ExtractDir",
      "  if (!(Test-Path (Join-Path $SourceRoot 'CSXS\\manifest.xml'))) {",
      "    $child = Get-ChildItem -Path $ExtractDir -Directory | Select-Object -First 1",
      "    if ($child -and (Test-Path (Join-Path $child.FullName 'CSXS\\manifest.xml'))) { $SourceRoot = $child.FullName }",
      "  }",
      "  if (!(Test-Path (Join-Path $SourceRoot 'CSXS\\manifest.xml'))) { Fail '更新包格式不正确：没有找到 CSXS\\manifest.xml。' }",
      "  $BackupRoot = Join-Path (Split-Path -Parent $PluginDir) ('backup-' + (Split-Path -Leaf $PluginDir) + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))",
      "  Log ('Backup to: ' + $BackupRoot)",
      "  Copy-Item -Path $PluginDir -Destination $BackupRoot -Recurse -Force",
      "  Write-Progress -Activity '短剧音频库更新' -Status '正在覆盖插件程序文件' -PercentComplete 82",
      "  Log 'Copy new files...'",
      "  Copy-Item -Path (Join-Path $SourceRoot '*') -Destination $PluginDir -Recurse -Force",
      "  Write-Progress -Activity '短剧音频库更新' -Status '安装完成' -PercentComplete 100",
      "  if ($PremierePath -and (Test-Path $PremierePath)) {",
      "    $ask = [System.Windows.Forms.MessageBox]::Show('更新完成。`n`n是否现在重新启动 Premiere Pro？`n`n如果新版本异常，可以在扩展目录旁边找到备份：`n' + $BackupRoot, '短剧音频库更新完成', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)",
      "    if ($ask -eq [System.Windows.Forms.DialogResult]::Yes) {",
      "      Log ('Relaunch Premiere: ' + $PremierePath)",
      "      try { Start-Process -FilePath $PremierePath | Out-Null } catch { Log ('Relaunch failed: ' + $_.Exception.Message); Info ('更新已完成，但自动启动 Premiere Pro 失败。`n请手动打开 PR。`n`n错误：' + $_.Exception.Message) }",
      "    } else {",
      "      Info \"更新完成。`n`n你可以稍后手动打开 Premiere Pro。\"",
      "    }",
      "  } else {",
      "    Info \"更新完成。`n`n没有自动找到 Premiere Pro 路径，请手动重新打开 PR。`n如果新版本异常，可以在扩展目录旁边找到备份：`n\" + $BackupRoot",
      "  }",
      "} catch {",
      "  Fail $_.Exception.Message",
      "}"
    ].join("\r\n");

    fs.writeFileSync(scriptPath, ps, "utf8");
    return scriptPath;
  }

  // v4.9.18 hotfix: v4.9.14 / v4.9.15 updater called setUpdateProgress,
  // but the function was missing, causing update to fail before downloading.
  function setUpdateProgress(percent, text) {
    percent = Math.max(0, Math.min(100, parseInt(percent || 0, 10) || 0));
    var msg = text || "正在准备更新...";
    try {
      updateUpdateStatus(msg + " " + percent + "%", true);
    } catch (e) {}

    try {
      var sub = $("uiDialogSubtitle");
      if (sub) sub.textContent = msg + " " + percent + "%";
    } catch (e2) {}

    try {
      var logLine = "[更新] " + msg + " " + percent + "%";
      if (typeof console !== "undefined" && console.log) console.log(logLine);
    } catch (e3) {}
  }

  // v4.9.18 hotfix: safe JSX call helper.
  // Used for saving Premiere project before handing update to the external updater window.
  function evalHostJson(script) {
    try {
      cs.evalScript(script, function (raw) {
        try {
          var res = parseHostJson(raw);
          if (!res.ok && res.error) {
            console.warn("Host script returned:", res.error);
          }
        } catch (e) {}
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message || String(e) };
    }
  }

  function installPluginUpdate(info) {
    info = normalizeUpdateInfo(info || latestUpdateInfo);

    if (!info || !info.hasUpdate) {
      toast("没有可安装的新版本。");
      return;
    }

    if (!info.downloadUrl) {
      alert("后台没有填写下载地址。\n\n请在授权后台「版本更新」里填写新版本 ZIP 的 downloadUrl。\n这个链接必须是可以直接下载 .zip 的直链。");
      return;
    }

    openUiConfirm({
      title: "内部自动更新到 v" + info.latestVersion,
      subtitle: "保存工程、独立更新、关闭 PR 后自动覆盖，完成后可一键启动 PR",
      message: "这是插件内部自动更新，不需要你手动下载或手动安装。\n\n流程：\n1. 先保存当前 Premiere 工程\n2. 弹出独立更新窗口\n3. 提示关闭 Premiere Pro\n4. 在独立窗口里自动下载并覆盖插件程序文件\n5. 更新完成后询问是否重新启动 Premiere Pro\n\n用户导入的音效、音乐、分类、设备码、激活缓存都保存在本地库目录，不会被覆盖。",
      confirmText: "保存工程并开始更新",
      cancelText: "取消",
      onConfirm: function () {
        try {
          setUpdateProgress(3, "正在保存当前 Premiere 工程...");
          try {
            var saveResult = evalHostJson("SFX_saveActiveProjectBeforeUpdate()");
            if (saveResult && saveResult.ok === false) {
              var goOn = confirm("保存工程时没有拿到确认结果：\n" + (saveResult.error || "未知错误") + "\n\n是否仍然继续启动更新？");
              if (!goOn) return;
            }
          } catch (saveErr) {
            var goOn2 = confirm("保存工程时没有拿到确认结果：\n" + (saveErr && saveErr.message ? saveErr.message : saveErr) + "\n\n是否仍然继续启动更新？");
            if (!goOn2) return;
          }

          var scriptPath = writeUpdaterScript(info);
          childProcess.spawn("powershell.exe", [
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            scriptPath
          ], {
            detached: true,
            stdio: "ignore",
            windowsHide: false
          }).unref();

          toast("独立更新窗口已启动，请按提示关闭 Premiere Pro。");
          alert("独立更新窗口已启动。\n\n后续会在新窗口里完成：\n1. 自动下载更新包\n2. 等你关闭 Premiere Pro\n3. 自动覆盖插件文件\n4. 完成后询问是否重新启动 PR");
        } catch (e) {
          alert("启动更新失败：" + e.message);
        }
      }
    });
  }

  function checkAuthorization() {
    var fp = getDeviceFingerprint();
    var deviceId = fp.deviceId;
    var cache = readAuthCache();
    var integrity = getIntegrityReport();
    authState.deviceId = deviceId;
    setAuthChip("授权检查中", "checking");
    showAuthGate("正在连接授权后台...", "checking");

    var input = $("authLicenseInput");
    if (input && cache.licenseCode) input.value = cache.licenseCode;

    return apiPost("/api/startup", {
      product: PRODUCT_ID,
      deviceId: deviceId,
      hardwareHash: fp.hardwareHash,
      hardwareVersion: fp.hardwareVersion,
      hardwareSources: fp.hardwareSources,
      integrityStatus: integrity.integrityStatus,
      integrityHash: integrity.integrityHash,
      integrityReport: integrity.integrityReport,
      pluginVersion: PLUGIN_VERSION,
      clientTime: new Date().toISOString(),
      licenseCode: cache.licenseCode || ""
    }).then(function (res) {
      if (res.developer) updateDeveloperContact(res.developer);
      var now = new Date().toISOString();
      if (res.status === "tampered") {
        authState.reason = res.reason || "插件文件完整性异常，请重新安装官方版本。";
        lockPlugin(authState.reason);
      } else if (res.status === "blocked") {
        authState.reason = res.reason || "此设备已被封禁。";
        lockPlugin(authState.reason);
      } else if (res.status === "licensed") {
        cache.status = "licensed";
        cache.lastOkAt = now;
        cache.deviceId = deviceId;
        cache.license = res.license || null;
        writeAuthCache(cache);
        allowPlugin("正式授权", "ok");
      } else if (res.status === "trial_active") {
        var days = res.trial ? res.trial.remainingDays : remainingDaysFromIso(res.trial && res.trial.trialEnd);
        cache.status = "trial_active";
        cache.lastOkAt = now;
        cache.deviceId = deviceId;
        cache.trial = res.trial || null;
        writeAuthCache(cache);
        allowPlugin("试用剩余 " + days + " 天", "trial");
      } else {
        authState.reason = res.reason || "试用已结束，请联系开发者获取激活码。";
        lockPlugin(authState.reason);
      }

      if (res.update) {
        latestUpdateInfo = normalizeUpdateInfo(res.update);
        if (latestUpdateInfo.hasUpdate) {
          updateUpdateStatus("发现新版本：v" + latestUpdateInfo.latestVersion, true);
          setUpdateButtonVisible(true);
          toast("发现新版本：" + latestUpdateInfo.latestVersion);
        } else {
          updateUpdateStatus("当前版本：v" + PLUGIN_VERSION, false);
        }
      }
    }).catch(function (err) {
      log("auth check failed: " + err.message);
      var cache = readAuthCache();
      if (cache.status === "licensed" && cache.lastOkAt) {
        var diff = Date.now() - new Date(cache.lastOkAt).getTime();
        if (diff < OFFLINE_GRACE_MS) {
          allowPlugin("离线授权", "ok");
          toast("授权后台暂时无法连接，已使用本地授权缓存。");
          return;
        }
      }
      authState.reason = "无法连接授权后台：" + err.message;
      lockPlugin(authState.reason);
    });
  }

  function activateLicense() {
    var code = ($("authLicenseInput") && $("authLicenseInput").value || "").trim();
    if (!code) {
      showAuthGate("请先粘贴激活码。", "bad");
      return;
    }

    var fp = getDeviceFingerprint();
    var deviceId = fp.deviceId;
    var integrity = getIntegrityReport();
    setAuthChip("正在激活", "checking");
    showAuthGate("正在激活，请稍候...", "checking");

    apiPost("/api/license/activate", {
      product: PRODUCT_ID,
      deviceId: deviceId,
      hardwareHash: fp.hardwareHash,
      hardwareVersion: fp.hardwareVersion,
      hardwareSources: fp.hardwareSources,
      integrityStatus: integrity.integrityStatus,
      integrityHash: integrity.integrityHash,
      integrityReport: integrity.integrityReport,
      pluginVersion: PLUGIN_VERSION,
      clientTime: new Date().toISOString(),
      licenseCode: code
    }).then(function (res) {
      if (res.developer) updateDeveloperContact(res.developer);
      if (res.ok && res.status === "licensed") {
        writeAuthCache({
          status: "licensed",
          deviceId: deviceId,
          licenseCode: code,
          license: res.license || null,
          activatedAt: new Date().toISOString(),
          lastOkAt: new Date().toISOString()
        });
        allowPlugin("正式授权", "ok");
        toast("激活成功");
      } else {
        lockPlugin(res.reason || "激活失败，请检查激活码。 ");
      }
    }).catch(function (err) {
      lockPlugin("激活失败：" + err.message);
    });
  }

  function bindAuthEvents() {
    if ($("btnCopyDevice")) {
      $("btnCopyDevice").addEventListener("click", function () {
        var dev = $("authDeviceId");
        if (!dev) return;
        dev.select();
        try { document.execCommand("copy"); toast("设备码已复制"); } catch (e) { toast("复制失败，请手动复制。 "); }
      });
    }
    if ($("btnActivateLicense")) $("btnActivateLicense").addEventListener("click", activateLicense);
    if ($("btnRetryAuth")) $("btnRetryAuth").addEventListener("click", checkAuthorization);
    if ($("authChip")) $("authChip").addEventListener("click", openAuthPanelFromChip);
    if ($("btnCloseAuthGate")) $("btnCloseAuthGate").addEventListener("click", function () {
      if (authState.allowed) hideAuthGate();
      else showAuthGate(authState.reason || "当前未授权，不能关闭授权窗口。", "bad");
    });
  }


  var dialogCallback = null;
  var dialogMode = "confirm";

  function dialogTextToHtml(text) {
    var html = escapeHtml(String(text || "")).replace(/\n/g, "<br>");
    html = html.replace(/「([^」]+)」/g, '「<span class="em">$1</span>」');
    return html;
  }

  function resetUiDialogInput() {
    var wrap = $("uiDialogInputWrap");
    var input = $("uiDialogInput");
    var hint = $("uiDialogInputHint");
    var panel = document.querySelector(".ui-dialog-panel");
    if (wrap) wrap.classList.add("hidden");
    if (input) {
      input.value = "";
      input.placeholder = "";
    }
    if (hint) hint.textContent = "";
    if (panel) panel.classList.remove("input-mode");
    dialogMode = "confirm";
  }

  function closeUiDialog(triggerCancel) {
    var box = $("uiDialog");
    if (!box) return;
    box.classList.add("hidden");
    box.setAttribute("aria-hidden", "true");
    var cb = dialogCallback;
    dialogCallback = null;
    resetUiDialogInput();
    if (triggerCancel && cb && cb.onCancel) cb.onCancel();
  }

  function showUiDialogBase(opts) {
    opts = opts || {};
    $("uiDialogTitle").textContent = opts.title || "确认操作";
    $("uiDialogSubtitle").textContent = opts.subtitle || "请确认后继续";
    $("uiDialogMessage").innerHTML = dialogTextToHtml(opts.message || "");
    $("uiDialogConfirm").textContent = opts.confirmText || "确认";
    $("uiDialogCancel").textContent = opts.cancelText || "取消";
    dialogCallback = { onConfirm: opts.onConfirm, onCancel: opts.onCancel };
    var box = $("uiDialog");
    box.classList.remove("hidden");
    box.setAttribute("aria-hidden", "false");
  }

  function openUiConfirm(opts) {
    opts = opts || {};
    var box = $("uiDialog");
    if (!box) {
      if (confirm(opts.message || "确定继续吗？")) {
        if (opts.onConfirm) opts.onConfirm();
      } else if (opts.onCancel) {
        opts.onCancel();
      }
      return;
    }
    resetUiDialogInput();
    showUiDialogBase(opts);
  }

  function openUiPrompt(opts) {
    opts = opts || {};
    var box = $("uiDialog");
    if (!box) {
      var v = window.prompt(opts.title || "请输入", opts.value || "");
      if (v === null) {
        if (opts.onCancel) opts.onCancel();
      } else if (opts.onConfirm) {
        opts.onConfirm(v);
      }
      return;
    }

    resetUiDialogInput();
    dialogMode = "prompt";

    var wrap = $("uiDialogInputWrap");
    var input = $("uiDialogInput");
    var hint = $("uiDialogInputHint");
    var panel = document.querySelector(".ui-dialog-panel");

    if (wrap) wrap.classList.remove("hidden");
    if (panel) panel.classList.add("input-mode");
    if (input) {
      input.value = opts.value || "";
      input.placeholder = opts.placeholder || "请输入名称";
    }
    if (hint) hint.textContent = opts.hint || "支持中文、英文、数字。";
    showUiDialogBase({
      title: opts.title || "输入名称",
      subtitle: opts.subtitle || "填写后点击确认",
      message: opts.message || "",
      confirmText: opts.confirmText || "确认添加",
      cancelText: opts.cancelText || "取消",
      onConfirm: function () {
        var value = input ? input.value : "";
        value = String(value || "").trim();
        if (opts.required !== false && !value) {
          toast(opts.emptyText || "名称不能为空。");
          openUiPrompt(opts);
          return;
        }
        if (opts.onConfirm) opts.onConfirm(value);
      },
      onCancel: opts.onCancel
    });

    setTimeout(function () {
      if (input) {
        input.focus();
        input.select();
      }
    }, 60);
  }

  function bindUiDialog() {
    if (!$("uiDialog")) return;
    $("uiDialogClose").addEventListener("click", function () { closeUiDialog(true); });
    $("uiDialogCancel").addEventListener("click", function () { closeUiDialog(true); });
    $("uiDialogMask").addEventListener("click", function () { closeUiDialog(true); });
    $("uiDialogConfirm").addEventListener("click", function () {
      var cb = dialogCallback;
      var mode = dialogMode;
      if (mode === "prompt") {
        if (cb && cb.onConfirm) cb.onConfirm();
        return;
      }
      closeUiDialog(false);
      if (cb && cb.onConfirm) cb.onConfirm();
    });

    if ($("uiDialogInput")) {
      $("uiDialogInput").addEventListener("keydown", function (e) {
        if (e.key === "Enter") {
          e.preventDefault();
          $("uiDialogConfirm").click();
        }
      });
    }

    document.addEventListener("keydown", function (e) {
      var box = $("uiDialog");
      if (!box || box.classList.contains("hidden")) return;
      if (e.key === "Escape") {
        e.preventDefault();
        closeUiDialog(true);
      }
    });
  }

  function normalizeSlashes(p) {
    return String(p || "").replace(/\\/g, "/");
  }

  function safeName(name) {
    return String(name || "sound")
      .replace(/[\\/:*?"<>|]/g, "_")
      .replace(/\s+/g, " ")
      .trim();
  }

  function uid() {
    return Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 9);
  }

  function loadState() {
    ensureDir(LIB_DIR);
    ensureDir(MEDIA_DIR);
    ensureDir(path.join(MEDIA_DIR, "sfx"));
    ensureDir(path.join(MEDIA_DIR, "music"));

    if (fs.existsSync(STATE_PATH)) {
      try {
        var loaded = JSON.parse(fs.readFileSync(STATE_PATH, "utf8"));
        if (loaded && loaded.items && loaded.items.length !== undefined) {
          state = migrateState(loaded);
        }
      } catch (e) {
        log("library.json read failed: " + e);
      }
    }

    if (!state.currentType) state.currentType = "sfx";
    if (!state.selectedCategory) state.selectedCategory = { sfx: "全部", music: "全部" };
    if (typeof state.selectedCategory === "string") {
      state.selectedCategory = { sfx: state.selectedCategory || "全部", music: "全部" };
    }
    if (!state.selectedCategory.sfx) state.selectedCategory.sfx = "全部";
    if (!state.selectedCategory.music) state.selectedCategory.music = "全部";

    if (!state.selectedPrimaryCategory) state.selectedPrimaryCategory = { sfx: "全部", music: "全部" };
    if (typeof state.selectedPrimaryCategory === "string") {
      state.selectedPrimaryCategory = { sfx: state.selectedPrimaryCategory || "全部", music: "全部" };
    }
    if (!state.selectedPrimaryCategory.sfx) state.selectedPrimaryCategory.sfx = "全部";
    if (!state.selectedPrimaryCategory.music) state.selectedPrimaryCategory.music = "全部";
    if (!state.customPrimaryCategories) state.customPrimaryCategories = [];
    if (!state.deletedPrimaryCategories) state.deletedPrimaryCategories = { sfx: [], music: [] };
    if (!state.deletedPrimaryCategories.sfx) state.deletedPrimaryCategories.sfx = [];
    if (!state.deletedPrimaryCategories.music) state.deletedPrimaryCategories.music = [];

    if (!state.customCategories) state.customCategories = [];
    if (!state.deletedCategories) state.deletedCategories = { sfx: [], music: [] };
    if (!state.deletedCategories.sfx) state.deletedCategories.sfx = [];
    if (!state.deletedCategories.music) state.deletedCategories.music = [];
    if (!state.items) state.items = [];
    for (var pi = 0; pi < state.items.length; pi++) {
      if (!state.items[pi].primaryCategory) state.items[pi].primaryCategory = "未分类";
      if (!state.items[pi].category) state.items[pi].category = "未分类";
    }

    cleanMissingItems(false);
    updateSaveStatus();
  }

  function migrateState(oldState) {
    var next = oldState;
    if (!next.version || next.version < 3) {
      next.version = 3;
      next.currentType = next.currentType || "sfx";

      if (typeof next.selectedCategory === "string") {
        next.selectedCategory = { sfx: next.selectedCategory || "全部", music: "全部" };
      } else if (!next.selectedCategory) {
        next.selectedCategory = { sfx: "全部", music: "全部" };
      }

      next.customPrimaryCategories = next.customPrimaryCategories || [];
      next.deletedPrimaryCategories = next.deletedPrimaryCategories || { sfx: [], music: [] };
      if (!next.deletedPrimaryCategories.sfx) next.deletedPrimaryCategories.sfx = [];
      if (!next.deletedPrimaryCategories.music) next.deletedPrimaryCategories.music = [];
      next.selectedPrimaryCategory = next.selectedPrimaryCategory || { sfx: "全部", music: "全部" };

      next.customCategories = next.customCategories || [];
      next.deletedCategories = next.deletedCategories || { sfx: [], music: [] };
      if (!next.deletedCategories.sfx) next.deletedCategories.sfx = [];
      if (!next.deletedCategories.music) next.deletedCategories.music = [];

      for (var i = 0; i < next.items.length; i++) {
        if (!next.items[i].type) next.items[i].type = "sfx";
        if (!next.items[i].primaryCategory) next.items[i].primaryCategory = "未分类";
      }
    }
    return next;
  }

  function saveState() {
    ensureDir(LIB_DIR);
    ensureDir(MEDIA_DIR);
    fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2), "utf8");
    updateSaveStatus();
  }

  function updateSaveStatus() {
    var html = "保存到：<br>" + escapeHtml(normalizeSlashes(LIB_DIR));
    if (!isSamePath(LIB_DIR, DEFAULT_LIB_DIR)) {
      html += "<br><span class='muted'>已自定义路径</span>";
    }
    $("saveStatus").innerHTML = html;
  }

  function getTypeInfo(type) {
    return LIB_TYPES[type || state.currentType] || LIB_TYPES.sfx;
  }

  function getCurrentType() {
    return state.currentType || "sfx";
  }

  function getCurrentLabel() {
    return getTypeInfo(getCurrentType()).label;
  }

  function getCurrentCategory() {
    var t = getCurrentType();
    return state.selectedCategory[t] || "全部";
  }

  function setCurrentCategory(cat) {
    var t = getCurrentType();
    state.selectedCategory[t] = cat || "全部";
  }

  function getCurrentPrimaryCategory() {
    var t = getCurrentType();
    if (!state.selectedPrimaryCategory) state.selectedPrimaryCategory = { sfx: "全部", music: "全部" };
    return state.selectedPrimaryCategory[t] || "全部";
  }

  function setCurrentPrimaryCategory(cat) {
    var t = getCurrentType();
    if (!state.selectedPrimaryCategory) state.selectedPrimaryCategory = { sfx: "全部", music: "全部" };
    state.selectedPrimaryCategory[t] = cat || "全部";
    state.selectedCategory[t] = "全部";
  }

  function getDeletedPrimaryCategories(type) {
    type = type || getCurrentType();
    if (!state.deletedPrimaryCategories) state.deletedPrimaryCategories = { sfx: [], music: [] };
    if (!state.deletedPrimaryCategories[type]) state.deletedPrimaryCategories[type] = [];
    return state.deletedPrimaryCategories[type];
  }

  function isProtectedPrimaryCategory(cat) {
    // v4.8.3：一级分类不再存在「未分类」。
    // 「未分类」只允许作为二级分类标签使用。
    return cat === "全部";
  }

  function getPrimaryCategories(type) {
    type = type || getCurrentType();

    // v4.8.3：一级分类列表不显示「未分类」。
    // 未识别的素材进入「当前一级分类 / 未分类」。
    var defaults = (getTypeInfo(type).primaryDefaults || ["全部", "短剧", "宣传片", "广告片"]).slice();
    var deleted = getDeletedPrimaryCategories(type);
    var result = [];

    for (var d = 0; d < defaults.length; d++) {
      var cat = defaults[d];
      if (!cat || cat === "未分类") continue;
      if (deleted.indexOf(cat) < 0 || isProtectedPrimaryCategory(cat)) {
        if (result.indexOf(cat) < 0) result.push(cat);
      }
    }

    var custom = state.customPrimaryCategories || [];
    for (var i = 0; i < custom.length; i++) {
      if (!custom[i] || custom[i] === "未分类") continue;
      if (deleted.indexOf(custom[i]) < 0 && result.indexOf(custom[i]) < 0) result.push(custom[i]);
    }

    // 旧版本已有素材所在的一级分类也会自动显示，但过滤掉一级「未分类」。
    for (var k = 0; k < state.items.length; k++) {
      var itemPrimary = state.items[k] && state.items[k].type === type ? (state.items[k].primaryCategory || "") : "";
      if (!itemPrimary || itemPrimary === "未分类") continue;
      if (deleted.indexOf(itemPrimary) < 0 && result.indexOf(itemPrimary) < 0) result.push(itemPrimary);
    }

    if (result.indexOf("全部") < 0) result.unshift("全部");
    return result;
  }

  function getDefaultPrimaryCategory(type) {
    type = type || getCurrentType();
    var cats = getPrimaryCategories(type);
    for (var i = 0; i < cats.length; i++) {
      if (cats[i] && cats[i] !== "全部" && cats[i] !== "未分类") return cats[i];
    }
    return "短剧";
  }

  function getImportPrimaryCategory() {
    var p = getCurrentPrimaryCategory();
    if (!p || p === "全部" || p === "未分类") return getDefaultPrimaryCategory();
    return p;
  }

  function getImportSecondaryCategory() {
    var c = getCurrentCategory();
    if (!c || c === "全部") return "未分类";
    return c;
  }

  function ensurePrimaryCategoryExists(cat) {
    if (!cat || isProtectedPrimaryCategory(cat)) return;
    if (!state.customPrimaryCategories) state.customPrimaryCategories = [];
    if (getPrimaryCategories(getCurrentType()).indexOf(cat) < 0 && state.customPrimaryCategories.indexOf(cat) < 0) {
      state.customPrimaryCategories.push(cat);
    }
  }

  function ensureSecondaryCategoryExists(cat, type) {
    type = type || getCurrentType();
    cat = String(cat || "").trim();

    if (!cat || isProtectedCategory(cat)) return false;

    if (!state.customCategories) state.customCategories = [];
    if (!state.deletedCategories) state.deletedCategories = { sfx: [], music: [] };
    if (!state.deletedCategories[type]) state.deletedCategories[type] = [];

    // v4.8.6：如果这个二级标签之前被删除过，重新自动分类点击「创建并分类」时，
    // 必须先从 deletedCategories 里移除，否则即使 push 到 customCategories 也不会显示。
    var deleted = state.deletedCategories[type];
    for (var d = deleted.length - 1; d >= 0; d--) {
      if (deleted[d] === cat) deleted.splice(d, 1);
    }

    if (state.customCategories.indexOf(cat) < 0) {
      state.customCategories.push(cat);
    }

    return true;
  }

  function resolveTargetPrimaryForImport(src, type, opts) {
    opts = opts || {};
    var targetPrimary = opts.targetPrimaryCategory || getImportPrimaryCategory();

    // v4.8.1: 如果你当前在某个一级分类里导入，就锁定到这个一级分类。
    // 例如当前在「短剧」里导入，素材只能进「短剧 / 二级分类」，不会跑到一级「未分类」。
    if (targetPrimary && targetPrimary !== "全部") {
      return targetPrimary;
    }

    if (opts.autoClassifyByName) {
      var byFile = primaryCategoryFromFileName(src, type);
      if (byFile && byFile.category && byFile.category !== "未分类") return byFile.category;
    }

    return "未分类";
  }

  function primaryCategoryFromFileName(filePath, type) {
    type = type || getCurrentType();
    var name = path.basename(filePath).toLowerCase();
    var cats = getPrimaryCategories(type);
    var best = { category: "未分类", score: 0 };

    for (var i = 0; i < cats.length; i++) {
      var cat = cats[i];
      if (!cat || cat === "全部" || cat === "未分类") continue;
      var c = String(cat).toLowerCase();
      if (name.indexOf(c) >= 0 && c.length > best.score) {
        best = { category: cat, score: c.length };
      }
    }

    return best;
  }

  function secondaryCategoryFromFileName(filePath, type) {
    type = type || getCurrentType();
    var byName = keywordClassify(path.basename(filePath), type);
    if (byName && byName.score > 0) {
      return {
        category: byName.category,
        confidence: Math.min(0.95, 0.45 + byName.score * 0.12),
        reason: "按文件名自动分类：" + byName.hits.join(" / ")
      };
    }
    return {
      category: "未分类",
      confidence: 0,
      reason: "文件名未命中分类关键词，放入未分类"
    };
  }

  function extraKeywordClassify(filename, type) {
    type = type || getCurrentType();
    var lower = String(filename || "").toLowerCase();
    var dict = (RECLASSIFY_EXTRA_KEYWORDS[type] || RECLASSIFY_EXTRA_KEYWORDS.sfx || {});
    var best = { category: "未分类", score: 0, hits: [] };

    for (var cat in dict) {
      if (!dict.hasOwnProperty(cat)) continue;

      var score = 0;
      var hits = [];
      for (var i = 0; i < dict[cat].length; i++) {
        var kw = String(dict[cat][i] || "").toLowerCase();
        if (kw && lower.indexOf(kw) >= 0) {
          score += kw.length > 2 ? 2 : 1;
          hits.push(dict[cat][i]);
        }
      }

      if (score > best.score) {
        best = { category: cat, score: score, hits: hits };
      }
    }

    return best;
  }

  function secondaryCategoryForReclassify(item, type) {
    type = type || getCurrentType();

    var name = item
      ? (item.originalName || item.name || path.basename(item.path || ""))
      : "";

    var byKnown = secondaryCategoryFromFileName(name, type);
    if (byKnown && byKnown.category && byKnown.category !== "未分类") {
      return byKnown;
    }

    var byExtra = extraKeywordClassify(name, type);
    if (byExtra && byExtra.score > 0) {
      return {
        category: byExtra.category,
        confidence: Math.min(0.95, 0.45 + byExtra.score * 0.12),
        reason: "重新自动分类命中扩展标签：" + byExtra.hits.join(" / ")
      };
    }

    return {
      category: "未分类",
      confidence: 0,
      reason: "文件名未命中二级分类关键词，放入未分类"
    };
  }

  function resolveImportClassify(src, type, opts) {
    opts = opts || {};

    var targetPrimary = resolveTargetPrimaryForImport(src, type, opts);
    if (!targetPrimary || targetPrimary === "全部") targetPrimary = "未分类";

    if (opts.autoClassifyByName) {
      var secondary = secondaryCategoryFromFileName(src, type);
      var category = secondary.category || "未分类";

      return Promise.resolve({
        primaryCategory: targetPrimary,
        category: category,
        confidence: secondary.confidence || 0,
        reason: "导入到一级分类「" + targetPrimary + "」；" + secondary.reason,
        features: { duration: 0 }
      });
    }

    var manualCategory = opts.targetCategory || getImportSecondaryCategory();
    if (!manualCategory || manualCategory === "全部") manualCategory = "未分类";

    return Promise.resolve({
      primaryCategory: targetPrimary,
      category: manualCategory,
      confidence: 0,
      reason: "未启用自动分类，导入到「" + targetPrimary + " / " + manualCategory + "」",
      features: { duration: 0 }
    });
  }

  function canDeletePrimaryCategory(cat) {
    return cat && !isProtectedPrimaryCategory(cat);
  }

  function getDeletedCategories(type) {
    type = type || getCurrentType();
    if (!state.deletedCategories) state.deletedCategories = { sfx: [], music: [] };
    if (!state.deletedCategories[type]) state.deletedCategories[type] = [];
    return state.deletedCategories[type];
  }

  function isProtectedCategory(cat) {
    return cat === "全部" || cat === "未分类";
  }

  function getCategories(type) {
    type = type || getCurrentType();
    var defaults = getTypeInfo(type).defaults.slice();
    var deleted = getDeletedCategories(type);
    var result = [];

    for (var d = 0; d < defaults.length; d++) {
      var cat = defaults[d];
      if (deleted.indexOf(cat) < 0 || isProtectedCategory(cat)) {
        if (result.indexOf(cat) < 0) result.push(cat);
      }
    }

    var custom = state.customCategories || [];
    for (var i = 0; i < custom.length; i++) {
      if (deleted.indexOf(custom[i]) < 0 && result.indexOf(custom[i]) < 0) {
        result.push(custom[i]);
      }
    }

    if (result.indexOf("全部") < 0) result.unshift("全部");
    if (result.indexOf("未分类") < 0) result.splice(1, 0, "未分类");

    return result;
  }

  function isCustomCategory(cat) {
    return (state.customCategories || []).indexOf(cat) >= 0;
  }

  function canDeleteCategory(cat) {
    return !!cat && !isProtectedCategory(cat);
  }

  function isAudioFile(filePath) {
    return AUDIO_EXTS.indexOf(path.extname(filePath).toLowerCase()) >= 0;
  }

  function walkAudioFiles(dir) {
    var out = [];
    if (!fs.existsSync(dir)) return out;
    var entries = fs.readdirSync(dir);

    for (var i = 0; i < entries.length; i++) {
      var full = path.join(dir, entries[i]);
      var st;
      try { st = fs.statSync(full); } catch (e) { continue; }

      if (st.isDirectory()) {
        out = out.concat(walkAudioFiles(full));
      } else if (st.isFile() && isAudioFile(full)) {
        out.push(full);
      }
    }

    return out;
  }

  function fileUrl(filePath) {
    var fixed = normalizeSlashes(filePath);
    if (/^[a-zA-Z]:\//.test(fixed)) return "file:///" + encodeURI(fixed);
    return "file://" + encodeURI(fixed);
  }

  function formatDuration(seconds) {
    if (!seconds || isNaN(seconds)) return "--";
    var m = Math.floor(seconds / 60);
    var s = Math.floor(seconds % 60);
    return m + ":" + String(s).padStart(2, "0");
  }

  function prettySize(bytes) {
    if (!bytes && bytes !== 0) return "--";
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + " KB";
    return (bytes / 1024 / 1024).toFixed(1) + " MB";
  }

  function keywordClassify(filename, type) {
    type = type || getCurrentType();
    var lower = filename.toLowerCase();
    var dict = KEYWORDS[type] || KEYWORDS.sfx;
    var best = { category: "其他", score: 0, hits: [] };

    for (var cat in dict) {
      if (!dict.hasOwnProperty(cat)) continue;
      var score = 0;
      var hits = [];

      for (var i = 0; i < dict[cat].length; i++) {
        var kw = dict[cat][i];
        if (lower.indexOf(String(kw).toLowerCase()) >= 0) {
          score += kw.length > 2 ? 2 : 1;
          hits.push(kw);
        }
      }

      if (score > best.score) best = { category: cat, score: score, hits: hits };
    }

    return best;
  }

  function bufferToArrayBuffer(buffer) {
    return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
  }

  function analyzeAudioFeatures(filePath) {
    return new Promise(function (resolve) {
      var result = {
        duration: 0,
        rms: 0,
        peak: 0,
        peakPosition: 0,
        riseRatio: 1,
        zeroCrossRate: 0,
        suggestedByAudio: ""
      };

      try {
        var AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return resolve(result);

        var buffer = fs.readFileSync(filePath);
        var audioCtx = new AudioCtx();

        audioCtx.decodeAudioData(bufferToArrayBuffer(buffer), function (audioBuffer) {
          try {
            var data = audioBuffer.getChannelData(0);
            var len = data.length;
            var stride = Math.max(1, Math.floor(len / 60000));
            var sumSq = 0;
            var peak = 0;
            var peakIndex = 0;
            var zeroCross = 0;
            var prev = data[0] || 0;
            var firstSq = 0;
            var firstN = 0;
            var lastSq = 0;
            var lastN = 0;

            for (var i = 0; i < len; i += stride) {
              var v = data[i];
              var av = Math.abs(v);
              sumSq += v * v;

              if (av > peak) {
                peak = av;
                peakIndex = i;
              }

              if ((v >= 0 && prev < 0) || (v < 0 && prev >= 0)) zeroCross++;
              prev = v;

              if (i < len * 0.35) {
                firstSq += v * v;
                firstN++;
              }

              if (i > len * 0.65) {
                lastSq += v * v;
                lastN++;
              }
            }

            var sampleCount = Math.ceil(len / stride);
            var rms = Math.sqrt(sumSq / Math.max(1, sampleCount));
            var firstRms = Math.sqrt(firstSq / Math.max(1, firstN));
            var lastRms = Math.sqrt(lastSq / Math.max(1, lastN));
            var riseRatio = lastRms / Math.max(firstRms, 0.00001);

            result.duration = audioBuffer.duration;
            result.rms = rms;
            result.peak = peak;
            result.peakPosition = peakIndex / len;
            result.riseRatio = riseRatio;
            result.zeroCrossRate = zeroCross / Math.max(1, sampleCount);

            if (result.duration > 0.8 && result.duration < 8 && riseRatio > 1.65) {
              result.suggestedByAudio = "上升";
            } else if (result.duration < 2.8 && peak > 0.78 && rms > 0.08) {
              result.suggestedByAudio = "重音";
            } else if (result.duration < 4.5 && result.peakPosition > 0.55 && peak > 0.65) {
              result.suggestedByAudio = "结尾";
            } else if (result.duration < 1.8 && result.zeroCrossRate > 0.23) {
              result.suggestedByAudio = "幽默";
            }
          } catch (inner) {
            log("audio feature parse failed: " + inner);
          }
          resolve(result);
        }, function () {
          resolve(result);
        });
      } catch (e) {
        log("audio feature analyze failed: " + e);
        resolve(result);
      }
    });
  }

  function classifySound(filePath, type) {
    type = type || getCurrentType();
    var name = path.basename(filePath);
    var byName = keywordClassify(name, type);

    return analyzeAudioFeatures(filePath).then(function (features) {
      var category = byName.score > 0 ? byName.category : "其他";
      var confidence = Math.min(0.95, 0.45 + byName.score * 0.12);
      var reason = byName.hits.length ? ("文件名命中：" + byName.hits.join(" / ")) : "未命中文件名关键词";

      if (type === "sfx") {
        if (features.suggestedByAudio && byName.score === 0) {
          category = features.suggestedByAudio;
          confidence = 0.58;
          reason = "音频特征推断：" + features.suggestedByAudio;
        } else if (features.suggestedByAudio && features.suggestedByAudio === byName.category) {
          confidence = Math.min(0.98, confidence + 0.18);
          reason += "；音频特征吻合";
        }
      } else {
        if (byName.score === 0 && features.duration > 20) {
          category = "短剧BGM";
          confidence = 0.52;
          reason = "音乐时长特征推断：短剧BGM";
        }
      }

      return {
        category: category,
        confidence: confidence,
        reason: reason,
        features: features
      };
    });
  }

  function getTypeBaseDir(type) {
    return path.join(MEDIA_DIR, getTypeInfo(type).folder);
  }

  function makeDestPath(srcPath, type, category, primaryCategory, forcedBaseName) {
    var ext = path.extname(srcPath);
    var baseName = forcedBaseName ? safeName(forcedBaseName) : safeName(path.basename(srcPath, ext));
    primaryCategory = primaryCategory || getImportPrimaryCategory();
    if (primaryCategory === "全部") primaryCategory = "未分类";
    category = category || "未分类";
    var catDir = path.join(getTypeBaseDir(type), safeName(primaryCategory), safeName(category));
    ensureDir(catDir);

    var dest = path.join(catDir, baseName + ext.toLowerCase());
    var i = 2;
    while (fs.existsSync(dest)) {
      dest = path.join(catDir, baseName + "_" + i + ext.toLowerCase());
      i++;
    }
    return dest;
  }

  function itemFingerprint(filePath) {
    try {
      var st = fs.statSync(filePath);
      return path.basename(filePath).toLowerCase() + "|" + st.size;
    } catch (e) {
      return path.basename(filePath).toLowerCase();
    }
  }

  function hasSameImported(srcPath, type) {
    var fp = itemFingerprint(srcPath);
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].type === type && state.items[i].fingerprint === fp) return true;
    }
    return false;
  }


  function importedNameExists(fileName, type) {
    fileName = String(fileName || "").toLowerCase();
    type = type || getCurrentType();
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].type === type && String(state.items[i].originalName || state.items[i].name || "").toLowerCase() === fileName) return true;
      if (state.items[i].type === type && String(state.items[i].name || "").toLowerCase() === fileName) return true;
    }
    return false;
  }

  function duplicatedImportNames(audioFiles, type) {
    var out = [];
    var seen = {};
    var local = {};
    for (var i = 0; i < audioFiles.length; i++) {
      var name = path.basename(audioFiles[i]);
      var key = name.toLowerCase();
      local[key] = (local[key] || 0) + 1;
      if ((importedNameExists(name, type) || local[key] > 1) && !seen[key]) {
        seen[key] = true;
        out.push(name);
      }
    }
    return out;
  }

  function uniqueNameForImport(srcPath, type) {
    var ext = path.extname(srcPath).toLowerCase();
    var base = safeName(path.basename(srcPath, ext));
    var name = base + ext;
    if (!importedNameExists(name, type)) return { base: base, name: name };
    var i = 2;
    while (importedNameExists(base + "_" + i + ext, type)) i++;
    return { base: base + "_" + i, name: base + "_" + i + ext };
  }

  function collectPaths(inputPaths) {
    var audioFiles = [];

    for (var i = 0; i < inputPaths.length; i++) {
      var p = inputPaths[i];
      if (!p || !fs.existsSync(p)) continue;

      var st;
      try { st = fs.statSync(p); } catch (e) { continue; }

      if (st.isDirectory()) {
        audioFiles = audioFiles.concat(walkAudioFiles(p));
      } else if (st.isFile() && isAudioFile(p)) {
        audioFiles.push(p);
      }
    }

    var seen = {};
    var unique = [];
    for (var j = 0; j < audioFiles.length; j++) {
      var key = normalizeSlashes(audioFiles[j]).toLowerCase();
      if (!seen[key]) {
        seen[key] = true;
        unique.push(audioFiles[j]);
      }
    }
    return unique;
  }

  function showProgress(current, total, text) {
    $("progressBox").classList.remove("hidden");
    $("progressText").textContent = text || "正在导入…";
    $("progressNum").textContent = current + " / " + total;
    var pct = total ? Math.round(current / total * 100) : 0;
    $("progressBar").style.width = pct + "%";
  }

  function hideProgress() {
    $("progressBox").classList.add("hidden");
    $("progressBar").style.width = "0%";
  }

  function importAudioPaths(inputPaths, importOptions) {
    if (!requireAuthorized()) return;
    if (importing) {
      toast("正在导入中。");
      return;
    }

    var type = getCurrentType();
    var typeLabel = getTypeInfo(type).label;
    var audioFiles = collectPaths(inputPaths);
    importOptions = importOptions || {};

    // v4.8.1: 导入时锁定当前一级分类。
    // 当前在「短剧」里导入，就导入到「短剧」下面，再按文件名分二级分类。
    if (!importOptions.targetPrimaryCategory) importOptions.targetPrimaryCategory = getImportPrimaryCategory();
    if (!importOptions.targetCategory) importOptions.targetCategory = getImportSecondaryCategory();

    if (!audioFiles.length) {
      toast("没有识别到音频文件。");
      return;
    }

    if (!importOptions.duplicateMode) {
      var dupNames = duplicatedImportNames(audioFiles, type);
      if (dupNames.length) {
        openUiConfirm({
          title: "检测到重名素材",
          subtitle: "选择重复命名处理方式",
          message: "发现 " + dupNames.length + " 个重名素材：\n" + dupNames.slice(0, 12).join("\n") + (dupNames.length > 12 ? "\n..." : "") + "\n\n点「自动命名」：导入并自动加 _2、_3 区分。\n点「跳过重复」：重名素材不导入。",
          confirmText: "自动命名",
          cancelText: "跳过重复",
          onConfirm: function () {
            importOptions.duplicateMode = "rename";
            importAudioPaths(inputPaths, importOptions);
          },
          onCancel: function () {
            importOptions.duplicateMode = "skip";
            importAudioPaths(inputPaths, importOptions);
          }
        });
        return;
      }
      importOptions.duplicateMode = "skip";
    }

    importing = true;
    showProgress(0, audioFiles.length, "正在导入到「" + typeLabel + "」库…");

    var imported = 0;
    var skipped = 0;
    var failed = 0;
    var index = 0;

    function next() {
      if (index >= audioFiles.length) {
        saveState();
        cleanMissingItems(false);
        render();
        hideProgress();
        importing = false;
        toast("导入完成：新增 " + imported + "，跳过 " + skipped + "，失败 " + failed);
        return;
      }

      var src = audioFiles[index];
      index++;
      showProgress(index - 1, audioFiles.length, "正在分析：" + path.basename(src));

      var srcName = path.basename(src);
      var duplicateByName = importedNameExists(srcName, type);
      if (importOptions.duplicateMode === "skip" && (hasSameImported(src, type) || duplicateByName)) {
        skipped++;
        showProgress(index, audioFiles.length, "跳过重名文件：" + srcName);
        setTimeout(next, 10);
        return;
      }

      resolveImportClassify(src, type, importOptions).then(function (classify) {
        try {
          var primaryCategory = classify.primaryCategory || importOptions.targetPrimaryCategory || getDefaultPrimaryCategory(type);
          if (!primaryCategory || primaryCategory === "未分类" || primaryCategory === "全部") primaryCategory = getDefaultPrimaryCategory(type);
          var category = classify.category || importOptions.targetCategory || "未分类";

          ensurePrimaryCategoryExists(primaryCategory);
          ensureSecondaryCategoryExists(category);

          var forced = null;
          if (importOptions.duplicateMode === "rename" && importedNameExists(path.basename(src), type)) {
            forced = uniqueNameForImport(src, type).base;
          }
          var dest = makeDestPath(src, type, category, primaryCategory, forced);
          fs.copyFileSync(src, dest);
          var st = fs.statSync(dest);

          state.items.push({
            id: uid(),
            type: type,
            name: path.basename(dest),
            originalName: path.basename(src),
            path: dest,
            primaryCategory: primaryCategory,
            category: category,
            confidence: classify.confidence,
            reason: classify.reason,
            duration: (classify.features && classify.features.duration) || 0,
            size: st.size,
            fingerprint: itemFingerprint(src),
            addedAt: new Date().toISOString(),
            source: "copied"
          });

          imported++;
          saveState();
          render();
        } catch (e) {
          failed++;
          log("import failed: " + src + " / " + e);
        }

        showProgress(index, audioFiles.length, "正在保存到「" + typeLabel + "」库…");
        setTimeout(next, 10);
      });
    }

    next();
  }

  function openDialog(chooseDirectory) {
    if (!requireAuthorized()) return;
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialogEx) {
      toast("文件选择接口不可用，请直接拖入文件。");
      return;
    }

    var types = ["wav", "mp3", "aif", "aiff", "m4a", "ogg", "flac"];
    var result = window.cep.fs.showOpenDialogEx(
      true,
      chooseDirectory,
      chooseDirectory ? "选择音频文件夹" : "选择音频文件",
      "",
      types,
      "Audio",
      chooseDirectory ? "选择文件夹" : "添加"
    );

    if (result && result.err === 0 && result.data && result.data.length) {
      askImportModeAndImport(result.data);
    }
  }

  function getPrimaryCounts() {
    var type = getCurrentType();
    var counts = {};
    var cats = getPrimaryCategories(type);
    for (var i = 0; i < cats.length; i++) counts[cats[i]] = 0;

    for (var j = 0; j < state.items.length; j++) {
      var item = state.items[j];
      if (item.type !== type) continue;
      var p = item.primaryCategory || getDefaultPrimaryCategory(type);
      if (p === "未分类") p = getDefaultPrimaryCategory(type);
      counts["全部"] = (counts["全部"] || 0) + 1;
      counts[p] = (counts[p] || 0) + 1;
    }
    return counts;
  }

  function getCounts() {
    var type = getCurrentType();
    var primary = getCurrentPrimaryCategory();
    var counts = {};
    var cats = getCategories(type);

    for (var i = 0; i < cats.length; i++) counts[cats[i]] = 0;

    for (var j = 0; j < state.items.length; j++) {
      var item = state.items[j];
      if (item.type !== type) continue;

      // v4.8.4：二级分类统计也要兼容旧数据。
      // 旧版本可能把 item.primaryCategory 写成一级「未分类」；
      // v4.8.3 已经在列表和一级统计里做了映射，但这里漏了，所以二级标签显示 0。
      var itemPrimary = item.primaryCategory || getDefaultPrimaryCategory(type);
      if (itemPrimary === "未分类" || itemPrimary === "全部") {
        itemPrimary = getDefaultPrimaryCategory(type);
      }

      if (primary !== "全部" && itemPrimary !== primary) continue;

      var cat = item.category || "未分类";
      if (!cat || cat === "全部") cat = "未分类";

      counts["全部"] = (counts["全部"] || 0) + 1;
      counts[cat] = (counts[cat] || 0) + 1;
    }

    return counts;
  }

  function filteredItems() {
    var type = getCurrentType();
    var q = $("searchInput").value.trim().toLowerCase();
    var primary = getCurrentPrimaryCategory();
    var cat = getCurrentCategory();
    var list = [];

    for (var i = 0; i < state.items.length; i++) {
      var item = state.items[i];
      if (item.type !== type) continue;

      var itemPrimary = item.primaryCategory || getDefaultPrimaryCategory(type);
      if (itemPrimary === "未分类") itemPrimary = getDefaultPrimaryCategory(type);
      var matchPrimary = primary === "全部" || itemPrimary === primary;
      var matchCat = cat === "全部" || item.category === cat;
      var text = (item.name + " " + item.originalName + " " + itemPrimary + " " + item.category + " " + item.reason + " " + type).toLowerCase();
      var matchQ = !q || text.indexOf(q) >= 0;

      if (matchPrimary && matchCat && matchQ && fs.existsSync(item.path)) {
        list.push(item);
      }
    }

    var sort = $("sortSelect").value || "timeDesc";

    function sortTime(item) {
      return String(item.addedAt || item.createdAt || "");
    }

    function sortName(item) {
      return String(item.name || item.originalName || "");
    }

    function sortCategory(item) {
      return String((item.primaryCategory || "未分类") + "/" + (item.category || ""));
    }

    list.sort(function (a, b) {
      if (sort === "timeAsc") {
        return sortTime(a).localeCompare(sortTime(b)) || sortName(a).localeCompare(sortName(b), "zh-CN");
      }

      if (sort === "timeDesc") {
        return sortTime(b).localeCompare(sortTime(a)) || sortName(a).localeCompare(sortName(b), "zh-CN");
      }

      if (sort === "nameAsc") {
        return sortName(a).localeCompare(sortName(b), "zh-CN", { numeric: true, sensitivity: "base" });
      }

      if (sort === "nameDesc") {
        return sortName(b).localeCompare(sortName(a), "zh-CN", { numeric: true, sensitivity: "base" });
      }

      if (sort === "categoryAsc") {
        return sortCategory(a).localeCompare(sortCategory(b), "zh-CN", { numeric: true, sensitivity: "base" }) ||
          sortName(a).localeCompare(sortName(b), "zh-CN", { numeric: true, sensitivity: "base" });
      }

      if (sort === "categoryDesc") {
        return sortCategory(b).localeCompare(sortCategory(a), "zh-CN", { numeric: true, sensitivity: "base" }) ||
          sortName(a).localeCompare(sortName(b), "zh-CN", { numeric: true, sensitivity: "base" });
      }

      return sortTime(b).localeCompare(sortTime(a));
    });

    return list;
  }

  function setHome() {
    setCurrentPrimaryCategory("全部");
    setCurrentCategory("全部");
    saveState();
    render();
  }

  function switchType(type) {
    if (!LIB_TYPES[type]) return;
    state.currentType = type;
    selectedId = null;
    selectedIds = {};
    $("audioPlayer").pause();
    $("audioPlayer").removeAttribute("src");
    $("nowPlaying").textContent = "未选择";
    saveState();
    render();
  }

  function createCustomPrimaryCategory(nameFromPrompt) {
    var input = $("customPrimaryInput");
    var raw = nameFromPrompt || (input ? input.value.trim() : "");
    if (!raw) {
      openUiPrompt({
        title: "新增一级分类",
        subtitle: "项目类型 / 视频类型",
        message: "请输入新的一级分类名称。\n例如：短剧、宣传片、广告片、纪录片。",
        placeholder: "例如：宣传片",
        confirmText: "添加分类",
        hint: "一级分类用于区分不同视频制作项目。",
        emptyText: "一级分类名称不能为空。",
        onConfirm: function (value) { createCustomPrimaryCategory(value); }
      });
      return;
    }
    if (!raw) {
      toast("先输入一级分类名称。");
      return;
    }

    var name = safeName(raw);
    if (!name || name === "全部") {
      toast("一级分类名不可用。");
      return;
    }

    var restored = false;
    ["sfx", "music"].forEach(function (type) {
      var deleted = getDeletedPrimaryCategories(type);
      var idx = deleted.indexOf(name);
      if (idx >= 0) {
        deleted.splice(idx, 1);
        restored = true;
      }
    });

    if (!restored) {
      if (getPrimaryCategories("sfx").indexOf(name) >= 0 || getPrimaryCategories("music").indexOf(name) >= 0) {
        toast("这个一级分类已经存在。");
        return;
      }
      state.customPrimaryCategories.push(name);
    }

    if (input) input.value = "";
    saveState();
    render();
    toast(restored ? ("已恢复一级分类：" + name) : ("已创建一级分类，并同步到音效/音乐：" + name));
  }

  function addPrimaryCategoryQuick() {
    createCustomPrimaryCategory();
  }

  function deleteCurrentPrimaryCategoryQuick() {
    deletePrimaryCategory(getCurrentPrimaryCategory());
  }

  function deletePrimaryCategory(cat) {
    if (!canDeletePrimaryCategory(cat)) {
      toast("「全部」和「未分类」不能删除。");
      return;
    }

    var type = getCurrentType();
    var count = 0;
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].type === type && (state.items[i].primaryCategory || "短剧") === cat) count++;
    }

    openUiConfirm({
      title: "删除一级分类",
      subtitle: "只删除目录，不删除音频文件",
      message: "确定删除一级分类「" + cat + "」吗？\n\n这个一级分类里的 " + count + " 个素材会移动到「" + getDefaultPrimaryCategory(type) + " / 未分类」。",
      confirmText: "确认删除",
      cancelText: "取消",
      onConfirm: function () {
        var deleted = getDeletedPrimaryCategories(type);
        if (deleted.indexOf(cat) < 0) deleted.push(cat);
        var moved = 0;
        for (var j = 0; j < state.items.length; j++) {
          var item = state.items[j];
          if (item.type === type && (item.primaryCategory || "未分类") === cat) {
            if (moveItemToCategoryNoRender(item, "未分类", getDefaultPrimaryCategory(type))) moved++;
          }
        }
        if (state.selectedPrimaryCategory[type] === cat) state.selectedPrimaryCategory[type] = getDefaultPrimaryCategory(type);
        state.selectedCategory[type] = "全部";
        saveState();
        render();
        toast("已删除一级分类，移动素材：" + moved + " 个");
      }
    });
  }

  function renamePrimaryCategory(cat) {
    if (!canDeletePrimaryCategory(cat)) {
      toast("「全部」和「未分类」不能改名。");
      return;
    }

    openUiPrompt({
      title: "重命名一级分类",
      subtitle: "当前分类：「" + cat + "」",
      message: "请输入新的一级分类名称。",
      value: cat,
      placeholder: "新的一级分类名称",
      confirmText: "确认改名",
      hint: "改名后，此分类下的素材会同步更新到新分类。",
      onConfirm: function (raw) {
        var name = safeName(raw);
        renamePrimaryCategoryApply(cat, name);
      }
    });
    return;
  }

  function renamePrimaryCategoryApply(cat, name) {
    if (!name || name === "全部" || name === "未分类") {
      toast("一级分类名不可用。");
      return;
    }
    if (name === cat) return;
    if (getPrimaryCategories("sfx").indexOf(name) >= 0 || getPrimaryCategories("music").indexOf(name) >= 0) {
      toast("这个一级分类已经存在。");
      return;
    }

    var type = getCurrentType();
    var moved = 0;
    for (var i = 0; i < state.items.length; i++) {
      var item = state.items[i];
      if (item.type === type && (item.primaryCategory || "未分类") === cat) {
        if (moveItemToCategoryNoRender(item, item.category || "未分类", name)) moved++;
      }
    }

    var idx = state.customPrimaryCategories.indexOf(cat);
    if (idx >= 0) state.customPrimaryCategories[idx] = name;
    else if (state.customPrimaryCategories.indexOf(name) < 0) state.customPrimaryCategories.push(name);

    var deleted = getDeletedPrimaryCategories(type);
    var dIdx = deleted.indexOf(cat);
    if (dIdx >= 0) deleted.splice(dIdx, 1);

    if (state.selectedPrimaryCategory[type] === cat) state.selectedPrimaryCategory[type] = name;
    saveState();
    render();
    toast("一级分类已改名：" + cat + " → " + name + "，移动素材：" + moved + " 个");
  }

  function createCustomCategory(nameFromPrompt) {
    var input = $("customCategoryInput");
    var raw = nameFromPrompt || (input ? input.value.trim() : "");
    if (!raw) {
      openUiPrompt({
        title: "新增二级分类",
        subtitle: "声音情绪 / 用途",
        message: "请输入新的二级分类名称。\n例如：悬疑、重音、反转、上升、结尾、幽默。",
        placeholder: "例如：反转",
        confirmText: "添加分类",
        hint: "二级分类用于区分具体声音用途。",
        emptyText: "二级分类名称不能为空。",
        onConfirm: function (value) { createCustomCategory(value); }
      });
      return;
    }
    if (!raw) {
      toast("先输入二级分类名称。");
      return;
    }

    var name = safeName(raw);
    if (!name || name === "全部") {
      toast("二级分类名不可用。");
      return;
    }

    var restored = false;
    ["sfx", "music"].forEach(function (type) {
      var deleted = getDeletedCategories(type);
      var idx = deleted.indexOf(name);
      if (idx >= 0) {
        deleted.splice(idx, 1);
        restored = true;
      }
    });

    if (!restored) {
      if (getCategories("sfx").indexOf(name) >= 0 || getCategories("music").indexOf(name) >= 0) {
        toast("这个二级分类已经存在。");
        return;
      }

      state.customCategories.push(name);
    }

    if ($("customCategoryInput")) $("customCategoryInput").value = "";
    saveState();
    render();
    toast(restored ? ("已恢复二级分类：" + name) : ("已创建二级分类，并同步到音效/音乐：" + name));
  }

  function addSecondaryCategoryQuick() {
    createCustomCategory();
  }

  function deleteCurrentSecondaryCategoryQuick() {
    deleteCustomCategory(getCurrentCategory());
  }

  function deleteCustomCategory(cat) {
    if (!canDeleteCategory(cat)) {
      toast("「全部」和「未分类」不能删除。");
      return;
    }

    var type = getCurrentType();
    var typeLabel = getTypeInfo(type).label;

    var count = 0;
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].type === type && state.items[i].category === cat) count++;
    }

    var msg = "确定删除「" + typeLabel + "」里的分类「" + cat + "」吗？";
    if (count > 0) {
      msg += "\n\n这个分类里的 " + count + " 个素材会移动到「未分类」。";
    }
    msg += "\n\n注意：只删除分类目录，不删除音频文件。";

    openUiConfirm({
      title: "删除二级分类",
      subtitle: "此操作不会删除原始音频文件",
      message: msg,
      confirmText: "确认删除",
      cancelText: "取消",
      onConfirm: function () {
        var deleted = getDeletedCategories(type);
        if (deleted.indexOf(cat) < 0) deleted.push(cat);

        var moved = 0;
        for (var j = 0; j < state.items.length; j++) {
          var item = state.items[j];
          if (item.type === type && item.category === cat) {
            if (moveItemToCategoryNoRender(item, "未分类")) {
              item.reason = "原分类被删除，自动移动到未分类";
              moved++;
            }
          }
        }

        if (state.selectedCategory[type] === cat) state.selectedCategory[type] = "未分类";

        saveState();
        render();
        toast("已删除分类「" + cat + "」，移动到未分类：" + moved + " 个");
      }
    });
  }

  function renameSecondaryCategory(cat) {
    if (!canDeleteCategory(cat)) {
      toast("「全部」和「未分类」不能改名。");
      return;
    }

    openUiPrompt({
      title: "重命名二级分类",
      subtitle: "当前分类：「" + cat + "」",
      message: "请输入新的二级分类名称。",
      value: cat,
      placeholder: "新的二级分类名称",
      confirmText: "确认改名",
      hint: "改名后，此分类下的素材会同步更新到新分类。",
      onConfirm: function (raw) {
        var name = safeName(raw);
        renameSecondaryCategoryApply(cat, name);
      }
    });
    return;
  }

  function renameSecondaryCategoryApply(cat, name) {
    if (!name || name === "全部" || name === "未分类") {
      toast("二级分类名不可用。");
      return;
    }
    if (name === cat) return;
    if (getCategories("sfx").indexOf(name) >= 0 || getCategories("music").indexOf(name) >= 0) {
      toast("这个二级分类已经存在。");
      return;
    }

    var type = getCurrentType();
    var moved = 0;
    for (var i = 0; i < state.items.length; i++) {
      var item = state.items[i];
      if (item.type === type && (item.category || "未分类") === cat) {
        if (moveItemToCategoryNoRender(item, name, item.primaryCategory || "未分类")) moved++;
      }
    }

    var idx = state.customCategories.indexOf(cat);
    if (idx >= 0) state.customCategories[idx] = name;
    else if (state.customCategories.indexOf(name) < 0) state.customCategories.push(name);

    var deleted = getDeletedCategories(type);
    if (!isProtectedCategory(cat) && deleted.indexOf(cat) < 0) deleted.push(cat);
    var nIdx = deleted.indexOf(name);
    if (nIdx >= 0) deleted.splice(nIdx, 1);

    if (state.selectedCategory[type] === cat) state.selectedCategory[type] = name;
    saveState();
    render();
    toast("二级分类已改名：" + cat + " → " + name + "，移动素材：" + moved + " 个");
  }

  function getSelectedIdsForCurrentType() {
    var type = getCurrentType();
    var ids = [];

    for (var id in selectedIds) {
      if (!selectedIds.hasOwnProperty(id) || !selectedIds[id]) continue;
      var item = getItem(id);
      if (item && item.type === type && item.path && fs.existsSync(item.path)) {
        ids.push(id);
      }
    }

    return ids;
  }

  function pruneSelection() {
    var type = getCurrentType();
    for (var id in selectedIds) {
      if (!selectedIds.hasOwnProperty(id)) continue;
      var item = getItem(id);
      if (!item || item.type !== type || !item.path || !fs.existsSync(item.path)) {
        delete selectedIds[id];
      }
    }
  }

  function updateBatchControls() {
    var select = $("batchCategorySelect");
    if (!select) return;

    pruneSelection();

    var type = getCurrentType();
    var cats = getCategories(type);
    var currentValue = select.value;
    var html = "";

    for (var i = 0; i < cats.length; i++) {
      var c = cats[i];
      if (c === "全部") continue;
      html += '<option value="' + escapeAttr(c) + '">' + escapeHtml(c) + '</option>';
    }

    select.innerHTML = html;

    if (currentValue && cats.indexOf(currentValue) >= 0 && currentValue !== "全部") {
      select.value = currentValue;
    }

    var selectedCount = getSelectedIdsForCurrentType().length;
    $("batchCount").textContent = selectedCount;
  }

  function setAssetBatchSelected(id, checked, shouldRender) {
    var item = getItem(id);
    if (!item || item.type !== getCurrentType()) return;

    if (checked) selectedIds[id] = true;
    else delete selectedIds[id];

    updateBatchControls();

    if (shouldRender !== false) {
      renderList();
      updateBatchControls();
    }
  }

  function toggleAssetBatchSelected(id, shouldRender) {
    setAssetBatchSelected(id, !selectedIds[id], shouldRender);
  }

  function selectCurrentList() {
    var items = filteredItems();
    for (var i = 0; i < items.length; i++) {
      selectedIds[items[i].id] = true;
    }
    render();
    toast("已选择当前列表：" + items.length + " 个");
  }

  function selectCurrentCategory() {
    var type = getCurrentType();
    var primary = getCurrentPrimaryCategory();
    var cat = getCurrentCategory();
    var count = 0;

    for (var i = 0; i < state.items.length; i++) {
      var item = state.items[i];
      if (item.type !== type) continue;
      if (!item.path || !fs.existsSync(item.path)) continue;
      var itemPrimary = item.primaryCategory || "未分类";
      if (primary !== "全部" && itemPrimary !== primary) continue;
      if (cat !== "全部" && item.category !== cat) continue;

      selectedIds[item.id] = true;
      count++;
    }

    render();
    toast("已选择当前分类：" + count + " 个");
  }

  function invertCurrentListSelection() {
    var items = filteredItems();
    for (var i = 0; i < items.length; i++) {
      var id = items[i].id;
      if (selectedIds[id]) delete selectedIds[id];
      else selectedIds[id] = true;
    }
    render();
    toast("已反选当前列表");
  }

  function clearSelection() {
    selectedIds = {};
    render();
    toast("已清空批量选择");
  }

  function moveItemToCategoryNoRender(item, newCategory, newPrimaryCategory) {
    if (!item) return false;
    newPrimaryCategory = newPrimaryCategory || item.primaryCategory || getImportPrimaryCategory();
    if (!newPrimaryCategory || newPrimaryCategory === "全部" || newPrimaryCategory === "未分类") {
      newPrimaryCategory = getDefaultPrimaryCategory(item.type || getCurrentType());
    }
    if (item.category === newCategory && (item.primaryCategory || "未分类") === newPrimaryCategory) {
      item.reason = "批量分类：分类未变化";
      item.confidence = 1;
      return true;
    }

    var oldPath = item.path;
    var dest = makeDestPath(item.path, item.type, newCategory, newPrimaryCategory);

    try {
      ensureDir(path.dirname(dest));
      fs.renameSync(oldPath, dest);
    } catch (e) {
      try {
        fs.copyFileSync(oldPath, dest);
        try { fs.unlinkSync(oldPath); } catch (_) {}
      } catch (copyErr) {
        log("batch move category failed: " + oldPath + " -> " + dest + " / " + copyErr);
        return false;
      }
    }

    item.path = dest;
    item.name = path.basename(dest);
    item.primaryCategory = newPrimaryCategory;
    item.category = newCategory;
    item.reason = "批量移动分类";
    item.confidence = 1;
    return true;
  }

  function getReclassifyTargetIds() {
    var ids = getSelectedIdsForCurrentType();

    // 如果没有勾选，但当前高亮选中了一个素材，也允许对单个素材重新分类。
    if (!ids.length && selectedId) {
      var one = getItem(selectedId);
      if (one && one.type === getCurrentType()) ids = [selectedId];
    }

    return ids;
  }

  function applyAutoReclassifyPlans(plans, targetPrimary, createMissing, missingMap) {
    var ok = 0;
    var failed = 0;
    var type = getCurrentType();
    var created = [];

    if (createMissing) {
      for (var cat in missingMap) {
        if (!missingMap.hasOwnProperty(cat)) continue;
        if (ensureSecondaryCategoryExists(cat, type)) created.push(cat);
      }
    }

    for (var i = 0; i < plans.length; i++) {
      var plan = plans[i];
      var item = plan.item;
      if (!item) {
        failed++;
        continue;
      }

      var cat = plan.category || "未分类";
      if (missingMap[cat] && !createMissing) cat = "未分类";

      if (!cat || cat === "全部") cat = "未分类";

      // v4.8.6：创建后再移动，保证二级分类列表能立刻看到新标签。
      if (cat !== "未分类" && createMissing) ensureSecondaryCategoryExists(cat, type);

      if (moveItemToCategoryNoRender(item, cat, targetPrimary)) {
        item.reason = "重新自动分类：" + (plan.reason || "");
        item.confidence = plan.confidence || 1;
        ok++;
        delete selectedIds[item.id];
      } else {
        failed++;
      }
    }

    saveState();
    render();

    if (created.length) {
      toast("已创建二级分类：" + created.join("、") + "；重新分类成功 " + ok + " 个");
    } else {
      toast("重新自动分类完成：成功 " + ok + "，失败 " + failed);
    }
  }

  function batchAutoClassifySelected() {
    if (!requireAuthorized()) return;
    updateBatchControls();

    var ids = getReclassifyTargetIds();
    if (!ids.length) {
      alert("还没有选择素材。\n\n请勾选素材，或者先点中一个素材卡片。");
      return;
    }

    var type = getCurrentType();
    var targetPrimary = getCurrentPrimaryCategory();

    if (!targetPrimary || targetPrimary === "全部" || targetPrimary === "未分类") {
      alert("请先在左侧选择一个具体的一级分类，再重新自动分类。\n\n例如：先点「短剧」，再勾选素材点击「重新自动分类」。");
      return;
    }

    var currentCats = getCategories(type);
    var missingMap = {};
    var plans = [];

    for (var i = 0; i < ids.length; i++) {
      var item = getItem(ids[i]);
      if (!item || item.type !== type) continue;

      var result = secondaryCategoryForReclassify(item, type);
      var cat = result.category || "未分类";
      if (!cat || cat === "全部") cat = "未分类";

      if (cat !== "未分类" && currentCats.indexOf(cat) < 0) {
        missingMap[cat] = true;
      }

      plans.push({
        item: item,
        category: cat,
        confidence: result.confidence || 0,
        reason: result.reason || ""
      });
    }

    if (!plans.length) {
      alert("没有找到可重新分类的素材。");
      return;
    }

    var missing = Object.keys(missingMap);
    var summary = {};
    for (var j = 0; j < plans.length; j++) {
      var pc = plans[j].category || "未分类";
      summary[pc] = (summary[pc] || 0) + 1;
    }

    var summaryLines = [];
    for (var key in summary) {
      if (summary.hasOwnProperty(key)) summaryLines.push(key + "：" + summary[key] + " 个");
    }

    if (missing.length) {
      openUiConfirm({
        title: "发现新的二级分类标签",
        subtitle: "当前一级分类：「" + targetPrimary + "」",
        message:
          "重新自动分类时，检测到这些二级分类还不存在：\n\n" +
          missing.join("、") +
          "\n\n是否自动创建这些二级分类，并把素材分进去？\n\n分类预览：\n" +
          summaryLines.join("\n") +
          "\n\n点「创建并分类」：自动新增二级分类。\n点「不创建」：这些新标签对应的素材会进入「未分类」。",
        confirmText: "创建并分类",
        cancelText: "不创建",
        onConfirm: function () {
          applyAutoReclassifyPlans(plans, targetPrimary, true, missingMap);
        },
        onCancel: function () {
          applyAutoReclassifyPlans(plans, targetPrimary, false, missingMap);
        }
      });
      return;
    }

    openUiConfirm({
      title: "重新自动分类",
      subtitle: "只在当前一级分类「" + targetPrimary + "」下重新分二级分类",
      message: "确定重新分类 " + plans.length + " 个素材吗？\n\n分类预览：\n" + summaryLines.join("\n"),
      confirmText: "确认分类",
      cancelText: "取消",
      onConfirm: function () {
        applyAutoReclassifyPlans(plans, targetPrimary, false, {});
      }
    });
  }

  function batchMoveSelected() {
    if (!requireAuthorized()) return;
    updateBatchControls();

    var ids = getSelectedIdsForCurrentType();
    if (!ids.length) {
      alert("还没有勾选素材。\n\n请点击素材卡片左上角的小方框进行批量选择。");
      return;
    }

    var target = $("batchCategorySelect").value;
    if (!target || target === "全部") {
      alert("请选择要移动到的目标分类。");
      return;
    }

    var typeLabel = getCurrentLabel();
    openUiConfirm({
      title: "批量分类",
      subtitle: "确认后会批量移动素材分类",
      message: "确定把「" + typeLabel + "」里已选择的 " + ids.length + " 个素材移动到「" + target + "」？",
      confirmText: "确认移动",
      cancelText: "取消",
      onConfirm: function () {
        var ok = 0;
        var failed = 0;

        for (var i = 0; i < ids.length; i++) {
          var item = getItem(ids[i]);
          if (!item) {
            failed++;
            continue;
          }

          var targetPrimary = getCurrentPrimaryCategory() === "全部" ? (item.primaryCategory || getDefaultPrimaryCategory(type)) : getCurrentPrimaryCategory();
          if (!targetPrimary || targetPrimary === "未分类" || targetPrimary === "全部") targetPrimary = getDefaultPrimaryCategory(type);
          if (moveItemToCategoryNoRender(item, target, targetPrimary)) {
            ok++;
            delete selectedIds[ids[i]];
          } else {
            failed++;
          }
        }

        saveState();
        render();
        toast("批量分类完成：成功 " + ok + "，失败 " + failed);
      }
    });
  }

  function renderTabs() {
    $("tabSfx").classList.toggle("active", getCurrentType() === "sfx");
    $("tabMusic").classList.toggle("active", getCurrentType() === "music");
  }

  function renderPrimaryCategories() {
    var type = getCurrentType();
    var cats = getPrimaryCategories(type);
    var counts = getPrimaryCounts();
    var current = getCurrentPrimaryCategory();
    var html = "";

    for (var i = 0; i < cats.length; i++) {
      var cat = cats[i];
      var active = cat === current ? " active" : "";
      html += '<div class="cat primary-cat' + active + '" data-primary-cat="' + escapeAttr(cat) + '">' +
        '<span class="cat-name">' + escapeHtml(cat) + '</span>' +
        '<span class="num">' + (counts[cat] || 0) + '</span>' +
      '</div>';
    }

    $("primaryCategoryList").innerHTML = html;
    var nodes = document.querySelectorAll(".primary-cat");
    for (var j = 0; j < nodes.length; j++) {
      nodes[j].addEventListener("click", function (e) {
        setCurrentPrimaryCategory(this.getAttribute("data-primary-cat"));
        saveState();
        render();
      });
      nodes[j].addEventListener("dblclick", function (e) {
        e.stopPropagation();
        renamePrimaryCategory(this.getAttribute("data-primary-cat"));
      });
    }
  }

  function normalizeCurrentPrimaryCategory() {
    var type = getCurrentType();
    var p = getCurrentPrimaryCategory();
    if (!p || p === "未分类" || getPrimaryCategories(type).indexOf(p) < 0) {
      state.selectedPrimaryCategory[type] = getDefaultPrimaryCategory(type);
    }
  }

  function renderCategories() {
    normalizeCurrentPrimaryCategory();
    renderPrimaryCategories();

    var type = getCurrentType();
    var cats = getCategories(type);
    var counts = getCounts();
    var current = getCurrentCategory();
    var html = "";

    for (var i = 0; i < cats.length; i++) {
      var cat = cats[i];

      // v4.8.5：二级分类左侧列表不再显示「全部」标签。
      // 「全部」仍作为内部筛选状态存在，点击一级分类时显示该一级分类下全部素材。
      if (cat === "全部") continue;

      var active = cat === current ? " active" : "";
      html += '<div class="cat secondary-cat' + active + '" data-cat="' + escapeAttr(cat) + '">' +
        '<span class="cat-name">' + escapeHtml(cat) + '</span>' +
        '<span class="num">' + (counts[cat] || 0) + '</span>' +
      '</div>';
    }

    $("categoryList").innerHTML = html;

    var catNodes = document.querySelectorAll(".secondary-cat");
    for (var j = 0; j < catNodes.length; j++) {
      catNodes[j].addEventListener("click", function (e) {
        setCurrentCategory(this.getAttribute("data-cat"));
        saveState();
        render();
      });
      catNodes[j].addEventListener("dblclick", function (e) {
        e.stopPropagation();
        renameSecondaryCategory(this.getAttribute("data-cat"));
      });
    }
  }

  function renderList() {
    var type = getCurrentType();
    var typeLabel = getTypeInfo(type).label;
    var items = filteredItems();
    var total = 0;

    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].type === type) total++;
    }

    $("countAll").textContent = total;
    $("countCurrent").textContent = items.length;
    $("currentCategory").textContent = getCurrentPrimaryCategory() + " / " + getCurrentCategory();

    var selected = getItem(selectedId);
    var batchNum = getSelectedIdsForCurrentType().length;
    $("countSelected").textContent = batchNum > 0 ? (batchNum + " 个已勾选") : (selected ? selected.name : "0");

    $("breadcrumb").textContent = typeLabel + " / " + getCurrentPrimaryCategory() + " / " + getCurrentCategory();
    $("dropTitle").textContent = "把" + typeLabel + "文件或文件夹直接拖进来。导入前会询问是否按文件名自动分类。⚡";

    if (!items.length) {
      $("soundList").innerHTML = '<div class="empty">当前没有素材。请把音频文件或文件夹直接拖进来。</div>';
      return;
    }

    var cats = getCategories(type);
    var html = "";

    for (var k = 0; k < items.length; k++) {
      var item = items[k];
      var checked = selectedIds[item.id] ? " checked" : "";
      var selectedClass = item.id === selectedId ? " selected" : "";
      if (selectedIds[item.id]) selectedClass += " multi-selected";

      var isPlayingThis = currentPreviewId === item.id && !$('audioPlayer').paused && !$('audioPlayer').ended;
      html += '<div class="card asset-row' + selectedClass + '" data-id="' + escapeAttr(item.id) + '">' +
        '<button class="row-btn row-play btn-play' + (isPlayingThis ? ' playing' : '') + '" data-action="play" title="' + (isPlayingThis ? '暂停' : '播放') + '">' + (isPlayingThis ? 'Ⅱ' : '▶') + '</button>' +
        '<button class="row-btn row-add btn-insert" data-action="insert" title="插入到轨道">＋</button>' +
        '<button class="row-btn row-remove btn-delete" data-action="delete" title="从素材库移除">×</button>' +
        '<div class="row-file-name" data-action="rename" title="双击重命名文件">' + escapeHtml(item.name) + '</div>' +
        '<select class="badge-select row-category" data-action="move" title="修改分类">' + categoryOptions(cats, item.category) + '</select>' +
        '<label class="row-check-wrap" title="批量勾选"><input class="asset-check" type="checkbox" data-action="check"' + checked + '></label>' +
      '</div>';
    }

    $("soundList").innerHTML = html;

    var cards = document.querySelectorAll(".card");
    for (var c = 0; c < cards.length; c++) {
      cards[c].addEventListener("click", function (e) {
        var id = this.getAttribute("data-id");
        var actionTarget = e.target;
        if (actionTarget && actionTarget.closest) {
          actionTarget = actionTarget.closest("[data-action]");
          if (actionTarget && !this.contains(actionTarget)) actionTarget = null;
        }
        var action = actionTarget ? actionTarget.getAttribute("data-action") : "";

        // v3.17: 只有行尾勾选框会触发批量选择。
        // 点击行空白处只设置当前选中素材，不再自动打勾。
        if (action === "check") {
          e.stopPropagation();
          setAssetBatchSelected(id, actionTarget.checked, true);
          return;
        }

        if (action === "play") {
          e.stopPropagation();
          selectedId = id;
          playAsset(id);
          renderList();
          return;
        }

        if (action === "insert") {
          e.stopPropagation();
          selectedId = id;
          insertAsset(id);
          renderList();
          return;
        }

        if (action === "delete") {
          e.stopPropagation();
          deleteAsset(id);
          return;
        }

        if (action === "rename") {
          e.stopPropagation();
          selectedId = id;
          renderList();
          return;
        }

        if (action === "move") {
          e.stopPropagation();
          return;
        }

        if (e.target.tagName === "SELECT" || e.target.tagName === "OPTION" || e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") {
          return;
        }

        selectedId = id;
        renderList();
        updateBatchControls();
      });

      var nameNode = cards[c].querySelector(".row-file-name");
      if (nameNode) {
        nameNode.addEventListener("dblclick", function (e) {
          e.stopPropagation();
          var card = this.closest(".card");
          if (!card) return;
          selectedId = card.getAttribute("data-id");
          renameAssetFile(selectedId);
        });
      }

      var select = cards[c].querySelector('select[data-action="move"]');
      if (select) {
        select.addEventListener("change", function (e) {
          e.stopPropagation();
          var card = this.closest(".card");
          moveCategory(card.getAttribute("data-id"), this.value);
        });
      }
    }
  }

  function normalizeAudioRenameInput(raw, oldName) {
    var oldExt = path.extname(oldName || "") || ".wav";
    var cleaned = safeName(raw || "");
    if (!cleaned) return "";

    var newExt = path.extname(cleaned);
    if (!newExt) {
      cleaned += oldExt;
    } else if (newExt.toLowerCase() !== oldExt.toLowerCase()) {
      cleaned = safeName(path.basename(cleaned, newExt)) + oldExt;
    }

    cleaned = safeName(cleaned);
    if (!cleaned || cleaned === oldExt) return "";
    return cleaned;
  }

  function renameAssetFile(id, nameFromPrompt) {
    var item = getItem(id);
    if (!item) return;

    var oldPath = item.path;
    var oldName = item.name || path.basename(oldPath || "");
    var oldDir = path.dirname(oldPath || "");
    if (!oldPath || !oldDir || !fs.existsSync(oldPath)) {
      alert("找不到原始音频文件，无法重命名：\n" + oldPath);
      return;
    }

    if (nameFromPrompt === undefined) {
      openUiPrompt({
        title: "重命名音频文件",
        subtitle: "会同步修改本地保存路径里的真实文件名",
        message: "请输入新的文件名。\n可以不写扩展名，系统会保留原来的音频格式。",
        value: oldName,
        placeholder: oldName,
        confirmText: "确认重命名",
        hint: "双击音频文件名即可打开这里。不会修改分类文件夹，只改文件名。",
        emptyText: "文件名不能为空。",
        onConfirm: function (value) { renameAssetFile(id, value); }
      });
      return;
    }

    var newName = normalizeAudioRenameInput(nameFromPrompt, oldName);
    if (!newName) {
      toast("文件名不可用。");
      return;
    }

    if (newName === oldName) {
      toast("文件名没有变化。");
      return;
    }

    var newPath = path.join(oldDir, newName);
    if (fs.existsSync(newPath) && normalizeSlashes(newPath).toLowerCase() !== normalizeSlashes(oldPath).toLowerCase()) {
      alert("同目录下已经有这个文件名：\n" + newName + "\n\n请换一个名字。");
      return;
    }

    var audio = $("audioPlayer");
    var wasCurrent = currentPreviewId === id;
    var wasPlaying = false;

    try {
      if (wasCurrent && audio) {
        wasPlaying = !audio.paused && !audio.ended;
        audio.pause();
        audio.removeAttribute("src");
        try { audio.load(); } catch (e) {}
      }

      fs.renameSync(oldPath, newPath);

      item.path = newPath;
      item.name = path.basename(newPath);
      saveState();

      if (wasCurrent && audio) {
        audio.src = fileUrl(item.path);
        $("nowPlaying").textContent = item.name;
        loadWaveformForItem(item);
        if (wasPlaying) {
          try { audio.play(); } catch (e) {}
        }
      }

      renderList();
      updateBatchControls();
      toast("已重命名：" + item.name);
    } catch (err) {
      alert("重命名失败：\n" + (err && err.message ? err.message : err));
      if (wasCurrent && audio && item && item.path && fs.existsSync(item.path)) {
        try { audio.src = fileUrl(item.path); } catch (e) {}
      }
    }
  }

  function categoryOptions(cats, currentCategory) {
    var html = "";
    for (var i = 0; i < cats.length; i++) {
      var c = cats[i];
      if (c === "全部") continue;
      html += '<option value="' + escapeAttr(c) + '"' + (c === currentCategory ? " selected" : "") + '>' + escapeHtml(c) + '</option>';
    }
    return html;
  }

  function render() {
    renderTabs();
    renderCategories();
    renderList();
    updateBatchControls();
    updateSaveStatus();
  }

  function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, function (ch) {
      return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch];
    });
  }

  function escapeAttr(s) {
    return escapeHtml(s).replace(/`/g, "&#96;");
  }

  function getItem(id) {
    if (!id) return null;
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].id === id) return state.items[i];
    }
    return null;
  }


  function formatRangeTime(sec) {
    if (sec === null || sec === undefined || isNaN(sec)) return "--:--";
    return secondsToText(sec);
  }

  function getAudioContextOnce() {
    if (!window.__dramaAudioCtx) {
      var AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) window.__dramaAudioCtx = new AudioCtx();
    }
    return window.__dramaAudioCtx || null;
  }

  function computeWavePeaks(audioBuffer, buckets) {
    buckets = buckets || 900;
    var channels = audioBuffer.numberOfChannels || 1;
    var len = audioBuffer.length;
    var block = Math.max(1, Math.floor(len / buckets));
    var peaks = [];

    for (var i = 0; i < buckets; i++) {
      var start = i * block;
      var end = Math.min(len, start + block);
      var max = 0;

      for (var c = 0; c < channels; c++) {
        var data = audioBuffer.getChannelData(c);
        for (var j = start; j < end; j++) {
          var v = Math.abs(data[j] || 0);
          if (v > max) max = v;
        }
      }

      peaks.push(Math.min(1, max));
    }

    return peaks;
  }

  function loadWaveformForItem(item) {
    var wrap = $("waveformWrap");
    var empty = $("waveformEmpty");
    if (!item || !wrap) return;

    waveState.itemId = item.id;
    waveState.path = item.path;
    waveState.duration = 0;
    waveState.peaks = [];
    waveState.hasRange = false;
    waveState.inSec = 0;
    waveState.outSec = 0;
    waveState.playRangeMode = false;
    waveState.loading = true;

    if (empty) empty.textContent = "正在解析波形…";
    wrap.classList.remove("has-wave");
    updateRangeLabels();
    drawWaveform();

    if (waveCache[item.path]) {
      var cached = waveCache[item.path];
      waveState.duration = cached.duration;
      waveState.peaks = cached.peaks;
      waveState.loading = false;
      wrap.classList.add("has-wave");
      updateRangeLabels();
      drawWaveform();
      return;
    }

    try {
      var audioCtx = getAudioContextOnce();
      if (!audioCtx) {
        if (empty) empty.textContent = "当前环境不支持波形解析。";
        waveState.loading = false;
        return;
      }

      var buffer = fs.readFileSync(item.path);
      audioCtx.decodeAudioData(bufferToArrayBuffer(buffer), function (audioBuffer) {
        if (waveState.path !== item.path) return;

        var peaks = computeWavePeaks(audioBuffer, 1000);
        waveCache[item.path] = {
          duration: audioBuffer.duration || 0,
          peaks: peaks
        };

        waveState.duration = audioBuffer.duration || 0;
        waveState.peaks = peaks;
        waveState.loading = false;

        if ($("waveformWrap")) $("waveformWrap").classList.add("has-wave");
        updateRangeLabels();
        drawWaveform();
      }, function () {
        waveState.loading = false;
        if ($("waveformEmpty")) $("waveformEmpty").textContent = "波形解析失败，但仍可正常试听。";
        drawWaveform();
      });
    } catch (e) {
      waveState.loading = false;
      if ($("waveformEmpty")) $("waveformEmpty").textContent = "波形解析失败，但仍可正常试听。";
      log("waveform load failed: " + e.message);
    }
  }

  function hasUsableRangeForItem(id) {
    return waveState.itemId === id && waveState.hasRange && waveState.outSec > waveState.inSec + 0.03;
  }

  function updateRangeLabels() {
    var start = $("rangeStart");
    var end = $("rangeEnd");

    if (!start || !end) return;

    if (waveState.hasRange) {
      start.textContent = formatRangeTime(waveState.inSec);
      end.textContent = formatRangeTime(waveState.outSec);
    } else {
      start.textContent = "--:--";
      end.textContent = "--:--";
    }
  }

  function canvasXToSec(x) {
    var canvas = $("waveformCanvas");
    if (!canvas || !waveState.duration) return 0;
    var rect = canvas.getBoundingClientRect();
    var ratio = Math.min(1, Math.max(0, x / Math.max(1, rect.width)));
    return ratio * waveState.duration;
  }

  function drawWaveform() {
    var canvas = $("waveformCanvas");
    if (!canvas) return;

    var rect = canvas.getBoundingClientRect();
    var dpr = window.devicePixelRatio || 1;
    var w = Math.max(1, Math.floor(rect.width * dpr));
    var h = Math.max(1, Math.floor(rect.height * dpr));

    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== h) canvas.height = h;

    var ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#080d14";
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = "#1f2a3d";
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();

    var peaks = waveState.peaks || [];
    if (peaks.length) {
      var barW = Math.max(1, w / peaks.length);
      for (var i = 0; i < peaks.length; i++) {
        var p = peaks[i];
        var bh = Math.max(1, p * h * 0.82);
        var x = i * barW;
        var y = (h - bh) / 2;

        ctx.fillStyle = "#5c75a5";
        ctx.fillRect(x, y, Math.max(1, barW * 0.72), bh);
      }
    }

    if (waveState.hasRange && waveState.duration > 0) {
      var sx = waveState.inSec / waveState.duration * w;
      var ex = waveState.outSec / waveState.duration * w;
      if (ex < sx) {
        var tmp = sx; sx = ex; ex = tmp;
      }

      ctx.fillStyle = "rgba(255, 208, 71, .22)";
      ctx.fillRect(sx, 0, Math.max(2, ex - sx), h);

      ctx.fillStyle = "#ffd047";
      ctx.fillRect(sx, 0, 2 * dpr, h);
      ctx.fillRect(ex, 0, 2 * dpr, h);
    }

    var audio = $("audioPlayer");
    if (audio && waveState.duration > 0) {
      var cx = (audio.currentTime || 0) / waveState.duration * w;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(cx, 0, Math.max(1, dpr), h);
    }
  }

  function setRangeFromSeconds(a, b) {
    var dur = waveState.duration || ($("audioPlayer") ? $("audioPlayer").duration : 0) || 0;
    if (!dur) return;

    a = Math.max(0, Math.min(dur, a));
    b = Math.max(0, Math.min(dur, b));

    if (Math.abs(a - b) < 0.03) {
      waveState.hasRange = false;
    } else {
      waveState.inSec = Math.min(a, b);
      waveState.outSec = Math.max(a, b);
      waveState.hasRange = true;
    }

    updateRangeLabels();
    drawWaveform();
  }

  function setInPointAtCurrent() {
    if (!currentPreviewId) {
      toast("先选择一个素材试听。");
      return;
    }

    var audio = $("audioPlayer");
    var t = audio ? (audio.currentTime || 0) : 0;
    var dur = waveState.duration || (audio ? audio.duration : 0) || 0;
    waveState.itemId = currentPreviewId;
    waveState.inSec = Math.max(0, Math.min(dur, t));

    if (!waveState.hasRange || waveState.outSec <= waveState.inSec + 0.03) {
      waveState.outSec = dur || waveState.inSec;
    }

    waveState.hasRange = waveState.outSec > waveState.inSec + 0.03;
    updateRangeLabels();
    drawWaveform();
    toast("已设置入点 I：" + secondsToText(waveState.inSec));
  }

  function setOutPointAtCurrent() {
    if (!currentPreviewId) {
      toast("先选择一个素材试听。");
      return;
    }

    var audio = $("audioPlayer");
    var t = audio ? (audio.currentTime || 0) : 0;
    var dur = waveState.duration || (audio ? audio.duration : 0) || 0;
    waveState.itemId = currentPreviewId;
    waveState.outSec = Math.max(0, Math.min(dur, t));

    if (!waveState.hasRange || waveState.inSec >= waveState.outSec - 0.03) {
      waveState.inSec = 0;
    }

    waveState.hasRange = waveState.outSec > waveState.inSec + 0.03;
    updateRangeLabels();
    drawWaveform();
    toast("已设置出点 O：" + secondsToText(waveState.outSec));
  }

  function clearRangeSelection() {
    waveState.hasRange = false;
    waveState.inSec = 0;
    waveState.outSec = 0;
    waveState.playRangeMode = false;
    updateRangeLabels();
    drawWaveform();
    toast("已清除选区");
  }

  function playRangeSelection() {
    if (!currentPreviewId || !hasUsableRangeForItem(currentPreviewId)) {
      toast("先在波形上拖拽选区，或用 I / O 设置入出点。");
      return;
    }

    var audio = $("audioPlayer");
    if (!audio) return;

    waveState.playRangeMode = true;
    audio.currentTime = waveState.inSec;
    audio.play();
    toast("试听选区：" + secondsToText(waveState.inSec) + " → " + secondsToText(waveState.outSec));
  }

  function insertCurrentRange() {
    if (!currentPreviewId || !hasUsableRangeForItem(currentPreviewId)) {
      toast("先选择一个有效区间。");
      return;
    }
    insertAsset(currentPreviewId, { useRange: true });
  }

  function syncCardPlayState() {
    var audio = $("audioPlayer");
    var playing = !!(audio && !audio.paused && !audio.ended);
    var cards = document.querySelectorAll('.card');
    for (var i = 0; i < cards.length; i++) {
      var card = cards[i];
      var btn = card.querySelector('.btn-play');
      if (!btn) continue;
      var isThis = playing && card.getAttribute('data-id') === currentPreviewId;
      btn.classList.toggle('playing', isThis);
      btn.innerHTML = isThis ? 'Ⅱ' : '▶';
      btn.setAttribute('title', isThis ? '暂停' : '播放');
    }
  }

  function playAsset(id) {
    var item = getItem(id);
    if (!item) return;

    var audio = $("audioPlayer");
    if (!audio) return;

    selectedId = id;

    // v4.9.18：同一个音频按钮第一次播放，第二次暂停，不再每次从头播放。
    if (currentPreviewId === id && audio.getAttribute("src")) {
      if (!audio.paused && !audio.ended) {
        audio.pause();
        updatePlayerTime();
        updatePlayerButton();
        syncCardPlayState();
        return;
      }

      if (audio.ended) {
        try { audio.currentTime = 0; } catch (e) {}
      }

      audio.play();
      $("nowPlaying").textContent = item.name;
      updatePlayerTime();
      updatePlayerButton();
      syncCardPlayState();
      return;
    }

    currentPreviewId = id;
    audio.src = fileUrl(item.path);
    audio.play();
    $("nowPlaying").textContent = item.name;
    loadWaveformForItem(item);
    updatePlayerTime();
    updatePlayerButton();
    syncCardPlayState();
    toast("正在试听：" + item.name);
  }

  function deleteAsset(id) {
    var item = getItem(id);
    if (!item) return;

    openUiConfirm({
      title: "移除素材",
      subtitle: "只移除插件库中的副本",
      message: "确定从本地库移除？\n\n" + item.name + "\n\n注意：只删除插件库复制的文件，不删除你的原始素材。",
      confirmText: "确认移除",
      cancelText: "取消",
      onConfirm: function () {
        try {
          if (fs.existsSync(item.path)) fs.unlinkSync(item.path);
        } catch (e) {
          log("delete file failed: " + e);
        }

        state.items = state.items.filter(function (x) { return x.id !== id; });
        if (selectedId === id) selectedId = null;
        saveState();
        render();
        toast("已移除");
      }
    });
  }


  function batchDeleteSelected() {
    if (!requireAuthorized()) return;
    var ids = getSelectedIdsForCurrentType();
    if (!ids.length) {
      alert("还没有勾选素材。\n\n请点击素材卡片左上角的小方框进行批量选择。");
      return;
    }

    openUiConfirm({
      title: "批量删除",
      subtitle: "只删除插件库中的副本",
      message: "确定删除已勾选的 " + ids.length + " 个素材吗？\n\n注意：只删除插件库复制的文件，不删除你原来的素材文件。",
      confirmText: "确认删除",
      cancelText: "取消",
      onConfirm: function () {
        var removed = 0;
        var failed = 0;
        var idMap = {};

        for (var i = 0; i < ids.length; i++) {
          var item = getItem(ids[i]);
          if (!item) { failed++; continue; }
          try {
            if (item.path && fs.existsSync(item.path)) fs.unlinkSync(item.path);
            idMap[ids[i]] = true;
            delete selectedIds[ids[i]];
            if (selectedId === ids[i]) selectedId = null;
            removed++;
          } catch (e) {
            failed++;
            log("batch delete failed: " + item.path + " / " + e.message);
          }
        }

        state.items = state.items.filter(function (x) { return !idMap[x.id]; });
        saveState();
        render();
        toast("批量删除完成：成功 " + removed + "，失败 " + failed);
      }
    });
  }

  function moveCategory(id, newCategory) {
    var item = getItem(id);
    if (!item || item.category === newCategory) return;

    var newPrimaryCategory = item.primaryCategory || getImportPrimaryCategory();
    var oldPath = item.path;
    var dest = makeDestPath(item.path, item.type, newCategory, newPrimaryCategory);

    try {
      ensureDir(path.dirname(dest));
      fs.renameSync(oldPath, dest);
    } catch (e) {
      try {
        fs.copyFileSync(oldPath, dest);
        try { fs.unlinkSync(oldPath); } catch (_) {}
      } catch (copyErr) {
        log("move category failed: " + copyErr);
        toast("移动分类失败，请看 debug.log");
        return;
      }
    }

    item.path = dest;
    item.name = path.basename(dest);
    item.primaryCategory = newPrimaryCategory;
    item.category = newCategory;
    item.reason = "手动移动二级分类";
    item.confidence = 1;
    saveState();
    render();
    toast("已移动到：" + newPrimaryCategory + " / " + newCategory);
  }

  function jsxString(s) {
    return JSON.stringify(String(s || ""));
  }

  function parseHostJson(raw) {
    try { return JSON.parse(raw); } catch (e) { return { ok: false, error: raw || "未知错误" }; }
  }

  function insertSelected() {
    if (!selectedId) {
      toast("先选择一个素材。");
      return;
    }
    insertAsset(selectedId);
  }

  function insertAsset(id, opts) {
    if (!requireAuthorized()) return;
    opts = opts || {};
    var item = getItem(id);
    if (!item) return;

    var trackIndex = parseInt($("trackSelect").value || "0", 10);
    var useRange = !!opts.useRange || hasUsableRangeForItem(id);

    var script;
    if (useRange && hasUsableRangeForItem(id)) {
      script = 'SFX_importAndInsertRangeAtCTI(' +
        jsxString(item.path) + ', ' +
        trackIndex + ', ' +
        Number(waveState.inSec).toFixed(3) + ', ' +
        Number(waveState.outSec).toFixed(3) +
      ')';
    } else {
      script = 'SFX_importAndInsertAtCTI(' + jsxString(item.path) + ', ' + trackIndex + ')';
    }

    cs.evalScript(script, function (raw) {
      var res = parseHostJson(raw);
      if (!res.ok) {
        alert("插入失败：" + (res.error || "未知错误"));
      } else {
        if (useRange && hasUsableRangeForItem(id)) {
          toast("已插入选区到 A" + (trackIndex + 1) + "：" + item.name + "（" + secondsToText(waveState.inSec) + " → " + secondsToText(waveState.outSec) + "）");
        } else {
          toast("已插入到 A" + (trackIndex + 1) + "：" + item.name);
        }
      }
    });
  }


  var trackOrganizerData = null;
  var trackOrganizerCurrentPlan = null;
  var trackOrganizerLastExecutedPlan = null;

  var trackOrganizerLastSnapshotPath = "";

  function getTrackOrganizerDir() {
    var dir = path.join(LIB_DIR, "track-organizer");
    ensureDir(dir);
    return dir;
  }

  function getTrackOrganizerSnapshotDir() {
    var dir = path.join(getTrackOrganizerDir(), "snapshots");
    ensureDir(dir);
    return dir;
  }

  function getTrackOrganizerLogPath() {
    return path.join(getTrackOrganizerDir(), "track-organizer.log");
  }

  function makeTrackOrgTimestamp() {
    var d = new Date();
    function pad(n) { return String(n).padStart(2, "0"); }
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + "_" + pad(d.getHours()) + "-" + pad(d.getMinutes()) + "-" + pad(d.getSeconds());
  }

  function appendTrackOrganizerLog(message, data) {
    try {
      var line = "[" + new Date().toISOString() + "] " + message;
      if (data !== undefined) line += "\n" + JSON.stringify(data, null, 2);
      line += "\n\n";
      fs.appendFileSync(getTrackOrganizerLogPath(), line, "utf8");
    } catch (e) {
      log("track organizer log write failed: " + e.message);
    }
  }

  function saveTrackOrganizerSnapshot(kind, execPlan) {
    try {
      var snapshot = {
        version: PLUGIN_VERSION,
        kind: kind || "execute",
        createdAt: new Date().toISOString(),
        plan: execPlan,
        reversePlan: buildReverseExecutionPlan(execPlan)
      };
      var file = path.join(getTrackOrganizerSnapshotDir(), "track-organizer-" + makeTrackOrgTimestamp() + "-" + (kind || "execute") + ".json");
      fs.writeFileSync(file, JSON.stringify(snapshot, null, 2), "utf8");
      trackOrganizerLastSnapshotPath = file;
      appendTrackOrganizerLog("saved snapshot: " + file, { kind: kind, file: file });
      return file;
    } catch (e) {
      appendTrackOrganizerLog("snapshot save failed", { error: e.message });
      return "";
    }
  }

  function openTrackOrganizerLogFolder() {
    try {
      var dir = getTrackOrganizerDir();
      appendTrackOrganizerLog("open log folder");
      if (window.cep && window.cep.process && window.cep.process.createProcess) {
        window.cep.process.createProcess("explorer.exe", dir);
      } else if (childProcess && childProcess.execFile) {
        childProcess.execFile("explorer.exe", [dir]);
      }
      toast("已打开整理日志目录");
    } catch (e) {
      alert("打开整理日志目录失败：" + e.message);
    }
  }


  function showTrackOrganizerPanel() {
    var panel = $("trackOrganizerPanel");
    if (!panel) return;
    panel.classList.remove("hidden");
    panel.setAttribute("aria-hidden", "false");
    if (!trackOrganizerData) scanOrganizerTracks();
  }

  function hideTrackOrganizerPanel() {
    var panel = $("trackOrganizerPanel");
    if (!panel) return;
    panel.classList.add("hidden");
    panel.setAttribute("aria-hidden", "true");
  }

  function scanOrganizerTracks() {
    var summary = $("trackOrgSummary");
    if (summary) summary.textContent = "正在快速扫描当前序列轨道数量…";
    if ($("trackVisualGrid")) $("trackVisualGrid").innerHTML = '<div class="track-visual-empty">正在扫描轨道，请稍等…</div>';

    var finished = false;
    var timer = setTimeout(function () {
      if (!finished && summary) {
        summary.textContent =
          "扫描还没有返回。可能是 Premiere 正在忙，或者当前序列片段太多。\n" +
          "这版已经改成先扫轨道数量，不读取全部素材块。等几秒后如果仍无响应，请点一次时间线面板，再点「扫描当前序列」。";
      }
    }, 6000);

    // v4.9.7：先只扫描轨道和片段数量，不一次性返回全部片段。
    // 旧版一次性返回所有素材块，复杂时间线容易导致 CEP evalScript 卡住。
    cs.evalScript("SFX_scanTrackOrganizerSummary()", function (raw) {
      finished = true;
      clearTimeout(timer);

      var res = parseHostJson(raw);
      if (!res.ok) {
        $("trackOrgSummary").textContent = "扫描失败：" + (res.error || raw || "未知错误");
        $("videoTrackList").textContent = "扫描失败";
        $("audioTrackList").textContent = "扫描失败";
        return;
      }

      trackOrganizerData = res;
      trackOrganizerCurrentPlan = null;
      renderOrganizerTracks();
      $("trackOrgSummary").textContent =
        "扫描完成。视频轨：" + (res.videoTracks ? res.videoTracks.length : 0) +
        " 条，音频轨：" + (res.audioTracks ? res.audioTracks.length : 0) + " 条。\n" +
        "现在只读取了轨道数量。勾选轨道后点「生成整理后时间轴」，再读取选中轨道的素材块。";
      $("trackVisualGrid").innerHTML = '<div class="track-visual-empty">扫描完成。请选择轨道并点击「生成整理后时间轴」。</div>';
      setTrackOrganizerButtonsEnabled(false);
    });
  }

  function renderOrganizerTrackList(containerId, tracks, kind) {
    var box = $(containerId);
    if (!box) return;
    if (!tracks || !tracks.length) {
      box.className = "track-org-list empty";
      box.textContent = "没有轨道";
      return;
    }

    box.className = "track-org-list";
    var html = "";
    for (var i = 0; i < tracks.length; i++) {
      var tr = tracks[i];
      var label = (kind === "video" ? "V" : "A") + (tr.index + 1);
      var disabled = tr.clipCount > 0 ? "" : " disabled";
      var checked = tr.clipCount > 0 ? " checked" : "";
      html += '<label class="track-row">' +
        '<input type="checkbox" class="track-org-check" data-kind="' + kind + '" data-index="' + tr.index + '"' + checked + disabled + ' />' +
        '<span class="track-name">' + escapeHtml(label) + '</span>' +
        '<span class="track-meta">' + escapeHtml(tr.name || "未命名轨道") + '</span>' +
        '<span class="track-count">' + tr.clipCount + ' 个</span>' +
      '</label>';
    }
    box.innerHTML = html;
  }

  function renderOrganizerTracks() {
    if (!trackOrganizerData) return;
    renderOrganizerTrackList("videoTrackList", trackOrganizerData.videoTracks || [], "video");
    renderOrganizerTrackList("audioTrackList", trackOrganizerData.audioTracks || [], "audio");
  }

  function setTrackSelection(kind, checked) {
    var nodes = document.querySelectorAll('.track-org-check[data-kind="' + kind + '"]');
    for (var i = 0; i < nodes.length; i++) {
      if (!nodes[i].disabled) nodes[i].checked = checked;
    }
  }

  function clearTrackSelection() {
    var nodes = document.querySelectorAll(".track-org-check");
    for (var i = 0; i < nodes.length; i++) nodes[i].checked = false;
  }

  function getSelectedTrackIndexes(kind) {
    var nodes = document.querySelectorAll('.track-org-check[data-kind="' + kind + '"]');
    var out = [];
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].checked) out.push(parseInt(nodes[i].getAttribute("data-index"), 10));
    }
    return out;
  }

  function intervalsOverlap(a, b) {
    return a.start < b.end && b.start < a.end;
  }

  function buildCompressPlan(tracks, selectedIndexes, kind) {
    var selectedMap = {};
    var orderedSelected = [];

    for (var s = 0; s < selectedIndexes.length; s++) {
      var idx = parseInt(selectedIndexes[s], 10);
      if (!isNaN(idx) && !selectedMap[idx]) {
        selectedMap[idx] = true;
        orderedSelected.push(idx);
      }
    }

    orderedSelected.sort(function (a, b) { return a - b; });

    var clips = [];
    var occupancy = {};
    for (var os = 0; os < orderedSelected.length; os++) occupancy[orderedSelected[os]] = [];

    for (var i = 0; i < tracks.length; i++) {
      var tr = tracks[i];
      if (!selectedMap[tr.index]) continue;

      var list = tr.clips || [];
      for (var j = 0; j < list.length; j++) {
        var c = list[j];
        var clip = {
          kind: kind,
          sourceTrack: tr.index,
          targetTrack: tr.index,
          clipIndex: j,
          start: Number(c.start) || 0,
          end: Number(c.end) || 0,
          name: c.name || "未命名片段"
        };
        clip.duration = Math.max(0, clip.end - clip.start);
        clips.push(clip);
        occupancy[tr.index].push(clip);
      }
    }

    clips.sort(function (a, b) {
      return a.sourceTrack - b.sourceTrack || a.start - b.start || a.end - b.end || a.name.localeCompare(b.name);
    });

    function removeFromOccupancy(trackIndex, clip) {
      var arr = occupancy[trackIndex] || [];
      for (var r = arr.length - 1; r >= 0; r--) {
        if (arr[r] === clip) {
          arr.splice(r, 1);
          return;
        }
      }
    }

    function canPlace(trackIndex, clip) {
      var arr = occupancy[trackIndex] || [];
      for (var c = 0; c < arr.length; c++) {
        if (arr[c] === clip) continue;
        if (intervalsOverlap(clip, arr[c])) return false;
      }
      return true;
    }

    function addToOccupancy(trackIndex, clip) {
      if (!occupancy[trackIndex]) occupancy[trackIndex] = [];
      occupancy[trackIndex].push(clip);
      clip.targetTrack = trackIndex;
    }

    function moveClipTowardLowerIndex(clip, allowedTracks) {
      removeFromOccupancy(clip.sourceTrack, clip);
      var current = clip.sourceTrack;
      var pos = allowedTracks.indexOf(current);

      if (pos < 0) {
        addToOccupancy(current, clip);
        return current;
      }

      while (pos > 0) {
        var nextTrack = allowedTracks[pos - 1];
        if (canPlace(nextTrack, clip)) {
          current = nextTrack;
          pos--;
        } else {
          break;
        }
      }

      addToOccupancy(current, clip);
      return current;
    }

    function isMusicClip(clip, threshold) {
      return clip.duration >= threshold;
    }

    if (kind === "video") {
      // 视频：从上方轨道往下压，也就是向 V1 方向移动。
      // 移动到下一条下方轨道被时间重叠素材挡住，或者到 V1，就停止。
      clips.sort(function (a, b) {
        return a.sourceTrack - b.sourceTrack || a.start - b.start || a.end - b.end;
      });

      for (var vc = 0; vc < clips.length; vc++) {
        moveClipTowardLowerIndex(clips[vc], orderedSelected);
      }
    } else {
      // 音频：普通音频向上移动，也就是向 A1 方向压。
      // 背景音乐按持续时间识别，并统一放到整理后最下面的音频轨道。
      var minStart = null;
      var maxEnd = null;
      for (var ac0 = 0; ac0 < clips.length; ac0++) {
        if (minStart === null || clips[ac0].start < minStart) minStart = clips[ac0].start;
        if (maxEnd === null || clips[ac0].end > maxEnd) maxEnd = clips[ac0].end;
      }

      var sequenceSpan = Math.max(0, (maxEnd || 0) - (minStart || 0));
      var musicThreshold = Math.max(12, Math.min(45, sequenceSpan * 0.25));

      var musicClips = [];
      var normalClips = [];
      for (var ac = 0; ac < clips.length; ac++) {
        clips[ac].isMusic = isMusicClip(clips[ac], musicThreshold);
        if (clips[ac].isMusic) musicClips.push(clips[ac]);
        else normalClips.push(clips[ac]);
      }

      var reservedMusicTracks = [];
      if (musicClips.length && orderedSelected.length) {
        reservedMusicTracks.push(orderedSelected[orderedSelected.length - 1]);
      }

      var normalAllowedTracks = orderedSelected.slice();
      if (reservedMusicTracks.length && normalAllowedTracks.length > 1) {
        normalAllowedTracks = normalAllowedTracks.slice(0, normalAllowedTracks.length - 1);
      }

      normalClips.sort(function (a, b) {
        return a.sourceTrack - b.sourceTrack || a.start - b.start || a.end - b.end;
      });

      for (var nc = 0; nc < normalClips.length; nc++) {
        moveClipTowardLowerIndex(normalClips[nc], normalAllowedTracks);
      }

      // 背景音乐：先从原位置移出，再从最下面轨道开始放。
      // 如果同一底部轨道有重叠，才向上开新的音乐轨，避免覆盖。
      var musicTargets = orderedSelected.slice().reverse();
      musicClips.sort(function (a, b) {
        return a.start - b.start || a.end - b.end || a.sourceTrack - b.sourceTrack;
      });

      for (var mc = 0; mc < musicClips.length; mc++) {
        var mclip = musicClips[mc];
        removeFromOccupancy(mclip.sourceTrack, mclip);
        var placedTrack = mclip.sourceTrack;

        for (var mt = 0; mt < musicTargets.length; mt++) {
          var candidate = musicTargets[mt];
          if (canPlace(candidate, mclip)) {
            placedTrack = candidate;
            break;
          }
        }

        addToOccupancy(placedTrack, mclip);
      }

      for (var mark = 0; mark < musicClips.length; mark++) {
        musicClips[mark].name = musicClips[mark].name;
      }
    }

    var usedMap = {};
    for (var uc = 0; uc < clips.length; uc++) {
      usedMap[clips[uc].targetTrack] = true;
    }

    var laneTrackIndexes = [];
    for (var oi = 0; oi < orderedSelected.length; oi++) {
      if (usedMap[orderedSelected[oi]]) laneTrackIndexes.push(orderedSelected[oi]);
    }

    // 如果某些素材没在选中轨道里产生目标，也做兜底。
    laneTrackIndexes.sort(function (a, b) { return a - b; });

    var lanes = [];
    for (var li = 0; li < laneTrackIndexes.length; li++) {
      lanes.push({ clips: [] });
    }

    var laneIndexByTrack = {};
    for (var lbi = 0; lbi < laneTrackIndexes.length; lbi++) {
      laneIndexByTrack[laneTrackIndexes[lbi]] = lbi;
    }

    for (var fc = 0; fc < clips.length; fc++) {
      var laneIndex = laneIndexByTrack[clips[fc].targetTrack];
      if (laneIndex === undefined) {
        laneTrackIndexes.push(clips[fc].targetTrack);
        laneTrackIndexes.sort(function (a, b) { return a - b; });
        lanes = [];
        laneIndexByTrack = {};
        for (var rebuild = 0; rebuild < laneTrackIndexes.length; rebuild++) {
          laneIndexByTrack[laneTrackIndexes[rebuild]] = rebuild;
          lanes.push({ clips: [] });
        }
        for (var refill = 0; refill <= fc; refill++) {
          var li2 = laneIndexByTrack[clips[refill].targetTrack];
          if (li2 !== undefined) lanes[li2].clips.push(clips[refill]);
        }
        continue;
      }

      clips[fc].targetLane = laneIndex;
      lanes[laneIndex].clips.push(clips[fc]);
    }

    for (var sortLane = 0; sortLane < lanes.length; sortLane++) {
      lanes[sortLane].clips.sort(function (a, b) {
        return a.start - b.start || a.end - b.end || a.sourceTrack - b.sourceTrack;
      });
    }

    var originalUsedMap = {};
    for (var oc = 0; oc < clips.length; oc++) {
      originalUsedMap[clips[oc].sourceTrack] = true;
    }

    var originalUsed = Object.keys(originalUsedMap).length;
    var targetUsed = laneTrackIndexes.length;

    return {
      kind: kind,
      clips: clips,
      lanes: lanes,
      originalUsed: originalUsed,
      targetUsed: targetUsed,
      reduced: Math.max(0, originalUsed - targetUsed),
      selectedTrackIndexes: orderedSelected,
      laneTrackIndexes: laneTrackIndexes
    };
  }


  function fmtSec(sec) {
    sec = Math.max(0, Number(sec) || 0);
    var m = Math.floor(sec / 60);
    var s = Math.floor(sec % 60);
    var ms = Math.round((sec - Math.floor(sec)) * 100);
    return m + ":" + String(s).padStart(2, "0") + "." + String(ms).padStart(2, "0");
  }

  function renderPlanGroup(plan, titlePrefix) {
    if (!plan || !plan.clips.length) return "";
    var prefix = plan.kind === "video" ? "V" : "A";
    var html = '<div class="plan-group"><h4>' + titlePrefix + '：' +
      plan.originalUsed + ' 条 → 预计 ' + plan.targetUsed + ' 条，减少 ' + plan.reduced + ' 条</h4>';

    for (var i = 0; i < plan.clips.length; i++) {
      var c = plan.clips[i];
      html += '<div class="plan-line">' +
        escapeHtml(prefix + (c.sourceTrack + 1)) + ' → ' +
        escapeHtml(prefix + (c.targetLane + 1)) + ' ｜ ' +
        escapeHtml(fmtSec(c.start) + ' - ' + fmtSec(c.end)) + ' ｜ ' +
        escapeHtml(c.name) +
      '</div>';
    }

    html += '</div>';
    return html;
  }


  function collectSelectedTrackClips(tracks, selectedIndexes, kind) {
    var selectedMap = {};
    for (var s = 0; s < selectedIndexes.length; s++) selectedMap[selectedIndexes[s]] = true;

    var rows = [];
    for (var i = 0; i < tracks.length; i++) {
      var tr = tracks[i];
      if (!selectedMap[tr.index]) continue;

      var clips = [];
      var list = tr.clips || [];
      for (var j = 0; j < list.length; j++) {
        var c = list[j];
        clips.push({
          kind: kind,
          sourceTrack: tr.index,
          targetLane: tr.index,
          start: Number(c.start) || 0,
          end: Number(c.end) || 0,
          name: c.name || "未命名片段"
        });
      }

      rows.push({
        label: (kind === "video" ? "V" : "A") + (tr.index + 1),
        index: tr.index,
        clips: clips
      });
    }

    return rows;
  }

  function buildRowsFromPlan(plan) {
    if (!plan || !plan.lanes) return [];
    var prefix = plan.kind === "video" ? "V" : "A";
    var rows = [];
    for (var i = 0; i < plan.lanes.length; i++) {
      var actualTrack = plan.laneTrackIndexes && plan.laneTrackIndexes[i] !== undefined ? plan.laneTrackIndexes[i] : i;
      rows.push({
        label: prefix + (actualTrack + 1),
        index: actualTrack,
        clips: plan.lanes[i].clips || []
      });
    }
    return rows;
  }

  function getTimelineBoundsFromRows(rowGroups) {
    var min = 0;
    var max = 0;
    var found = false;

    for (var g = 0; g < rowGroups.length; g++) {
      var rows = rowGroups[g] || [];
      for (var r = 0; r < rows.length; r++) {
        var clips = rows[r].clips || [];
        for (var c = 0; c < clips.length; c++) {
          if (!found) {
            min = clips[c].start;
            max = clips[c].end;
            found = true;
          } else {
            min = Math.min(min, clips[c].start);
            max = Math.max(max, clips[c].end);
          }
        }
      }
    }

    if (!found || max <= min) {
      return { min: 0, max: 60, span: 60 };
    }

    var pad = Math.max(1, (max - min) * 0.04);
    min = Math.max(0, min - pad);
    max = max + pad;
    return { min: min, max: max, span: Math.max(1, max - min) };
  }

  function shortClipName(name) {
    name = String(name || "未命名片段");
    if (name.length <= 18) return name;
    return name.slice(0, 8) + "…" + name.slice(-8);
  }

  function renderScale(bounds) {
    var html = '<div class="timeline-scale">';
    for (var i = 0; i <= 4; i++) {
      var p = i / 4;
      var sec = bounds.min + bounds.span * p;
      html += '<span style="left:' + (p * 100).toFixed(2) + '%">' + escapeHtml(fmtSec(sec)) + '</span>';
    }
    html += '</div>';
    return html;
  }

  function renderTimelinePanel(title, subtitle, rows, bounds, mode, kind) {
    var clipClass = mode === "after" ? "clip-after" : "clip-before";
    var kindClass = kind === "audio" ? " clip-audio" : "";
    var html = '<div class="timeline-panel">' +
      '<div class="timeline-head"><b>' + escapeHtml(title) + '</b><span>' + escapeHtml(subtitle) + '</span></div>' +
      '<div class="timeline-body">' + renderScale(bounds);

    if (!rows.length) {
      html += '<div class="track-visual-empty">没有选中的' + (kind === "audio" ? "音频" : "视频") + '轨道。</div>';
    }

    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      html += '<div class="timeline-track-row">' +
        '<div class="timeline-track-label">' + escapeHtml(row.label) + '</div>' +
        '<div class="timeline-lane">';

      var clips = row.clips || [];
      for (var j = 0; j < clips.length; j++) {
        var c = clips[j];
        var left = ((c.start - bounds.min) / bounds.span) * 100;
        var width = Math.max(0.4, ((c.end - c.start) / bounds.span) * 100);
        var tooSmall = width < 2.2 ? " clip-too-small" : "";
        var titleText = (row.label + "｜" + fmtSec(c.start) + " - " + fmtSec(c.end) + "｜" + c.name);
        html += '<div class="clip-block ' + clipClass + kindClass + tooSmall + '" ' +
          'style="left:' + left.toFixed(3) + '%;width:' + width.toFixed(3) + '%" ' +
          'title="' + escapeAttr(titleText) + '">' +
          escapeHtml(width < 2.2 ? "" : shortClipName(c.name)) +
        '</div>';
      }

      html += '</div></div>';
    }

    html += '</div></div>';
    return html;
  }


  function renderSequenceRuler(bounds) {
    var html = '<div class="sequence-ruler"><div class="sequence-ruler-left"></div><div class="sequence-ruler-line">';
    for (var i = 0; i <= 10; i++) {
      var p = i / 10;
      var sec = bounds.min + bounds.span * p;
      html += '<div class="sequence-tick" style="left:' + (p * 100).toFixed(3) + '%"><span>' + escapeHtml(fmtSec(sec)) + '</span></div>';
    }
    html += '</div></div>';
    return html;
  }

  function renderSequenceRows(rows, bounds, kind) {
    var html = "";
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      html += '<div class="sequence-track-row">' +
        '<div class="sequence-track-name">' + escapeHtml(row.label) + '</div>' +
        '<div class="sequence-lane">';

      var clips = row.clips || [];
      for (var j = 0; j < clips.length; j++) {
        var c = clips[j];
        var left = ((c.start - bounds.min) / bounds.span) * 100;
        var width = Math.max(0.25, ((c.end - c.start) / bounds.span) * 100);
        var tiny = width < 1.4 ? " tiny" : "";
        var titleText = row.label + " ｜ " + fmtSec(c.start) + " - " + fmtSec(c.end) + " ｜ " + c.name;
        html += '<div class="sequence-clip ' + kind + tiny + '" style="left:' + left.toFixed(3) + '%;width:' + width.toFixed(3) + '%" title="' + escapeAttr(titleText) + '">' +
          escapeHtml(width < 1.4 ? "" : shortClipName(c.name)) +
        '</div>';
      }

      html += '</div></div>';
    }
    return html;
  }

  function renderAfterSequenceTimeline(videoPlan, audioPlan) {
    var videoRows = buildRowsFromPlan(videoPlan);
    var audioRows = buildRowsFromPlan(audioPlan);
    var bounds = getTimelineBoundsFromRows([videoRows, audioRows]);

    var vOriginal = videoPlan ? videoPlan.originalUsed : 0;
    var vTarget = videoPlan ? videoPlan.targetUsed : 0;
    var aOriginal = audioPlan ? audioPlan.originalUsed : 0;
    var aTarget = audioPlan ? audioPlan.targetUsed : 0;
    var reduced = Math.max(0, vOriginal - vTarget) + Math.max(0, aOriginal - aTarget);

    var html = '<div class="sequence-preview">' +
      '<div class="sequence-topbar">' +
        '<b>整理后模拟时间轴</b>' +
        '<span>像序列时间轴一样显示整理后的轨道和素材块</span>' +
      '</div>' +
      '<div class="sequence-stats-line">' +
        '<span class="sequence-pill">视频轨：<b>' + vOriginal + '</b> → <b>' + vTarget + '</b></span>' +
        '<span class="sequence-pill">音频轨：<b>' + aOriginal + '</b> → <b>' + aTarget + '</b></span>' +
        '<span class="sequence-pill">预计减少：<b>' + reduced + '</b> 条轨道</span>' +
      '</div>' +
      '<div class="sequence-scroll"><div class="sequence-canvas">' +
        renderSequenceRuler(bounds);

    if (videoRows.length) {
      html += '<div class="sequence-section-label">视频轨道 Video</div>' + renderSequenceRows(videoRows, bounds, "video");
    }

    if (audioRows.length) {
      html += '<div class="sequence-section-label">音频轨道 Audio</div>' + renderSequenceRows(audioRows, bounds, "audio");
    }

    if (!videoRows.length && !audioRows.length) {
      html += '<div class="sequence-empty">没有可显示的整理后轨道。</div>';
    }

    html += '</div></div></div>';
    return html;
  }

  function renderVisualTrackPlan(videoPlan, audioPlan, vSel, aSel) {
    $("trackVisualGrid").classList.add("sequence-only");
    $("trackVisualGrid").innerHTML = renderAfterSequenceTimeline(videoPlan, audioPlan);
  }

  function buildExecutionPlan(videoPlan, audioPlan) {
    var out = { videoCommands: [], audioCommands: [] };
    function add(plan, listName) {
      if (!plan || !plan.clips) return;
      var rows = [];
      for (var i = 0; i < plan.clips.length; i++) {
        var c = plan.clips[i];
        rows.push({
          sourceTrack: c.sourceTrack,
          targetTrack: c.targetTrack,
          start: c.start,
          end: c.end,
          name: c.name || "未命名片段",
          clipIndex: c.clipIndex || 0
        });
      }
      rows.sort(function (a, b) {
        return a.sourceTrack - b.sourceTrack || a.targetTrack - b.targetTrack || a.start - b.start || a.end - b.end;
      });
      out[listName] = rows;
    }
    add(videoPlan, "videoCommands");
    add(audioPlan, "audioCommands");
    return out;
  }

  function buildReverseExecutionPlan(execPlan) {
    var out = { videoCommands: [], audioCommands: [] };
    function flip(list, key) {
      var src = execPlan && execPlan[key] ? execPlan[key] : [];
      var rows = [];
      for (var i = 0; i < src.length; i++) {
        rows.push({
          sourceTrack: src[i].targetTrack,
          targetTrack: src[i].sourceTrack,
          start: src[i].start,
          end: src[i].end,
          name: src[i].name || "未命名片段",
          clipIndex: src[i].clipIndex || 0
        });
      }
      rows.sort(function (a, b) {
        return a.sourceTrack - b.sourceTrack || a.targetTrack - b.targetTrack || a.start - b.start || a.end - b.end;
      });
      out[key] = rows;
    }
    flip(execPlan, "videoCommands");
    flip(execPlan, "audioCommands");
    return out;
  }

  function summarizeExecutionResult(res, title) {
    var lines = [title, "成功移动：" + (res.moved || 0) + " 个", "跳过：" + (res.skipped || 0) + " 个", "失败：" + (res.failed || 0) + " 个"];
    if (trackOrganizerLastSnapshotPath) lines.push("快照：" + trackOrganizerLastSnapshotPath);
    lines.push("日志：" + getTrackOrganizerLogPath());
    if (res.details) lines.push("\n详情：\n" + res.details);
    return lines.join("\n");
  }

  function setTrackOrganizerButtonsEnabled(enabled) {
    if ($("btnConfirmTrackOrganize")) {
      $("btnConfirmTrackOrganize").classList.toggle("disabled-btn", !enabled);
      $("btnConfirmTrackOrganize").title = enabled ? "按整理方案执行纯上下轨道移动" : "请先生成整理后时间轴";
    }
    if ($("btnRestoreTrackSnapshot")) {
      var canRestore = !!trackOrganizerLastExecutedPlan;
      $("btnRestoreTrackSnapshot").classList.toggle("disabled-btn", !canRestore);
      $("btnRestoreTrackSnapshot").title = canRestore ? "把已执行的整理恢复到整理前" : "当前没有可恢复的整理记录";
    }
  }

  function csvFromIndexes(arr) {
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      var n = parseInt(arr[i], 10);
      if (!isNaN(n)) out.push(String(n));
    }
    return out.join(",");
  }

  function replaceOrganizerTracksWithClipData(target, incoming, kind) {
    if (!target || !incoming) return;
    var key = kind === "video" ? "videoTracks" : "audioTracks";
    var current = target[key] || [];
    var map = {};

    for (var i = 0; i < current.length; i++) {
      map[current[i].index] = current[i];
    }

    var rows = incoming[key] || [];
    for (var j = 0; j < rows.length; j++) {
      var tr = rows[j];
      if (map[tr.index]) {
        map[tr.index].clips = tr.clips || [];
        map[tr.index].clipCount = tr.clipCount || (tr.clips ? tr.clips.length : 0);
        map[tr.index].name = tr.name || map[tr.index].name || "";
      }
    }
  }

  function hasClipDataForSelection(indexes, tracks) {
    var map = {};
    for (var i = 0; i < tracks.length; i++) map[tracks[i].index] = tracks[i];

    for (var j = 0; j < indexes.length; j++) {
      var tr = map[indexes[j]];
      if (!tr) continue;
      if (tr.clipCount > 0 && (!tr.clips || !tr.clips.length)) return false;
    }
    return true;
  }

  function fetchSelectedOrganizerClips(vSel, aSel, done) {
    var summary = $("trackOrgSummary");
    if (summary) {
      summary.textContent =
        "正在读取选中轨道的素材块…\\n" +
        "选中轨道越多、片段越多，读取时间越长。";
    }

    var script = "SFX_scanTrackOrganizerSelected(" + jsxString(csvFromIndexes(vSel)) + "," + jsxString(csvFromIndexes(aSel)) + ")";

    var finished = false;
    var timer = setTimeout(function () {
      if (!finished && summary) {
        summary.textContent =
          "读取素材块还没有返回。\\n" +
          "如果你的时间线片段非常多，请减少勾选轨道数量后重新生成。";
      }
    }, 10000);

    cs.evalScript(script, function (raw) {
      finished = true;
      clearTimeout(timer);

      var res = parseHostJson(raw);
      if (!res.ok) {
        alert("读取素材块失败：" + (res.error || raw || "未知错误"));
        if (summary) summary.textContent = "读取素材块失败：" + (res.error || raw || "未知错误");
        return;
      }

      replaceOrganizerTracksWithClipData(trackOrganizerData, res, "video");
      replaceOrganizerTracksWithClipData(trackOrganizerData, res, "audio");
      if (done) done();
    });
  }

  function analyzeTrackOrganizerPlan() {
    if (!trackOrganizerData) {
      scanOrganizerTracks();
      return;
    }

    var vSel = getSelectedTrackIndexes("video");
    var aSel = getSelectedTrackIndexes("audio");

    if (!vSel.length && !aSel.length) {
      alert("请先勾选要整理的视频轨或音频轨。");
      return;
    }

    var needsFetch =
      !hasClipDataForSelection(vSel, trackOrganizerData.videoTracks || []) ||
      !hasClipDataForSelection(aSel, trackOrganizerData.audioTracks || []);

    if (needsFetch) {
      fetchSelectedOrganizerClips(vSel, aSel, analyzeTrackOrganizerPlan);
      return;
    }

    var videoPlan = buildCompressPlan(trackOrganizerData.videoTracks || [], vSel, "video");
    var audioPlan = buildCompressPlan(trackOrganizerData.audioTracks || [], aSel, "audio");
    trackOrganizerCurrentPlan = { videoPlan: videoPlan, audioPlan: audioPlan, videoSelected: vSel.slice(), audioSelected: aSel.slice() };

    var lines = [];
    if (vSel.length) lines.push("视频轨：" + videoPlan.originalUsed + " → " + videoPlan.targetUsed + "，上方素材会向下压到 V1 方向，遇到重叠阻挡就停止。");
    if (aSel.length) lines.push("音频轨：" + audioPlan.originalUsed + " → " + audioPlan.targetUsed + "，普通音频向 A1 方向上移，长音频识别为背景音乐并放到整理后最下面。");
    lines.push("已生成纯垂直整理方案：开始时间、结束时间、片段间隙、效果参数都保持不变。确认整理后会执行上下轨道移动。可用“恢复整理前”回退。"
    );

    $("trackOrgSummary").textContent = lines.join("\n");
    renderVisualTrackPlan(videoPlan, audioPlan, vSel, aSel);
    if ($("trackVisualGrid")) {
      $("trackVisualGrid").insertAdjacentHTML("afterbegin",
        '<div class="vertical-safe-warning">当前显示的是整理后时间轴预览。视频向下压到被素材挡住为止；普通音频向上压；长音频识别为背景音乐放到最下面。不会左右移动，不会封闭间隙。</div>' +
        '<div class="track-org-log-tip">点击“确认整理”前会自动保存恢复快照，并写入整理日志。</div>'
      );
    }
    setTrackOrganizerButtonsEnabled(true);
  }

  function confirmTrackOrganizePreviewOnly() {
    if (!trackOrganizerCurrentPlan) {
      alert("请先点击“生成整理后时间轴”，确认预览没问题后再执行整理。");
      return;
    }

    var execPlan = buildExecutionPlan(trackOrganizerCurrentPlan.videoPlan, trackOrganizerCurrentPlan.audioPlan);
    if ((!execPlan.videoCommands || !execPlan.videoCommands.length) && (!execPlan.audioCommands || !execPlan.audioCommands.length)) {
      alert("当前选中的轨道已经很紧凑了，没有需要移动的素材。");
      return;
    }

    var snapshotFile = saveTrackOrganizerSnapshot("before-execute", execPlan);
    appendTrackOrganizerLog("execute start", { snapshot: snapshotFile, plan: execPlan });
    $("trackOrgSummary").textContent =
      "正在执行纯垂直整理…\n只会上下移动素材轨道，不会改动素材的前后时间位置。\n已保存快照：" + (snapshotFile || "保存失败，但继续执行");
    cs.evalScript("SFX_executeTrackOrganizerPlan(" + jsxString(JSON.stringify(execPlan)) + ")", function (raw) {
      var res = parseHostJson(raw);
      if (!res.ok) {
        alert("执行整理失败：" + (res.error || raw || "未知错误"));
        $("trackOrgSummary").textContent = "执行整理失败：" + (res.error || raw || "未知错误");
        return;
      }
      trackOrganizerLastExecutedPlan = execPlan;
      appendTrackOrganizerLog("execute finished", { result: res });
      setTrackOrganizerButtonsEnabled(true);
      alert(summarizeExecutionResult(res, "轨道整理完成"));
      $("trackOrgSummary").textContent = summarizeExecutionResult(res, "轨道整理完成");
      scanOrganizerTracks();
    });
  }

  function restoreTrackSnapshotPreviewOnly() {
    if (!trackOrganizerLastExecutedPlan) {
      alert("当前没有可恢复的整理记录。请先执行一次整理。");
      return;
    }

    var reversePlan = buildReverseExecutionPlan(trackOrganizerLastExecutedPlan);
    var snapshotFile = saveTrackOrganizerSnapshot("before-restore", reversePlan);
    appendTrackOrganizerLog("restore start", { snapshot: snapshotFile, plan: reversePlan });
    $("trackOrgSummary").textContent =
      "正在恢复整理前轨道…\n会按上一次整理的反向方案进行纯上下轨道移动。\n已保存恢复快照：" + (snapshotFile || "保存失败，但继续执行");
    cs.evalScript("SFX_executeTrackOrganizerPlan(" + jsxString(JSON.stringify(reversePlan)) + ")", function (raw) {
      var res = parseHostJson(raw);
      if (!res.ok) {
        alert("恢复整理前失败：" + (res.error || raw || "未知错误"));
        $("trackOrgSummary").textContent = "恢复整理前失败：" + (res.error || raw || "未知错误");
        return;
      }
      appendTrackOrganizerLog("restore finished", { result: res });
      alert(summarizeExecutionResult(res, "已恢复整理前"));
      $("trackOrgSummary").textContent = summarizeExecutionResult(res, "已恢复整理前");
      trackOrganizerLastExecutedPlan = null;
      setTrackOrganizerButtonsEnabled(false);
      scanOrganizerTracks();
    });
  }

  function refreshTracks() {
    cs.evalScript("SFX_getAudioTracks()", function (raw) {
      var res = parseHostJson(raw);
      var sel = $("trackSelect");
      sel.innerHTML = "";

      if (!res.ok || !res.tracks || !res.tracks.length) {
        var opt = document.createElement("option");
        opt.value = "0";
        opt.textContent = "A1";
        sel.appendChild(opt);
        return;
      }

      for (var i = 0; i < res.tracks.length; i++) {
        var tr = res.tracks[i];
        var opt2 = document.createElement("option");
        opt2.value = tr.index;
        opt2.textContent = "A" + (tr.index + 1) + (tr.name ? "｜" + tr.name : "");
        sel.appendChild(opt2);
      }
    });
  }


  function timestampName() {
    var d = new Date();
    function pad(n) { return String(n).padStart(2, "0"); }
    return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + "-" + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  }

  function removeDirSafe(dir) {
    try {
      if (!dir || !fs.existsSync(dir)) return;
      if (fs.rmSync) fs.rmSync(dir, { recursive: true, force: true });
      else fs.rmdirSync(dir, { recursive: true });
    } catch (e) {
      log("remove dir failed: " + dir + " / " + e.message);
    }
  }

  function copyFileSafe(src, dest) {
    ensureDir(path.dirname(dest));
    fs.copyFileSync(src, dest);
  }

  function psQuote(s) {
    return "'" + String(s || "").replace(/'/g, "''") + "'";
  }

  function compressFolderToZip(srcDir, zipPath) {
    if (process.platform !== "win32") {
      throw new Error("当前自动压缩功能优先支持 Windows。已生成未压缩包目录：" + srcDir);
    }
    var script = [
      "$src=" + psQuote(srcDir) + ";",
      "$dst=" + psQuote(zipPath) + ";",
      "if(Test-Path -LiteralPath $dst){Remove-Item -LiteralPath $dst -Force};",
      "Compress-Archive -Path (Join-Path $src '*') -DestinationPath $dst -Force;"
    ].join(" ");
    childProcess.execFileSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], { stdio: "pipe" });
  }

  function extractZipToFolder(zipPath, destDir) {
    if (process.platform !== "win32") {
      throw new Error("当前自动解包功能优先支持 Windows。请先手动解压转移包。 ");
    }
    var script = [
      "$zip=" + psQuote(zipPath) + ";",
      "$dst=" + psQuote(destDir) + ";",
      "if(Test-Path -LiteralPath $dst){Remove-Item -LiteralPath $dst -Recurse -Force};",
      "New-Item -ItemType Directory -Force -Path $dst | Out-Null;",
      "Expand-Archive -LiteralPath $zip -DestinationPath $dst -Force;"
    ].join(" ");
    childProcess.execFileSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], { stdio: "pipe" });
  }

  function findFileRecursive(dir, fileName) {
    if (!fs.existsSync(dir)) return "";
    var entries = fs.readdirSync(dir);
    for (var i = 0; i < entries.length; i++) {
      var full = path.join(dir, entries[i]);
      var st;
      try { st = fs.statSync(full); } catch (e) { continue; }
      if (st.isFile() && entries[i] === fileName) return full;
      if (st.isDirectory()) {
        var found = findFileRecursive(full, fileName);
        if (found) return found;
      }
    }
    return "";
  }

  function chooseFolderForTransfer(title) {
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialogEx) {
      toast("文件夹选择接口不可用。 ");
      return "";
    }
    var result = window.cep.fs.showOpenDialogEx(false, true, title || "选择目录", "", [], "Folder", "选择");
    if (result && result.err === 0 && result.data && result.data.length) return cepPathToFsPath(result.data[0]);
    return "";
  }

  function choosePackFile() {
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialogEx) {
      toast("文件选择接口不可用。 ");
      return "";
    }
    var result = window.cep.fs.showOpenDialogEx(false, false, "选择短剧音频库转移包", "", ["zip"], "Drama Audio Pack", "导入");
    if (result && result.err === 0 && result.data && result.data.length) return cepPathToFsPath(result.data[0]);
    return "";
  }

  function uniqueRelPath(baseDir, relPath) {
    var ext = path.extname(relPath);
    var dir = path.dirname(relPath);
    var base = path.basename(relPath, ext);
    var candidate = relPath;
    var i = 2;
    while (fs.existsSync(path.join(baseDir, candidate))) {
      candidate = path.join(dir, base + "_" + i + ext);
      i++;
    }
    return candidate;
  }

  function exportTransferPack() {
    if (!requireAuthorized()) return;
    cleanMissingItems(false);

    var validItems = [];
    for (var i = 0; i < state.items.length; i++) {
      var item = state.items[i];
      if (item && item.path && fs.existsSync(item.path) && isAudioFile(item.path)) validItems.push(item);
    }

    if (!validItems.length) {
      toast("当前没有可打包的音频素材。 ");
      return;
    }

    var targetDir = chooseFolderForTransfer("选择转移包保存目录");
    if (!targetDir) return;

    var packName = "DramaAudioLibrary-Pack-" + timestampName();
    var workRoot = path.join(LIB_DIR, "transfer_export_tmp", packName);
    var zipPath = path.join(targetDir, packName + ".dalp.zip");
    removeDirSafe(workRoot);
    ensureDir(workRoot);

    showProgress(0, validItems.length, "正在准备转移包…");

    var manifest = {
      format: "drama-audio-library-pack",
      packVersion: 1,
      pluginVersion: PLUGIN_VERSION,
      exportedAt: new Date().toISOString(),
      exportedBy: "短剧音频库",
      customPrimaryCategories: (state.customPrimaryCategories || []).slice(),
      deletedPrimaryCategories: state.deletedPrimaryCategories || { sfx: [], music: [] },
      customCategories: (state.customCategories || []).slice(),
      deletedCategories: state.deletedCategories || { sfx: [], music: [] },
      items: []
    };

    var exported = 0;
    var failed = 0;

    for (var j = 0; j < validItems.length; j++) {
      var srcItem = validItems[j];
      try {
        var type = srcItem.type || "sfx";
        var primaryCategory = srcItem.primaryCategory || "短剧";
        var category = srcItem.category || "未分类";
        var rel = path.join("media", type, safeName(primaryCategory), safeName(category), safeName(path.basename(srcItem.path)));
        rel = uniqueRelPath(workRoot, rel);
        var dest = path.join(workRoot, rel);
        copyFileSafe(srcItem.path, dest);
        var st = fs.statSync(dest);
        var meta = {
          type: type,
          primaryCategory: primaryCategory,
          category: category,
          name: srcItem.name || path.basename(dest),
          originalName: srcItem.originalName || srcItem.name || path.basename(dest),
          file: normalizeSlashes(rel),
          confidence: srcItem.confidence || 1,
          reason: srcItem.reason || "转移包导出",
          duration: srcItem.duration || 0,
          size: st.size,
          fingerprint: srcItem.fingerprint || itemFingerprint(srcItem.path),
          addedAt: srcItem.addedAt || new Date().toISOString(),
          exportedAt: new Date().toISOString()
        };
        manifest.items.push(meta);
        exported++;
      } catch (e) {
        failed++;
        log("export pack item failed: " + (srcItem && srcItem.path) + " / " + e.message);
      }
      showProgress(j + 1, validItems.length, "正在打包素材…");
    }

    fs.writeFileSync(path.join(workRoot, "drama-audio-library-pack.json"), JSON.stringify(manifest, null, 2), "utf8");

    try {
      showProgress(validItems.length, validItems.length, "正在压缩转移包…");
      compressFolderToZip(workRoot, zipPath);
      hideProgress();
      toast("打包完成：" + exported + " 个素材");
      openUiConfirm({
        title: "转移包导出完成",
        subtitle: "可以复制到其他电脑导入",
        message: "已生成转移包：\n" + zipPath + "\n\n导出素材：" + exported + "\n失败：" + failed + "\n\n是否打开保存目录？",
        confirmText: "打开目录",
        cancelText: "关闭",
        onConfirm: function () {
          try { childProcess.exec('explorer "' + targetDir + '"'); } catch (e) { alert(targetDir); }
        }
      });
    } catch (zipErr) {
      hideProgress();
      toast("压缩失败，已保留未压缩包目录。 ");
      alert("压缩失败：" + zipErr.message + "\n\n未压缩包目录：\n" + workRoot);
    }
  }

  function ensurePrimaryCategoryExistsForTransfer(cat) {
    if (!cat || isProtectedPrimaryCategory(cat)) return;
    var allSfx = getPrimaryCategories("sfx");
    var allMusic = getPrimaryCategories("music");
    if (allSfx.indexOf(cat) < 0 && allMusic.indexOf(cat) < 0 && state.customPrimaryCategories.indexOf(cat) < 0) {
      state.customPrimaryCategories.push(cat);
    }
  }

  function ensureCategoryExistsForTransfer(cat) {
    if (!cat || isProtectedCategory(cat)) return;
    var allSfx = getCategories("sfx");
    var allMusic = getCategories("music");
    if (allSfx.indexOf(cat) < 0 && allMusic.indexOf(cat) < 0 && state.customCategories.indexOf(cat) < 0) {
      state.customCategories.push(cat);
    }
  }

  function importTransferPack() {
    if (!requireAuthorized()) return;
    var packPath = choosePackFile();
    if (!packPath) return;

    if (!fs.existsSync(packPath)) {
      toast("转移包不存在。 ");
      return;
    }

    var tempDir = path.join(LIB_DIR, "transfer_import_tmp", "import_" + timestampName() + "_" + uid());

    try {
      showProgress(0, 1, "正在解压转移包…");
      extractZipToFolder(packPath, tempDir);
      var manifestPath = findFileRecursive(tempDir, "drama-audio-library-pack.json");
      if (!manifestPath) throw new Error("没有找到转移包清单 drama-audio-library-pack.json");

      var manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
      if (!manifest || manifest.format !== "drama-audio-library-pack" || !manifest.items) {
        throw new Error("这不是有效的短剧音频库转移包。 ");
      }

      var packRoot = path.dirname(manifestPath);
      var customPrimary = manifest.customPrimaryCategories || [];
      for (var pc = 0; pc < customPrimary.length; pc++) {
        if (customPrimary[pc] && state.customPrimaryCategories.indexOf(customPrimary[pc]) < 0 && !isProtectedPrimaryCategory(customPrimary[pc])) {
          state.customPrimaryCategories.push(customPrimary[pc]);
        }
      }

      var custom = manifest.customCategories || [];
      for (var c = 0; c < custom.length; c++) {
        if (custom[c] && state.customCategories.indexOf(custom[c]) < 0 && !isProtectedCategory(custom[c])) {
          state.customCategories.push(custom[c]);
        }
      }

      var imported = 0;
      var skipped = 0;
      var failed = 0;
      var items = manifest.items || [];
      showProgress(0, items.length, "正在导入转移包…");

      for (var i = 0; i < items.length; i++) {
        var meta = items[i];
        try {
          var type = meta.type === "music" ? "music" : "sfx";
          var primaryCategory = meta.primaryCategory || "短剧";
          var category = meta.category || "未分类";
          ensurePrimaryCategoryExistsForTransfer(primaryCategory);
          ensureCategoryExistsForTransfer(category);
          var srcFile = path.join(packRoot, meta.file || "");
          if (!fs.existsSync(srcFile) || !isAudioFile(srcFile)) {
            failed++;
            continue;
          }

          if (hasSameImported(srcFile, type)) {
            skipped++;
            continue;
          }

          var dest = makeDestPath(srcFile, type, category, primaryCategory);
          copyFileSafe(srcFile, dest);
          var st = fs.statSync(dest);
          state.items.push({
            id: uid(),
            type: type,
            name: path.basename(dest),
            originalName: meta.originalName || meta.name || path.basename(srcFile),
            path: dest,
            primaryCategory: primaryCategory,
            category: category,
            confidence: meta.confidence || 1,
            reason: "从转移包导入" + (meta.reason ? "；原记录：" + meta.reason : ""),
            duration: meta.duration || 0,
            size: st.size,
            fingerprint: itemFingerprint(srcFile),
            addedAt: new Date().toISOString(),
            source: "transfer-pack"
          });
          imported++;
        } catch (e) {
          failed++;
          log("import pack item failed: " + i + " / " + e.message);
        }
        showProgress(i + 1, items.length, "正在导入转移包…");
      }

      saveState();
      cleanMissingItems(false);
      render();
      hideProgress();
      toast("转移包导入完成：新增 " + imported + "，跳过 " + skipped + "，失败 " + failed);
      openUiConfirm({
        title: "转移包导入完成",
        subtitle: "分类和素材已合并到当前库",
        message: "新增素材：" + imported + "\n跳过重复：" + skipped + "\n失败：" + failed,
        confirmText: "知道了",
        cancelText: "关闭"
      });
    } catch (e) {
      hideProgress();
      log("import transfer pack failed: " + e.message);
      alert("导入转移包失败：" + e.message);
    }
  }

  function openLibraryDir() {
    ensureDir(LIB_DIR);
    try {
      if (process.platform === "win32") {
        childProcess.exec('explorer "' + LIB_DIR + '"');
      } else if (process.platform === "darwin") {
        childProcess.exec('open "' + LIB_DIR + '"');
      } else {
        childProcess.exec('xdg-open "' + LIB_DIR + '"');
      }
    } catch (e) {
      alert(LIB_DIR);
    }
  }

  function cleanMissingItems(shouldToast) {
    var before = state.items.length;
    state.items = state.items.filter(function (item) {
      return item && item.path && fs.existsSync(item.path);
    });

    var removed = before - state.items.length;
    if (removed > 0) saveState();
    if (shouldToast) toast("清理失效记录：" + removed);
  }

  function repairPrimaryUncategorizedItems() {
    // v4.8.3：修复旧版本产生的「一级分类 / 未分类」。
    // 只把一级分类改到默认一级分类，二级分类仍然保留原来的「悬疑 / 重音 / 未分类」等。
    var changed = 0;
    var types = ["sfx", "music"];

    for (var t = 0; t < types.length; t++) {
      var type = types[t];
      var targetPrimary = getDefaultPrimaryCategory(type);

      for (var i = 0; i < state.items.length; i++) {
        var item = state.items[i];
        if (!item || item.type !== type) continue;
        if ((item.primaryCategory || "") !== "未分类") continue;

        var oldPath = item.path;
        var cat = item.category || "未分类";
        var dest = makeDestPath(oldPath, type, cat, targetPrimary);

        try {
          ensureDir(path.dirname(dest));
          fs.renameSync(oldPath, dest);
        } catch (e) {
          try {
            fs.copyFileSync(oldPath, dest);
            try { fs.unlinkSync(oldPath); } catch (_) {}
          } catch (copyErr) {
            // 如果移动失败，至少修正显示逻辑，避免一级未分类继续出现。
          }
        }

        if (fs.existsSync(dest)) {
          item.path = dest;
          item.name = path.basename(dest);
        }

        item.primaryCategory = targetPrimary;
        item.category = cat;
        item.reason = "v4.8.3 自动修复：一级未分类移动到「" + targetPrimary + " / " + cat + "」";
        changed++;
      }
    }

    if (changed > 0) {
      saveState();
      toast("已修复旧的一级「未分类」素材：" + changed + " 个");
    }
  }

  function rescanLibrary() {
    cleanMissingItems(false);

    var existing = {};
    for (var i = 0; i < state.items.length; i++) {
      existing[normalizeSlashes(state.items[i].path).toLowerCase()] = true;
    }

    var added = 0;
    var types = ["sfx", "music"];

    for (var t = 0; t < types.length; t++) {
      var type = types[t];
      var files = walkAudioFiles(getTypeBaseDir(type));

      for (var j = 0; j < files.length; j++) {
        var f = files[j];
        var key = normalizeSlashes(f).toLowerCase();
        if (existing[key]) continue;

        var cat = path.basename(path.dirname(f));
        var primaryCategory = path.basename(path.dirname(path.dirname(f)));

        if (!primaryCategory || primaryCategory === "全部" || primaryCategory === "未分类" || primaryCategory === getTypeInfo(type).folder) primaryCategory = getDefaultPrimaryCategory(type);
        if (!cat || cat === "全部") cat = "未分类";

        ensurePrimaryCategoryExists(primaryCategory);
        ensureSecondaryCategoryExists(cat);

        var st;
        try { st = fs.statSync(f); } catch (e) { continue; }

        state.items.push({
          id: uid(),
          type: type,
          name: path.basename(f),
          originalName: path.basename(f),
          path: f,
          primaryCategory: primaryCategory,
          category: cat,
          confidence: 1,
          reason: "重新扫描库目录加入",
          duration: 0,
          size: st.size,
          fingerprint: itemFingerprint(f),
          addedAt: new Date().toISOString(),
          source: "rescan"
        });
        added++;
      }
    }

    saveState();
    render();
    toast("重新扫描完成，补回素材：" + added);
  }

  function askImportModeAndImport(dropped) {
    if (!dropped || !dropped.length) return;
    if (!requireAuthorized()) return;

    var typeLabel = getTypeInfo(getCurrentType()).label;
    var importPrimary = getImportPrimaryCategory();
    var importSecondary = getImportSecondaryCategory();

    openUiConfirm({
      title: "导入" + typeLabel,
      subtitle: "当前导入位置：「" + importPrimary + "」一级分类",
      message: "点「自动分类」：素材会固定放进当前一级分类「" + importPrimary + "」，再根据文件名分到二级分类。\n\n点「不分类导入」：素材会放进「" + importPrimary + " / " + importSecondary + "」。\n\n没有匹配到二级分类的素材，只会放进「" + importPrimary + " / 未分类」。左侧一级分类不再显示「未分类」。",
      confirmText: "自动分类",
      cancelText: "不分类导入",
      onConfirm: function () {
        importAudioPaths(dropped, {
          autoClassifyByName: true,
          targetPrimaryCategory: importPrimary,
          targetCategory: importSecondary
        });
      },
      onCancel: function () {
        importAudioPaths(dropped, {
          autoClassifyByName: false,
          targetPrimaryCategory: importPrimary,
          targetCategory: importSecondary
        });
      }
    });
  }

  function preventGlobalFileOpen() {
    window.addEventListener("dragover", function (e) {
      e.preventDefault();
      if ($("dropZone")) $("dropZone").classList.add("dragover");
    }, false);

    window.addEventListener("dragleave", function () {
      if ($("dropZone")) $("dropZone").classList.remove("dragover");
    }, false);

    window.addEventListener("drop", function (e) {
      e.preventDefault();
      if ($("dropZone")) $("dropZone").classList.remove("dragover");

      var dropped = [];
      if (e.dataTransfer && e.dataTransfer.files) {
        for (var i = 0; i < e.dataTransfer.files.length; i++) {
          if (e.dataTransfer.files[i].path) dropped.push(e.dataTransfer.files[i].path);
        }
      }

      if (dropped.length) {
        askImportModeAndImport(dropped);
      } else {
        toast("没有拿到文件路径，请直接拖入本地音频文件或文件夹。");
      }
    }, false);
  }

  function secondsToText(sec) {
    if (!sec || isNaN(sec)) return "0:00";
    var m = Math.floor(sec / 60);
    var s = Math.floor(sec % 60);
    return m + ":" + String(s).padStart(2, "0");
  }

  function updatePlayerButton() {
    var audio = $("audioPlayer");
    var icon = $("playerIcon");
    if (!audio || !icon) return;

    if (!audio.paused && !audio.ended) {
      icon.className = "pause-icon";
    } else {
      icon.className = "play-icon";
    }
    syncCardPlayState();
  }

  function updatePlayerTime() {
    var audio = $("audioPlayer");
    if (!audio) return;

    var duration = audio.duration || 0;
    var current = audio.currentTime || 0;

    $("playerCurrent").textContent = secondsToText(current);
    $("playerDuration").textContent = secondsToText(duration);

    if (duration > 0 && !$("playerSeek").dataset.dragging) {
      $("playerSeek").value = Math.round(current / duration * 1000);
    }

    if (waveState.playRangeMode && waveState.hasRange && current >= waveState.outSec) {
      audio.pause();
      audio.currentTime = waveState.outSec;
      waveState.playRangeMode = false;
      updatePlayerButton();
    }

    drawWaveform();
  }

  function setupPlayerControls() {
    var audio = $("audioPlayer");
    var toggle = $("playerToggle");
    var stop = $("playerStop");
    var seek = $("playerSeek");

    if (!audio || !toggle || !stop || !seek) return;

    toggle.addEventListener("click", function () {
      if (!audio.src) {
        toast("先选择一个素材试听。");
        return;
      }

      if (audio.paused) audio.play();
      else audio.pause();
    });

    stop.addEventListener("click", function () {
      audio.pause();
      audio.currentTime = 0;
      updatePlayerTime();
      updatePlayerButton();
    });

    seek.addEventListener("mousedown", function () {
      seek.dataset.dragging = "1";
    });

    seek.addEventListener("mouseup", function () {
      delete seek.dataset.dragging;
      if (audio.duration) {
        audio.currentTime = Number(seek.value) / 1000 * audio.duration;
      }
    });

    seek.addEventListener("change", function () {
      delete seek.dataset.dragging;
      if (audio.duration) {
        audio.currentTime = Number(seek.value) / 1000 * audio.duration;
      }
    });

    var waveCanvas = $("waveformCanvas");
    if (waveCanvas) {
      var dragMoved = false;

      function pointerToSec(e) {
        var rect = waveCanvas.getBoundingClientRect();
        return canvasXToSec((e.clientX || 0) - rect.left);
      }

      waveCanvas.addEventListener("mousedown", function (e) {
        if (!currentPreviewId || !waveState.duration) return;
        waveState.dragging = true;
        dragMoved = false;
        waveState.dragStartSec = pointerToSec(e);
        setRangeFromSeconds(waveState.dragStartSec, waveState.dragStartSec);
        e.preventDefault();
      });

      document.addEventListener("mousemove", function (e) {
        if (!waveState.dragging) return;
        dragMoved = true;
        setRangeFromSeconds(waveState.dragStartSec, pointerToSec(e));
      });

      document.addEventListener("mouseup", function (e) {
        if (!waveState.dragging) return;
        waveState.dragging = false;

        var sec = pointerToSec(e);
        if (!dragMoved || Math.abs(sec - waveState.dragStartSec) < 0.03) {
          if (audio && waveState.duration) {
            audio.currentTime = sec;
            waveState.hasRange = false;
            updateRangeLabels();
            drawWaveform();
          }
        } else {
          setRangeFromSeconds(waveState.dragStartSec, sec);
          toast("已选择区间：" + secondsToText(waveState.inSec) + " → " + secondsToText(waveState.outSec));
        }
      });
    }

    if ($("btnSetIn")) $("btnSetIn").addEventListener("click", setInPointAtCurrent);
    if ($("btnSetOut")) $("btnSetOut").addEventListener("click", setOutPointAtCurrent);
    if ($("btnPlayRange")) $("btnPlayRange").addEventListener("click", playRangeSelection);
    if ($("btnClearRange")) $("btnClearRange").addEventListener("click", clearRangeSelection);
    if ($("btnInsertRange")) $("btnInsertRange").addEventListener("click", insertCurrentRange);

    document.addEventListener("keydown", function (e) {
      var tag = String((e.target && e.target.tagName) || "").toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select") return;

      if (e.key === "i" || e.key === "I") {
        e.preventDefault();
        setInPointAtCurrent();
      } else if (e.key === "o" || e.key === "O") {
        e.preventDefault();
        setOutPointAtCurrent();
      }
    });

    window.addEventListener("resize", drawWaveform);

    audio.addEventListener("loadedmetadata", updatePlayerTime);
    audio.addEventListener("timeupdate", updatePlayerTime);
    audio.addEventListener("play", updatePlayerButton);
    audio.addEventListener("pause", function () {
      waveState.playRangeMode = false;
      updatePlayerButton();
    });
    audio.addEventListener("ended", function () {
      waveState.playRangeMode = false;
      updatePlayerButton();
    });
  }

  function setupResizableLayout() {
    var appEl = document.querySelector(".app");
    var side = $("sidebarResizer");
    var player = $("playerPanel");
    var playerHandle = $("playerResizer");

    try {
      var savedSidebar = localStorage.getItem("dramaAudio.sidebarW");
      var savedPlayer = localStorage.getItem("dramaAudio.playerH");
      if (savedSidebar) document.documentElement.style.setProperty("--sidebar-w", savedSidebar + "px");
      if (savedPlayer) document.documentElement.style.setProperty("--player-h", Math.max(118, Number(savedPlayer) || 132) + "px");
    } catch (e) {}

    if (side && appEl) {
      side.addEventListener("mousedown", function (e) {
        e.preventDefault();
        var startX = e.clientX;
        var startW = document.querySelector(".sidebar").getBoundingClientRect().width;

        function move(ev) {
          var w = Math.max(190, Math.min(380, startW + ev.clientX - startX));
          document.documentElement.style.setProperty("--sidebar-w", w + "px");
        }

        function up(ev) {
          document.removeEventListener("mousemove", move);
          document.removeEventListener("mouseup", up);
          try {
            var w = document.querySelector(".sidebar").getBoundingClientRect().width;
            localStorage.setItem("dramaAudio.sidebarW", Math.round(w));
          } catch (e) {}
        }

        document.addEventListener("mousemove", move);
        document.addEventListener("mouseup", up);
      });
    }

    if (playerHandle && player) {
      playerHandle.addEventListener("mousedown", function (e) {
        e.preventDefault();
        var startY = e.clientY;
        var startH = player.getBoundingClientRect().height;

        function move(ev) {
          var h = Math.max(48, Math.min(132, startH - (ev.clientY - startY)));
          document.documentElement.style.setProperty("--player-h", h + "px");
        }

        function up(ev) {
          document.removeEventListener("mousemove", move);
          document.removeEventListener("mouseup", up);
          try {
            var h = player.getBoundingClientRect().height;
            localStorage.setItem("dramaAudio.playerH", Math.round(h));
          } catch (e) {}
        }

        document.addEventListener("mousemove", move);
        document.addEventListener("mouseup", up);
      });
    }
  }

  function bindEvents() {
    if ($("btnHome")) $("btnHome").addEventListener("click", setHome);
    if ($("btnAddFiles")) $("btnAddFiles").addEventListener("click", function () { openDialog(false); });
    if ($("btnAddFolder")) $("btnAddFolder").addEventListener("click", function () { openDialog(true); });
    $("btnRescan").addEventListener("click", rescanLibrary);
    $("btnOpenLibrary").addEventListener("click", openLibraryDir);
    if ($("btnChangeLibraryDir")) $("btnChangeLibraryDir").addEventListener("click", changeLibraryDir);
    if ($("btnExportPack")) $("btnExportPack").addEventListener("click", exportTransferPack);
    if ($("btnImportPack")) $("btnImportPack").addEventListener("click", importTransferPack);
    if ($("btnCheckUpdate")) $("btnCheckUpdate").addEventListener("click", function () { checkPluginUpdate(true); });
    if ($("btnInstallUpdate")) $("btnInstallUpdate").addEventListener("click", function () { installPluginUpdate(latestUpdateInfo); });
    $("btnRefreshTracks").addEventListener("click", refreshTracks);
    if ($("btnOpenTrackOrganizer")) $("btnOpenTrackOrganizer").addEventListener("click", showTrackOrganizerPanel);
    if ($("btnCloseTrackOrganizer")) $("btnCloseTrackOrganizer").addEventListener("click", hideTrackOrganizerPanel);
    if ($("btnScanTracks")) $("btnScanTracks").addEventListener("click", scanOrganizerTracks);
    if ($("btnSelectAllVideoTracks")) $("btnSelectAllVideoTracks").addEventListener("click", function () { setTrackSelection("video", true); });
    if ($("btnSelectAllAudioTracks")) $("btnSelectAllAudioTracks").addEventListener("click", function () { setTrackSelection("audio", true); });
    if ($("btnClearTrackSelection")) $("btnClearTrackSelection").addEventListener("click", clearTrackSelection);
    if ($("btnAnalyzeTrackPlan")) $("btnAnalyzeTrackPlan").addEventListener("click", analyzeTrackOrganizerPlan);
    if ($("btnGenerateVisualPlan")) $("btnGenerateVisualPlan").addEventListener("click", analyzeTrackOrganizerPlan);
    if ($("btnReAnalyzeTrackPlan")) $("btnReAnalyzeTrackPlan").addEventListener("click", analyzeTrackOrganizerPlan);
    if ($("btnConfirmTrackOrganize")) $("btnConfirmTrackOrganize").addEventListener("click", confirmTrackOrganizePreviewOnly);
    if ($("btnRestoreTrackSnapshot")) $("btnRestoreTrackSnapshot").addEventListener("click", restoreTrackSnapshotPreviewOnly);
    if ($("btnOpenTrackOrgLog")) $("btnOpenTrackOrgLog").addEventListener("click", openTrackOrganizerLogFolder);
    $("btnInsertSelected").addEventListener("click", insertSelected);
    $("btnSelectPage").addEventListener("click", selectCurrentList);
    $("btnSelectCategory").addEventListener("click", selectCurrentCategory);
    $("btnInvertSelection").addEventListener("click", invertCurrentListSelection);
    $("btnClearSelection").addEventListener("click", clearSelection);
    $("btnBatchMove").addEventListener("click", batchMoveSelected);
    if ($("btnBatchAutoClassify")) $("btnBatchAutoClassify").addEventListener("click", batchAutoClassifySelected);
    if ($("btnBatchDelete")) $("btnBatchDelete").addEventListener("click", batchDeleteSelected);
    $("searchInput").addEventListener("input", render);
    $("sortSelect").addEventListener("change", render);
    if ($("btnCreatePrimaryCategory")) $("btnCreatePrimaryCategory").addEventListener("click", createCustomPrimaryCategory);
    if ($("btnCreateCategory")) $("btnCreateCategory").addEventListener("click", createCustomCategory);
    if ($("btnAddPrimaryQuick")) $("btnAddPrimaryQuick").addEventListener("click", addPrimaryCategoryQuick);
    if ($("btnDeletePrimaryQuick")) $("btnDeletePrimaryQuick").addEventListener("click", deleteCurrentPrimaryCategoryQuick);
    if ($("btnAddSecondaryQuick")) $("btnAddSecondaryQuick").addEventListener("click", addSecondaryCategoryQuick);
    if ($("btnDeleteSecondaryQuick")) $("btnDeleteSecondaryQuick").addEventListener("click", deleteCurrentSecondaryCategoryQuick);

    if ($("customPrimaryInput")) $("customPrimaryInput").addEventListener("keydown", function (e) {
      if (e.key === "Enter") createCustomPrimaryCategory();
    });

    if ($("customCategoryInput")) $("customCategoryInput").addEventListener("keydown", function (e) {
      if (e.key === "Enter") createCustomCategory();
    });

    $("tabSfx").addEventListener("click", function () { switchType("sfx"); });
    $("tabMusic").addEventListener("click", function () { switchType("music"); });

    preventGlobalFileOpen();
  }


  function applyUiScale(percent) {
    percent = Math.max(80, Math.min(120, parseInt(percent || 92, 10)));
    document.documentElement.style.setProperty("--ui-scale", String(percent / 100));
    var label = $("uiScaleLabel");
    if (label) label.textContent = percent + "%";
    var range = $("uiScaleRange");
    if (range) range.value = percent;
    try { localStorage.setItem("dramaAudio.uiScale", String(percent)); } catch (e) {}
  }

  function setupUiScaleControl() {
    var range = $("uiScaleRange");
    var saved = 92;

    try {
      saved = parseInt(localStorage.getItem("dramaAudio.uiScale") || "92", 10) || 92;
    } catch (e) {
      saved = 92;
    }

    applyUiScale(saved);

    if (range) {
      range.addEventListener("input", function () {
        applyUiScale(range.value);
      });
      range.addEventListener("change", function () {
        applyUiScale(range.value);
        toast("界面缩放：" + range.value + "%");
      });
    }
  }

  function applyAssetRowScale(percent) {
    percent = Math.max(75, Math.min(150, parseInt(percent || 100, 10)));
    document.documentElement.style.setProperty("--asset-row-scale", String(percent / 100));
    var label = $("assetRowScaleLabel");
    if (label) label.textContent = percent + "%";
    var range = $("assetRowScaleRange");
    if (range) range.value = percent;
    try { localStorage.setItem("dramaAudio.assetRowScale", String(percent)); } catch (e) {}
  }

  function setupAssetRowScaleControl() {
    var range = $("assetRowScaleRange");
    var saved = 100;

    try {
      saved = parseInt(localStorage.getItem("dramaAudio.assetRowScale") || "100", 10) || 100;
    } catch (e) {
      saved = 100;
    }

    applyAssetRowScale(saved);

    if (range) {
      range.addEventListener("input", function () {
        applyAssetRowScale(range.value);
      });
      range.addEventListener("change", function () {
        applyAssetRowScale(range.value);
        toast("文件显示缩放：" + range.value + "%");
      });
    }
  }


  function init() {
    try {
      loadState();
      bindEvents();
      bindAuthEvents();
      bindUiDialog();
      setupPlayerControls();
      setupResizableLayout();
      setupUiScaleControl();
      setupAssetRowScaleControl();
      render();
      refreshTracks();
      checkAuthorization();
      setTrackOrganizerButtonsEnabled(false);
      toast("短剧音频库 v4.9.18 筛选操作区重排版已启动");
    } catch (e) {
      log("init failed: " + e);
      alert("插件初始化失败：" + e + "\n请打开本地库目录查看 debug.log");
    }
  }

  init();
})();
