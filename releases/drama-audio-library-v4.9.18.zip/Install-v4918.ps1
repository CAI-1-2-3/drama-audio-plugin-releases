﻿# 短剧音频库 v4.9.18 筛选操作区重排版安装器
$ErrorActionPreference = "Stop"
$Version = "v4.9.18"
$PanelId = "com.cai.dramaaudiolibrary.panel"
$BundleId = "com.cai.dramaaudiolibrary"

function Show-Step { param([int]$Percent,[string]$Status)
  Write-Progress -Activity "短剧音频库 $Version 安装中" -Status $Status -PercentComplete $Percent
  Write-Host ("[{0,3}%] {1}" -f $Percent, $Status) -ForegroundColor Cyan
}
function Ensure-Dir { param([string]$Path) if (!(Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } }
function Add-UniquePath { param([System.Collections.Generic.List[string]]$List,[string]$Path)
  if ([string]::IsNullOrWhiteSpace($Path)) { return }
  $p = $Path.Trim()
  if ($List -notcontains $p) { [void]$List.Add($p) }
}
function Is-PluginFolder { param([string]$Folder)
  try {
    $mf = Join-Path $Folder "CSXS\manifest.xml"
    $idx = Join-Path $Folder "index.html"
    $app = Join-Path $Folder "js\app.js"
    if (Test-Path -LiteralPath $mf) {
      $t = Get-Content -LiteralPath $mf -Raw -Encoding UTF8
      if ($t -like "*$BundleId*" -or $t -like "*$PanelId*" -or $t -like "*短剧音频库*") { return $true }
    }
    if (Test-Path -LiteralPath $idx) {
      $t = Get-Content -LiteralPath $idx -Raw -Encoding UTF8
      if ($t -like "*短剧音频库*") { return $true }
    }
    if (Test-Path -LiteralPath $app) {
      $t = Get-Content -LiteralPath $app -Raw -Encoding UTF8
      if ($t -like "*drama-audio-library*" -or $t -like "*短剧音频库*") { return $true }
    }
  } catch {}
  return $false
}
function Copy-PluginToTarget { param([string]$SourceDir,[string]$TargetDir,[string]$BackupRoot)
  Ensure-Dir (Split-Path -Parent $TargetDir)
  if (Test-Path -LiteralPath $TargetDir) {
    $backup = Join-Path $BackupRoot ("plugin-backup-" + (Split-Path -Leaf $TargetDir) + "-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Copy-Item -LiteralPath $TargetDir -Destination $backup -Recurse -Force
    Remove-Item -LiteralPath $TargetDir -Recurse -Force
  }
  Ensure-Dir $TargetDir

  $Exclude = @(
    "Install-v4918.ps1",
    "一键安装-v4.9.18.bat",
    "INSTALL_SAFE.bat",
    "install-log-v4-9-18.txt"
  )

  Get-ChildItem -LiteralPath $SourceDir -Force | Where-Object { $Exclude -notcontains $_.Name } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $TargetDir -Recurse -Force
  }

  return $TargetDir
}

try {
  $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
  $LogPath = Join-Path $ScriptDir "install-log-v4-9-18.txt"
  Start-Transcript -Path $LogPath -Force | Out-Null
  Clear-Host
  Write-Host "短剧音频库 v4.9.18 筛选操作区重排版安装器" -ForegroundColor Cyan

  Show-Step 5 "检查安装包文件"
  foreach ($r in @("index.html","CSXS","js","jsx","css")) {
    if (!(Test-Path -LiteralPath (Join-Path $ScriptDir $r))) { throw "安装包缺少必要文件：$r" }
  }

  Show-Step 12 "扫描所有可能的 Adobe CEP 插件目录"
  $Roots = New-Object System.Collections.Generic.List[string]
  Add-UniquePath $Roots (Join-Path $env:APPDATA "Adobe\CEP\extensions")
  if ($env:LOCALAPPDATA) { Add-UniquePath $Roots (Join-Path $env:LOCALAPPDATA "Adobe\CEP\extensions") }
  if ($env:ProgramFiles) { Add-UniquePath $Roots (Join-Path $env:ProgramFiles "Common Files\Adobe\CEP\extensions") }
  if (${env:ProgramFiles(x86)}) { Add-UniquePath $Roots (Join-Path ${env:ProgramFiles(x86)} "Common Files\Adobe\CEP\extensions") }
  if ($env:CommonProgramFiles) { Add-UniquePath $Roots (Join-Path $env:CommonProgramFiles "Adobe\CEP\extensions") }
  if (${env:CommonProgramFiles(x86)}) { Add-UniquePath $Roots (Join-Path ${env:CommonProgramFiles(x86)} "Adobe\CEP\extensions") }

  $Targets = New-Object System.Collections.Generic.List[string]

  # 默认用户目录一定安装一份
  $DefaultTarget = Join-Path (Join-Path $env:APPDATA "Adobe\CEP\extensions") $PanelId
  Add-UniquePath $Targets $DefaultTarget

  # 扫描旧版本实际所在位置，找到就原地覆盖，避免 PR 继续加载旧 v4.9.7
  foreach ($root in $Roots) {
    if (!(Test-Path -LiteralPath $root)) { continue }
    Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
      if ($_.Name -eq $PanelId -or (Is-PluginFolder $_.FullName)) {
        Add-UniquePath $Targets $_.FullName
      }
    }
  }

  Show-Step 25 ("发现需要覆盖的插件目录：" + $Targets.Count)
  $BackupRoot = Join-Path $env:APPDATA "DramaAudioLibrary\installer-backups"
  Ensure-Dir $BackupRoot

  $Installed = New-Object System.Collections.Generic.List[string]
  foreach ($target in $Targets) {
    try {
      Show-Step 45 ("覆盖安装：" + $target)
      $done = Copy-PluginToTarget $ScriptDir $target $BackupRoot
      [void]$Installed.Add($done)
    } catch {
      Write-Host ("跳过目录：" + $target) -ForegroundColor Yellow
      Write-Host $_.Exception.Message -ForegroundColor Yellow
    }
  }

  if ($Installed.Count -lt 1) { throw "没有任何 CEP 插件目录安装成功。请右键以管理员身份运行安装器。" }

  Show-Step 72 "写入 CEP 调试注册表"
  foreach ($v in @("8","9","10","11","12","13","14")) {
    New-Item -Path "HKCU:\Software\Adobe\CSXS.$v" -Force | Out-Null
    New-ItemProperty -Path "HKCU:\Software\Adobe\CSXS.$v" -Name "PlayerDebugMode" -Value "1" -PropertyType String -Force | Out-Null
  }

  Show-Step 88 "检查用户数据目录"
  $UserDataDir = Join-Path $env:APPDATA "DramaAudioLibrary"
  Ensure-Dir $UserDataDir
  Ensure-Dir (Join-Path $UserDataDir "track-organizer")
  Ensure-Dir (Join-Path $UserDataDir "track-organizer\snapshots")

  $Marker = Join-Path $UserDataDir "last-installed-version.txt"
  Set-Content -LiteralPath $Marker -Value ("$Version installed at " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") + "`r`n" + ($Installed -join "`r`n")) -Encoding UTF8

  Show-Step 100 "安装完成"
  Write-Progress -Activity "短剧音频库 $Version 安装中" -Completed
  Write-Host ""
  Write-Host "安装成功。已覆盖以下目录：" -ForegroundColor Green
  foreach ($x in $Installed) { Write-Host (" - " + $x) -ForegroundColor Green }
  Write-Host ""
  Write-Host "请完全关闭 Premiere Pro 后重新打开。如果还显示旧版本，打开 install-log-v4-9-18.txt 发给我。" -ForegroundColor Yellow
  Stop-Transcript | Out-Null
  exit 0
}
catch {
  Write-Progress -Activity "短剧音频库 $Version 安装中" -Completed
  Write-Host "安装失败：" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  try { Stop-Transcript | Out-Null } catch {}
  pause
  exit 1
}
