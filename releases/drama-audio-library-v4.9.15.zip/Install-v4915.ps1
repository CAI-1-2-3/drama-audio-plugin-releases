﻿# 短剧音频库 v4.9.15 音频列表交互优化版安装器
$ErrorActionPreference = "Stop"
$Version = "v4.9.15"
$PanelId = "com.cai.dramaaudiolibrary.panel"

function Show-Step { param([int]$Percent,[string]$Status)
  Write-Progress -Activity "短剧音频库 $Version 安装中" -Status $Status -PercentComplete $Percent
  Write-Host ("[{0,3}%] {1}" -f $Percent, $Status) -ForegroundColor Cyan
}
function Ensure-Dir { param([string]$Path) if (!(Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } }

try {
  $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
  $LogPath = Join-Path $ScriptDir "install-log-v4-9-15.txt"
  Start-Transcript -Path $LogPath -Force | Out-Null
  Clear-Host
  Write-Host "短剧音频库 v4.9.15 音频列表交互优化版安装器" -ForegroundColor Cyan

  Show-Step 5 "检查安装包文件"
  foreach ($r in @("index.html","CSXS","js","jsx","css")) {
    if (!(Test-Path -LiteralPath (Join-Path $ScriptDir $r))) { throw "安装包缺少必要文件：$r" }
  }

  Show-Step 15 "定位 Adobe CEP 插件目录"
  $CepDir = Join-Path $env:APPDATA "Adobe\CEP\extensions"
  Ensure-Dir $CepDir
  $TargetDir = Join-Path $CepDir $PanelId

  Show-Step 25 "备份旧插件程序文件"
  $BackupRoot = Join-Path $env:APPDATA "DramaAudioLibrary\installer-backups"
  Ensure-Dir $BackupRoot
  if (Test-Path -LiteralPath $TargetDir) {
    $backup = Join-Path $BackupRoot ("plugin-backup-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Copy-Item -LiteralPath $TargetDir -Destination $backup -Recurse -Force
  }

  Show-Step 40 "清理旧插件程序目录"
  if (Test-Path -LiteralPath $TargetDir) { Remove-Item -LiteralPath $TargetDir -Recurse -Force }
  Ensure-Dir $TargetDir

  Show-Step 55 "复制插件文件"
  $Exclude = @("Install-v4915.ps1","一键安装-v4.9.15.bat","INSTALL_SAFE.bat")
  Get-ChildItem -LiteralPath $ScriptDir -Force | Where-Object { $Exclude -notcontains $_.Name } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $TargetDir -Recurse -Force
  }

  Show-Step 72 "写入 CEP 调试注册表"
  foreach ($v in @("11","12","13","14")) {
    New-Item -Path "HKCU:\Software\Adobe\CSXS.$v" -Force | Out-Null
    New-ItemProperty -Path "HKCU:\Software\Adobe\CSXS.$v" -Name "PlayerDebugMode" -Value "1" -PropertyType String -Force | Out-Null
  }

  Show-Step 88 "检查用户数据目录"
  $UserDataDir = Join-Path $env:APPDATA "DramaAudioLibrary"
  Ensure-Dir $UserDataDir
  Ensure-Dir (Join-Path $UserDataDir "track-organizer")
  Ensure-Dir (Join-Path $UserDataDir "track-organizer\snapshots")

  Show-Step 100 "安装完成"
  Write-Progress -Activity "短剧音频库 $Version 安装中" -Completed
  Write-Host "安装成功，请重启 Premiere Pro。" -ForegroundColor Green
  Stop-Transcript | Out-Null
  exit 0
}
catch {
  Write-Progress -Activity "短剧音频库 $Version 安装中" -Completed
  Write-Host "安装失败：" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  try { Stop-Transcript | Out-Null } catch {}
  pause
  exit 1
}
