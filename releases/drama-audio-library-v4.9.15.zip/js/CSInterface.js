/*
  Minimal CSInterface wrapper.
*/
(function () {
  function CSInterface() {}

  CSInterface.prototype.evalScript = function (script, callback) {
    if (window.__adobe_cep__ && window.__adobe_cep__.evalScript) {
      window.__adobe_cep__.evalScript(script, callback || function () {});
    } else {
      console.warn("CEP evalScript unavailable.");
      if (callback) callback("");
    }
  };

  CSInterface.prototype.getSystemPath = function (pathType) {
    if (window.__adobe_cep__ && window.__adobe_cep__.getSystemPath) {
      return window.__adobe_cep__.getSystemPath(pathType);
    }
    return "";
  };

  window.CSInterface = CSInterface;
  window.SystemPath = {
    USER_DATA: "userData",
    EXTENSION: "extension"
  };
})();
