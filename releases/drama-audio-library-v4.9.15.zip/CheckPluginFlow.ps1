﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$PluginId = "com.cai.dramaaudiolibrary"
$Api = "https://drama-audio-license-api.cai1473785473.workers.dev"
$PluginDir = Join-Path $env:APPDATA "Adobe\CEP\extensions\$PluginId"
$DataDir = Join-Path $env:APPDATA "DramaAudioLibrary"

$form = New-Object System.Windows.Forms.Form
$form.Text = "Drama Audio Plugin Flow Check v4.2"
$form.Size = New-Object System.Drawing.Size(920, 640)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(13,16,22)
$form.ForeColor = [System.Drawing.Color]::Gainsboro
$form.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = "Short Drama Audio Library v4.2 Flow Check"
$title.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 15, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(255,208,71)
$title.Location = New-Object System.Drawing.Point(18,14)
$title.Size = New-Object System.Drawing.Size(760,30)
$form.Controls.Add($title)

$box = New-Object System.Windows.Forms.RichTextBox
$box.Location = New-Object System.Drawing.Point(18,60)
$box.Size = New-Object System.Drawing.Size(868,460)
$box.BackColor = [System.Drawing.Color]::FromArgb(11,15,22)
$box.ForeColor = [System.Drawing.Color]::Gainsboro
$box.ReadOnly = $true
$box.Font = New-Object System.Drawing.Font("Consolas", 10)
$form.Controls.Add($box)

$btn = New-Object System.Windows.Forms.Button
$btn.Text = "Check"
$btn.Location = New-Object System.Drawing.Point(18,538)
$btn.Size = New-Object System.Drawing.Size(120,36)
$btn.BackColor = [System.Drawing.Color]::FromArgb(255,208,71)
$btn.ForeColor = [System.Drawing.Color]::Black
$form.Controls.Add($btn)

$openPlugin = New-Object System.Windows.Forms.Button
$openPlugin.Text = "Open Plugin Folder"
$openPlugin.Location = New-Object System.Drawing.Point(154,538)
$openPlugin.Size = New-Object System.Drawing.Size(150,36)
$openPlugin.BackColor = [System.Drawing.Color]::FromArgb(32,40,57)
$openPlugin.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($openPlugin)

$openData = New-Object System.Windows.Forms.Button
$openData.Text = "Open Data Folder"
$openData.Location = New-Object System.Drawing.Point(320,538)
$openData.Size = New-Object System.Drawing.Size(150,36)
$openData.BackColor = [System.Drawing.Color]::FromArgb(32,40,57)
$openData.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($openData)

function Line($text, $color) {
    $box.SelectionStart = $box.TextLength
    $box.SelectionColor = $color
    $box.AppendText($text + [Environment]::NewLine)
    $box.SelectionColor = $box.ForeColor
}
function OK($t) { Line "[OK]   $t" ([System.Drawing.Color]::LightGreen) }
function WARN($t) { Line "[WARN] $t" ([System.Drawing.Color]::Khaki) }
function FAIL($t) { Line "[FAIL] $t" ([System.Drawing.Color]::LightSalmon) }

$btn.Add_Click({
    $box.Clear()
    Line "PluginDir: $PluginDir" ([System.Drawing.Color]::LightSkyBlue)
    Line "DataDir:   $DataDir" ([System.Drawing.Color]::LightSkyBlue)
    Line "API:       $Api" ([System.Drawing.Color]::LightSkyBlue)
    Line "" ([System.Drawing.Color]::Gainsboro)

    if (Test-Path $PluginDir) { OK "Plugin folder exists" } else { FAIL "Plugin folder missing. Run installer first." }
    foreach ($f in @("CSXS\manifest.xml", "index.html", "css\styles.css", "js\app.js", "jsx\host.jsx")) {
        if (Test-Path (Join-Path $PluginDir $f)) { OK $f } else { FAIL "$f missing" }
    }

    $manifest = Join-Path $PluginDir "CSXS\manifest.xml"
    if (Test-Path $manifest) {
        $txt = Get-Content $manifest -Raw -Encoding UTF8
        if ($txt -match 'ExtensionBundleVersion="4\.2\.0"') { OK "Manifest version 4.2.0" } else { WARN "Manifest version is not 4.2.0" }
    }

    $app = Join-Path $PluginDir "js\app.js"
    if (Test-Path $app) {
        $txt = Get-Content $app -Raw -Encoding UTF8
        if ($txt -match [regex]::Escape($Api)) { OK "API URL written into app.js" } else { FAIL "API URL not found in app.js" }
    }

    if (Test-Path $DataDir) { OK "Data folder exists" } else { WARN "Data folder not created yet. It will be created when plugin starts." }
    foreach ($f in @("library.json", "device.json", "license.json")) {
        $p = Join-Path $DataDir $f
        if (Test-Path $p) { OK "Data file: $f" } else { WARN "Data file not found yet: $f" }
    }

    try {
        $root = Invoke-WebRequest -Uri $Api -UseBasicParsing -TimeoutSec 12
        if ($root.Content -match "Drama Audio License API is running") { OK "API root reachable" } else { WARN "API root returned unexpected content" }
    } catch { FAIL "API root request failed: $($_.Exception.Message)" }

    try {
        $body = @{ product = "drama-audio-library"; deviceId = "DAG-CHECK-0000-0000-0000"; pluginVersion = "4.2.0"; licenseCode = "" } | ConvertTo-Json
        $res = Invoke-RestMethod -Uri "$Api/api/startup" -Method POST -ContentType "application/json" -Body $body -TimeoutSec 15
        if ($res.status -eq "trial_active" -or $res.status -eq "trial_expired" -or $res.status -eq "licensed") {
            OK "/api/startup reachable. status=$($res.status)"
        } else {
            WARN "/api/startup returned status=$($res.status)"
        }
    } catch { FAIL "/api/startup request failed: $($_.Exception.Message)" }

    Line "" ([System.Drawing.Color]::Gainsboro)
    Line "Check complete. Fix [FAIL] items first." ([System.Drawing.Color]::FromArgb(255,208,71))
})

$openPlugin.Add_Click({ if (Test-Path $PluginDir) { Start-Process explorer.exe $PluginDir } })
$openData.Add_Click({ if (!(Test-Path $DataDir)) { New-Item -Path $DataDir -ItemType Directory -Force | Out-Null }; Start-Process explorer.exe $DataDir })

[void]$form.ShowDialog()
