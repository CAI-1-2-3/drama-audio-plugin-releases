@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

title 短剧音频库 v4.7 备用安装器

set "PLUGIN_ID=com.cai.dramaaudiolibrary"
set "SRC=%~dp0"
set "DESTROOT=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%DESTROOT%\%PLUGIN_ID%"
set "DATA=%APPDATA%\DramaAudioLibrary"
set "BACKUP=%DATA%\backups"
set "LOG=%~dp0install-log-v4-7-fallback.txt"

echo ========= v4.7 fallback install ========= > "%LOG%"
echo SRC=%SRC% >> "%LOG%"
echo DEST=%DEST% >> "%LOG%"

echo.
echo [备用安装器] 如果 PowerShell 安装器失败，再运行这个。
echo.

if exist "%DATA%\library.json" (
  if not exist "%BACKUP%" mkdir "%BACKUP%"
  copy "%DATA%\library.json" "%BACKUP%\library-backup-fallback.json" /Y >> "%LOG%" 2>&1
  echo 已备份 library.json
)

if exist "%DEST%\CSXS\manifest.xml" (
  echo 检测到旧版本插件。
  choice /C YN /M "是否覆盖旧版本插件本体？Y=覆盖，N=取消"
  if errorlevel 2 (
    echo 已取消。
    pause
    exit /b 0
  )
  rmdir /s /q "%DEST%" >> "%LOG%" 2>&1
)

if not exist "%DESTROOT%" mkdir "%DESTROOT%" >> "%LOG%" 2>&1
mkdir "%DEST%" >> "%LOG%" 2>&1

echo 复制文件中...
xcopy "%SRC%CSXS" "%DEST%\CSXS" /E /I /Y >> "%LOG%" 2>&1
xcopy "%SRC%css" "%DEST%\css" /E /I /Y >> "%LOG%" 2>&1
xcopy "%SRC%js" "%DEST%\js" /E /I /Y >> "%LOG%" 2>&1
xcopy "%SRC%jsx" "%DEST%\jsx" /E /I /Y >> "%LOG%" 2>&1
copy "%SRC%index.html" "%DEST%\index.html" /Y >> "%LOG%" 2>&1
copy "%SRC%README.md" "%DEST%\README.md" /Y >> "%LOG%" 2>&1

echo 开启 CEP 调试模式...
for %%v in (9 10 11 12 13 14) do (
  reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >> "%LOG%" 2>&1
)

if exist "%DEST%\CSXS\manifest.xml" (
  echo.
  echo 安装完成，请重启 Premiere Pro。
  explorer "%DEST%"
) else (
  echo.
  echo 安装失败，请查看：
  echo %LOG%
)

echo.
pause
